import React from 'react';
import { SuspiciousSpan } from '../types';

interface HighlightedMessageProps {
  text: string;
  spans?: SuspiciousSpan[];
}

export const HighlightedMessage: React.FC<HighlightedMessageProps> = ({ text, spans = [] }) => {
  if (!spans || spans.length === 0) {
    return (
      <div className="font-mono text-sm leading-relaxed p-4 bg-cyber-surface rounded-lg border border-cyber-border text-slate-300 whitespace-pre-wrap select-text">
        {text}
      </div>
    );
  }

  // Sort spans by start index
  const sortedSpans = [...spans].sort((a, b) => a.start - b.start);

  // Build rendered fragments
  const fragments: React.ReactNode[] = [];
  let currentIndex = 0;

  sortedSpans.forEach((span, i) => {
    // Non-overlapping check
    if (span.start < currentIndex) return;

    // Normal text before match
    if (span.start > currentIndex) {
      fragments.push(
        <span key={`text-${currentIndex}`}>
          {text.slice(currentIndex, span.start)}
        </span>
      );
    }

    // Highlighted phrase
    const isCritical = span.severity === 'CRITICAL' || span.category.includes('Credential') || span.category.includes('Threatening');
    const badgeBg = isCritical
      ? 'bg-red-500/25 text-red-300 border-red-500/50 shadow-neon-danger'
      : 'bg-amber-500/25 text-amber-300 border-amber-500/50';

    fragments.push(
      <span
        key={`span-${i}`}
        title={`${span.category} [${span.severity}]`}
        className={`inline-block px-1.5 py-0.5 my-0.5 rounded border text-xs font-semibold cursor-help transition-transform hover:scale-105 ${badgeBg}`}
      >
        {text.slice(span.start, span.end)}
        <span className="ml-1 text-[9px] uppercase tracking-wider opacity-75 font-normal">
          ({span.category.split(' ')[0]})
        </span>
      </span>
    );

    currentIndex = span.end;
  });

  // Trailing text
  if (currentIndex < text.length) {
    fragments.push(
      <span key={`text-${currentIndex}`}>
        {text.slice(currentIndex)}
      </span>
    );
  }

  return (
    <div className="font-mono text-sm leading-relaxed p-5 bg-cyber-surface rounded-xl border border-cyber-border text-slate-200 whitespace-pre-wrap select-text">
      {fragments}
    </div>
  );
};
