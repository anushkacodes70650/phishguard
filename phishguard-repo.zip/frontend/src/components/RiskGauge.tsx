import React from 'react';
import { motion } from 'framer-motion';

interface RiskGaugeProps {
  score: number;
  level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  size?: number;
  showDetails?: boolean;
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({
  score,
  level,
  size = 200,
  showDetails = true
}) => {
  const strokeWidth = size * 0.08;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(100, Math.max(0, score));
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  let strokeColor = '#22C55E'; // green
  let glowColor = 'rgba(34, 197, 94, 0.4)';
  let bgBadge = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';

  if (level === 'CRITICAL') {
    strokeColor = '#EF4444';
    glowColor = 'rgba(239, 68, 68, 0.5)';
    bgBadge = 'bg-red-500/10 text-red-400 border-red-500/30';
  } else if (level === 'HIGH') {
    strokeColor = '#F97316';
    glowColor = 'rgba(249, 115, 22, 0.45)';
    bgBadge = 'bg-orange-500/10 text-orange-400 border-orange-500/30';
  } else if (level === 'MEDIUM') {
    strokeColor = '#F59E0B';
    glowColor = 'rgba(245, 158, 11, 0.4)';
    bgBadge = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
  }

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative" style={{ width: size, height: size }}>
        {/* Glow backdrop */}
        <div
          className="absolute inset-0 rounded-full blur-xl transition-all duration-700"
          style={{ background: glowColor, transform: 'scale(0.8)' }}
        />

        <svg width={size} height={size} className="rotate-[-90deg] relative z-10">
          {/* Background Track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke="#1E2D4A"
            strokeWidth={strokeWidth}
          />
          {/* Animated Value Arc */}
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke={strokeColor}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.4, ease: "easeOut" }}
            strokeLinecap="round"
          />
        </svg>

        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center z-20">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex items-baseline"
          >
            <span className="text-4xl sm:text-5xl font-mono font-extrabold tracking-tight text-white">
              {score}
            </span>
            <span className="text-xs text-cyber-muted font-mono ml-1">/100</span>
          </motion.div>
          <span className="text-[10px] tracking-wider uppercase font-semibold text-cyber-muted mt-1">
            Risk Index
          </span>
        </div>
      </div>

      {showDetails && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-4 flex flex-col items-center"
        >
          <span className={`px-4 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider border ${bgBadge}`}>
            {level} THREAT
          </span>
        </motion.div>
      )}
    </div>
  );
};
