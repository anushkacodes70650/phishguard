import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, CheckCircle2, Loader2 } from 'lucide-react';

interface RadarScannerProps {
  onComplete?: () => void;
  target: string;
}

const STAGES = [
  "Validating host & SSRF safety boundary",
  "Analyzing lexical entropy & punycode homoglyphs",
  "Evaluating brand impersonation heuristics",
  "Inspecting transport encryption & redirect vectors",
  "Synthesizing threat intelligence indicators"
];

export const RadarScanner: React.FC<RadarScannerProps> = ({ onComplete, target }) => {
  const [currentStage, setCurrentStage] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStage((prev) => {
        if (prev < STAGES.length - 1) {
          return prev + 1;
        } else {
          clearInterval(interval);
          if (onComplete) {
            setTimeout(onComplete, 400);
          }
          return prev;
        }
      });
    }, 450);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 max-w-lg mx-auto">
      {/* Radar Animation Box */}
      <div className="relative w-56 h-56 rounded-full border-2 border-cyber-cyan/30 flex items-center justify-center overflow-hidden bg-cyber-card/60 backdrop-blur-md shadow-neon-cyan">
        {/* Concentric rings */}
        <div className="absolute w-44 h-44 rounded-full border border-cyber-cyan/20" />
        <div className="absolute w-28 h-28 rounded-full border border-cyber-cyan/30" />
        <div className="absolute w-12 h-12 rounded-full border border-cyber-cyan/40 bg-cyber-cyan/10" />

        {/* Crosshair grid lines */}
        <div className="absolute w-full h-[1px] bg-cyber-cyan/20" />
        <div className="absolute h-full w-[1px] bg-cyber-cyan/20" />

        {/* Rotating sweep line */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2.2, ease: "linear" }}
          className="absolute inset-0 origin-center"
          style={{
            background: 'conic-gradient(from 0deg, rgba(0, 229, 255, 0.45) 0deg, transparent 65deg, transparent 360deg)'
          }}
        />

        {/* Center Shield Icon */}
        <div className="relative z-10 p-3 rounded-full bg-cyber-card border border-cyber-cyan/60 text-cyber-cyan">
          <Shield className="w-6 h-6 animate-pulse" />
        </div>
      </div>

      {/* Target and Live Stage Indicator */}
      <div className="mt-8 text-center w-full">
        <div className="text-xs font-mono text-cyber-cyan uppercase tracking-widest mb-1 flex items-center justify-center gap-1.5">
          <Loader2 className="w-3.5 h-3.5 animate-spin" /> Deep Forensic Inspection
        </div>
        <div className="text-sm font-mono text-slate-300 truncate max-w-sm mx-auto bg-cyber-surface px-3 py-1.5 rounded border border-cyber-border/60">
          {target}
        </div>

        {/* Progressive Stages Checklist */}
        <div className="mt-6 space-y-2 text-left bg-cyber-card/70 border border-cyber-border rounded-xl p-4">
          {STAGES.map((stage, idx) => {
            const isDone = idx < currentStage;
            const isCurrent = idx === currentStage;
            return (
              <motion.div
                key={stage}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.2 }}
                className={`flex items-center text-xs font-mono transition-colors ${
                  isDone ? 'text-cyber-success' : isCurrent ? 'text-cyber-cyan font-semibold' : 'text-slate-500'
                }`}
              >
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 mr-2 text-cyber-success shrink-0" />
                ) : isCurrent ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin text-cyber-cyan shrink-0" />
                ) : (
                  <div className="w-4 h-4 mr-2 rounded-full border border-slate-700 shrink-0" />
                )}
                <span className="truncate">{stage}</span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
