import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShieldAlert, CheckCircle, AlertTriangle, FileDown, ExternalLink, Loader2 } from 'lucide-react';
import { RiskGauge } from './RiskGauge';
import { HighlightedMessage } from './HighlightedMessage';
import api from '../services/api';

interface ScanDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  scanData: any;
}

export const ScanDetailModal: React.FC<ScanDetailModalProps> = ({ isOpen, onClose, scanData }) => {
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  if (!isOpen || !scanData) return null;

  const result = scanData.result || {};
  const isMessage = scanData.scan_type === 'message';
  const isDomain = scanData.scan_type === 'domain';
  const isUrl = scanData.scan_type === 'url';

  const handleDownloadReport = async () => {
    try {
      setDownloadingPdf(true);
      // Generate or retrieve report
      const genRes = await api.post(`/reports/generate/${scanData.id}`);
      const reportId = genRes.data.id;

      // Download binary PDF
      const resp = await api.get(`/reports/${reportId}/download`, { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([resp.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${genRes.data.report_code || 'PhishGuard_Report'}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error("PDF download failed", err);
      alert("Failed to download PDF report. Please verify connection.");
    } finally {
      setDownloadingPdf(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-4xl bg-cyber-card border border-cyber-cyan/30 rounded-2xl shadow-2xl p-6 my-8 max-h-[90vh] overflow-y-auto"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-lg bg-cyber-surface hover:bg-cyber-border text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2.5 rounded-xl bg-cyber-cyan/10 border border-cyber-cyan/30 text-cyber-cyan">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-cyber-cyan">
                Forensic Inspection // {scanData.scan_type?.toUpperCase()}
              </span>
              <h2 className="text-lg font-bold text-white font-mono truncate max-w-lg">
                {scanData.target_display || scanData.input_value}
              </h2>
            </div>
          </div>

          {/* Top Grid: Gauge + Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-5 rounded-xl bg-cyber-surface/60 border border-cyber-border/70 mb-6">
            <div className="flex justify-center items-center">
              <RiskGauge score={scanData.risk_score} level={scanData.risk_level} size={150} />
            </div>
            <div className="md:col-span-2 flex flex-col justify-between">
              <div>
                <h4 className="text-xs uppercase font-mono tracking-wider text-slate-400 mb-1">
                  Executive Assessment
                </h4>
                <p className="text-sm text-slate-200 leading-relaxed font-sans mb-3">
                  {scanData.summary}
                </p>
                <div className="text-xs font-mono text-slate-400">
                  Target: <span className="text-cyber-cyan break-all">{scanData.input_value}</span>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-3">
                <button
                  onClick={handleDownloadReport}
                  disabled={downloadingPdf}
                  className="inline-flex items-center px-4 py-2 rounded-lg bg-cyber-cyan/10 border border-cyber-cyan text-cyber-cyan hover:bg-cyber-cyan hover:text-black font-mono text-xs font-semibold transition-all disabled:opacity-50"
                >
                  {downloadingPdf ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating Report...
                    </>
                  ) : (
                    <>
                      <FileDown className="w-4 h-4 mr-2" />
                      Download Forensic PDF
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Message Scanner Visual Highlighting */}
          {isMessage && (
            <div className="mb-6">
              <h3 className="text-sm font-mono uppercase tracking-wider text-slate-300 mb-2">
                Highlighted Phrase Detection
              </h3>
              <HighlightedMessage text={scanData.input_value} spans={result.suspicious_spans} />
            </div>
          )}

          {/* Technical Checks & Findings */}
          <div className="mb-6">
            <h3 className="text-sm font-mono uppercase tracking-wider text-slate-300 mb-3">
              Automated Forensic Checks ({result.total_checks || (result.failed_checks?.length || 0) + (result.passed_checks?.length || 0)} Total)
            </h3>
            
            <div className="space-y-2">
              {result.failed_checks && result.failed_checks.map((fc: any, i: number) => (
                <div key={i} className="p-3 rounded-lg bg-red-950/20 border border-red-500/30 flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div className="flex-1 text-xs">
                    <div className="flex items-center justify-between font-mono font-bold text-red-300 mb-0.5">
                      <span>{fc.title}</span>
                      <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-400">{fc.severity}</span>
                    </div>
                    <p className="text-slate-300">{fc.description}</p>
                    {fc.evidence && (
                      <div className="mt-1 font-mono text-[11px] text-red-200/80 bg-red-950/40 p-1.5 rounded">
                        Evidence: {fc.evidence}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {result.passed_checks && result.passed_checks.slice(0, 4).map((pc: any, i: number) => (
                <div key={i} className="p-3 rounded-lg bg-emerald-950/15 border border-emerald-500/20 flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="flex-1 text-xs">
                    <div className="flex items-center justify-between font-mono font-semibold text-emerald-300 mb-0.5">
                      <span>{pc.title}</span>
                      <span className="text-emerald-400">PASSED</span>
                    </div>
                    <p className="text-slate-400">{pc.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recommendations Protocol */}
          {result.recommendations && result.recommendations.length > 0 && (
            <div className="p-4 rounded-xl bg-cyber-surface border border-cyber-border">
              <h4 className="text-xs uppercase font-mono tracking-wider text-cyber-cyan mb-2">
                Actionable Defense Protocol
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {result.recommendations.map((rec: string, i: number) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-cyber-cyan font-mono font-bold">[{i + 1}]</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
