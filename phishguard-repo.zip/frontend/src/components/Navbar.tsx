import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Shield,
  LayoutDashboard,
  Link2,
  MailWarning,
  Globe,
  Radio,
  History,
  FileText,
  GraduationCap,
  Settings,
  ShieldCheck,
  LogOut,
  Menu,
  X,
  User as UserIcon
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user, logout, isAdmin } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'URL Scanner', path: '/scan/url', icon: Link2 },
    { name: 'Message Scanner', path: '/scan/message', icon: MailWarning },
    { name: 'Domain Intel', path: '/domain-intel', icon: Globe },
    { name: 'Threat Intel', path: '/threat-intel', icon: Radio },
    { name: 'Scan History', path: '/history', icon: History },
    { name: 'Reports', path: '/reports', icon: FileText },
    { name: 'Awareness', path: '/awareness', icon: GraduationCap },
  ];

  if (isAdmin) {
    navLinks.push({ name: 'Admin Console', path: '/admin', icon: ShieldCheck });
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b border-cyber-border/80 bg-cyber-bg/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to={user ? "/dashboard" : "/"} className="flex items-center gap-2.5 group">
            <div className="relative p-2 rounded-xl bg-cyber-card border border-cyber-cyan/40 group-hover:border-cyber-cyan group-hover:shadow-neon-cyan transition-all">
              <Shield className="w-5 h-5 text-cyber-cyan" />
              <div className="absolute inset-0 rounded-xl bg-cyber-cyan/10 blur-sm" />
            </div>
            <div className="flex flex-col">
              <span className="font-mono font-extrabold text-base tracking-wider text-white flex items-center gap-1">
                PHISH<span className="text-cyber-cyan">GUARD</span>
              </span>
              <span className="text-[9px] font-mono text-cyber-muted tracking-widest uppercase">
                Threat Intelligence
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          {user && (
            <nav className="hidden xl:flex items-center space-x-1">
              {navLinks.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.path);
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
                      active
                        ? 'bg-cyber-cyan/15 text-cyber-cyan border border-cyber-cyan/40 shadow-sm'
                        : 'text-slate-300 hover:text-white hover:bg-cyber-surface'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </nav>
          )}

          {/* Right Side User Menu / Auth Controls */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-2">
                <Link
                  to="/profile"
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono transition-all ${
                    isActive('/profile')
                      ? 'border-cyber-cyan text-cyber-cyan bg-cyber-cyan/10'
                      : 'border-cyber-border text-slate-300 hover:border-slate-500 bg-cyber-card'
                  }`}
                >
                  <UserIcon className="w-3.5 h-3.5 text-cyber-cyan" />
                  <span className="max-w-[110px] truncate">{user.name}</span>
                  {user.role === 'admin' && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold uppercase">
                      Admin
                    </span>
                  )}
                </Link>

                <button
                  onClick={handleLogout}
                  title="Sign Out"
                  className="p-2 rounded-lg border border-cyber-border hover:border-red-500/50 hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  to="/login"
                  className="px-4 py-2 rounded-lg text-xs font-mono text-slate-300 hover:text-white transition-colors"
                >
                  Sign In
                </Link>
                <Link
                  to="/register"
                  className="px-4 py-2 rounded-lg bg-cyber-cyan/10 border border-cyber-cyan text-cyber-cyan hover:bg-cyber-cyan hover:text-black font-mono text-xs font-bold transition-all shadow-neon-cyan"
                >
                  Deploy Shield
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex xl:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-cyber-card border border-cyber-border text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-cyber-surface border-b border-cyber-border px-4 pt-3 pb-5 space-y-1">
          {user ? (
            <>
              <div className="p-3 mb-3 rounded-lg bg-cyber-card border border-cyber-border flex items-center justify-between">
                <div>
                  <div className="font-mono text-xs font-bold text-white">{user.name}</div>
                  <div className="font-mono text-[11px] text-cyber-muted truncate">{user.email}</div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyber-cyan/20 text-cyber-cyan uppercase font-mono">
                  {user.role}
                </span>
              </div>

              {navLinks.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.path);
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-mono ${
                      active ? 'bg-cyber-cyan/20 text-cyber-cyan' : 'text-slate-300 hover:bg-cyber-card'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.name}</span>
                  </Link>
                );
              })}

              <Link
                to="/profile"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-mono text-slate-300 hover:bg-cyber-card"
              >
                <Settings className="w-4 h-4 text-cyber-cyan" />
                <span>Account Settings</span>
              </Link>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleLogout();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-mono text-red-400 hover:bg-red-500/10 mt-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </>
          ) : (
            <div className="space-y-2 pt-2">
              <Link
                to="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="block text-center py-2 rounded-lg bg-cyber-card border border-cyber-border text-xs font-mono text-white"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                onClick={() => setMobileMenuOpen(false)}
                className="block text-center py-2 rounded-lg bg-cyber-cyan text-black font-bold text-xs font-mono"
              >
                Deploy Shield
              </Link>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
