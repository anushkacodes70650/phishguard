import React from 'react';
import { Shield, Lock, Terminal, Activity } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-cyber-border/70 bg-cyber-bg/95 py-12 px-4 sm:px-6 lg:px-8 text-xs font-mono text-slate-400">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand identity */}
        <div className="md:col-span-2 space-y-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-cyber-card border border-cyber-cyan/30 text-cyber-cyan">
              <Shield className="w-4 h-4" />
            </div>
            <span className="font-extrabold text-sm tracking-wider text-white">
              PHISH<span className="text-cyber-cyan">GUARD</span>
            </span>
          </div>
          <p className="text-slate-400 text-xs max-w-md leading-relaxed font-sans">
            "Think Before You Click." Next-generation cybersecurity telemetry and heuristic inspection engine. Empowering individuals and security operations centers to neutralize social engineering and phishing before breach execution.
          </p>
          <div className="flex items-center gap-2 text-[11px] text-cyber-cyan">
            <Activity className="w-3.5 h-3.5 text-cyber-success animate-pulse" />
            <span>Detection Engine: Active // Strict SSRF Boundary Enforced</span>
          </div>
        </div>

        {/* Core Detection Engines */}
        <div>
          <h4 className="text-white uppercase font-bold tracking-wider mb-3 flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-cyber-cyan" /> Capabilities
          </h4>
          <ul className="space-y-2 text-slate-400 text-[11px]">
            <li>URL Lexical & Entropy Analysis</li>
            <li>Homoglyph / Punycode Spoof Trap</li>
            <li>Social Engineering NLP Extraction</li>
            <li>Automated SSRF Infrastructure Guard</li>
            <li>Enterprise Forensic PDF Generator</li>
          </ul>
        </div>

        {/* Security & Threat Feeds */}
        <div>
          <h4 className="text-white uppercase font-bold tracking-wider mb-3 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-cyber-purple" /> Threat Intel
          </h4>
          <ul className="space-y-2 text-slate-400 text-[11px]">
            <li>URLhaus Malware Feed</li>
            <li>PhishTank Community Database</li>
            <li>Google Safe Browsing Bridge</li>
            <li>VirusTotal Telemetry Adapter</li>
            <li>PhishGuard Sensor Network</li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-cyber-border/40 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500">
        <div>
          &copy; {new Date().getFullYear()} PHISHGUARD CYBERSECURITY PLATFORM. ALL RIGHTS RESERVED.
        </div>
        <div className="flex items-center gap-4 mt-2 sm:mt-0">
          <span>CLASSIFICATION: OPERATIONAL DEFENSE</span>
          <span>ZERO-TRUST INTEGRITY</span>
        </div>
      </div>
    </footer>
  );
};
