export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  organization?: string;
  is_active: boolean;
  created_at: string;
  last_login?: string;
}

export interface SecurityCheckItem {
  id: string;
  title: string;
  category: string;
  passed: boolean;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  evidence?: string;
}

export interface PsychologicalTrigger {
  category: string;
  severity: string;
  occurrences: number;
  matched_phrases: string[];
  explanation: string;
}

export interface SuspiciousSpan {
  start: number;
  end: number;
  text: string;
  category: string;
  severity: string;
}

export interface ScanResult {
  id?: string;
  risk_score: number;
  risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  target?: string;
  hostname?: string;
  scheme?: string;
  entropy?: number;
  summary: string;
  total_checks?: number;
  passed_count?: number;
  failed_count?: number;
  passed_checks?: SecurityCheckItem[];
  failed_checks?: SecurityCheckItem[];
  reasons: string[];
  recommendations: string[];
  // Message scan extras
  psychological_triggers?: PsychologicalTrigger[];
  suspicious_spans?: SuspiciousSpan[];
  embedded_urls?: Array<{
    url: string;
    risk_score: number;
    risk_level: string;
    summary: string;
  }>;
  // Domain scan extras
  domain?: string;
  dns?: {
    a_records: string[];
    mx_records: string[];
    ns_records: string[];
    has_spf: boolean;
    dns_resolved: boolean;
  };
  ssl?: {
    ssl_active: boolean;
    issuer: string;
    subject: string;
    valid_from?: string;
    valid_to?: string;
    days_remaining: number;
    is_expired: boolean;
  };
  metadata?: Record<string, any>;
}

export interface ScanRecord {
  id: string;
  scan_type: 'url' | 'message' | 'domain';
  input_value: string;
  target_display?: string;
  risk_score: number;
  risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  summary?: string;
  created_at: string;
  result?: ScanResult;
}

export interface ThreatItem {
  id: string;
  indicator: string;
  threat_type: string;
  source: string;
  confidence: number;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  tags: string[];
  first_seen: string;
  last_seen: string;
}

export interface ThreatStats {
  total_threats: number;
  phishing_count: number;
  impersonation_count: number;
  malware_c2_count: number;
  social_eng_count: number;
  active_feeds: number;
}

export interface IntelligenceProvider {
  id: string;
  name: string;
  configured: boolean;
  status: string;
  capabilities: string[];
  notice: string;
}

export interface DashboardOverview {
  total_scans: number;
  safe_scans: number;
  suspicious_scans: number;
  critical_threats: number;
  engine_accuracy: number;
  health_score: number;
  health_status: string;
}

export interface DashboardAnalytics {
  activity_chart: Array<{
    date: string;
    total: number;
    threats: number;
    safe: number;
    suspicious: number;
  }>;
  distribution_chart: Array<{
    name: string;
    value: number;
  }>;
}

export interface SecurityReport {
  id: string;
  scan_id: string;
  report_code: string;
  report_name: string;
  file_size_bytes: number;
  created_at: string;
}

export interface UserSettings {
  theme: string;
  notifications_enabled: boolean;
  deep_analysis_enabled: boolean;
  auto_export_pdf: boolean;
  email_alerts: boolean;
  updated_at: string;
}

export interface AwarenessModule {
  id: string;
  title: string;
  badge: string;
  category: string;
  reading_time: string;
  summary: string;
  content: Array<{ subheading: string; body: string }>;
  quiz: Array<{
    question: string;
    options: string[];
    correct_index: number;
    explanation: string;
  }>;
  user_score?: number;
  user_passed?: boolean;
}
