import React, { useState, useEffect } from 'react';
import {
  History,
  Search,
  Filter,
  Trash2,
  Eye,
  FileDown,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import api from '../services/api';
import { ScanRecord } from '../types';
import { ScanDetailModal } from '../components/ScanDetailModal';

export const ScanHistoryPage: React.FC = () => {
  const [scans, setScans] = useState<ScanRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [scanType, setScanType] = useState('all');
  const [riskLevel, setRiskLevel] = useState('ALL');
  const [sortBy, setSortBy] = useState('created_at');
  const [order, setOrder] = useState('desc');
  const [loading, setLoading] = useState(true);
  const [selectedScan, setSelectedScan] = useState<any>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      const res = await api.get(
        `/history?search=${encodeURIComponent(search)}&scan_type=${scanType}&risk_level=${riskLevel}&sort_by=${sortBy}&order=${order}&page=${page}&limit=10`
      );
      setScans(res.data.items);
      setTotal(res.data.total);
      setTotalPages(res.data.total_pages || 1);
    } catch (err) {
      console.error('Failed to load scan history', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [page, scanType, riskLevel, sortBy, order]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchHistory();
  };

  const handleOpenDetail = async (id: string) => {
    try {
      const res = await api.get(`/history/${id}`);
      setSelectedScan(res.data);
      setModalOpen(true);
    } catch (err) {
      console.error('Failed to load scan record', err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to permanently delete this scan record?')) return;
    try {
      await api.delete(`/history/${id}`);
      fetchHistory();
    } catch (err) {
      console.error('Failed to delete scan', err);
    }
  };

  const handleExport = async (format: 'csv' | 'json') => {
    try {
      const res = await api.get(`/history/export?format=${format}`, {
        responseType: format === 'csv' ? 'blob' : 'json'
      });

      if (format === 'csv') {
        const url = window.URL.createObjectURL(new Blob([res.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `phishguard_scans_${Date.now()}.csv`);
        document.body.appendChild(link);
        link.click();
        link.remove();
      } else {
        const jsonStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(res.data, null, 2));
        const link = document.createElement('a');
        link.href = jsonStr;
        link.setAttribute('download', `phishguard_scans_${Date.now()}.json`);
        document.body.appendChild(link);
        link.click();
        link.remove();
      }
    } catch (err) {
      console.error('Failed to export history', err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyber-cyan uppercase tracking-widest">
            <History className="w-4 h-4" />
            <span>Telemetry Archive</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
            Forensic Scan History
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
            Secure, encrypted record of all inspected URLs, domains, and communication payloads.
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleExport('csv')}
            className="px-3 py-2 rounded-xl bg-cyber-card border border-cyber-border hover:border-cyber-cyan text-xs font-mono text-slate-300 hover:text-cyber-cyan transition-colors flex items-center gap-1.5"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => handleExport('json')}
            className="px-3 py-2 rounded-xl bg-cyber-card border border-cyber-border hover:border-cyber-cyan text-xs font-mono text-slate-300 hover:text-cyber-cyan transition-colors flex items-center gap-1.5"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-cyber-card border border-cyber-border flex flex-col md:flex-row items-center justify-between gap-4">
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search targets or summaries..."
            className="w-full bg-cyber-surface border border-cyber-border rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan"
          />
        </form>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <select
            value={scanType}
            onChange={(e) => { setScanType(e.target.value); setPage(1); }}
            className="bg-cyber-surface border border-cyber-border rounded-lg px-3 py-2 text-xs font-mono text-slate-300 focus:outline-none"
          >
            <option value="all">All Types</option>
            <option value="url">URLs Only</option>
            <option value="message">Messages Only</option>
            <option value="domain">Domains Only</option>
          </select>

          <select
            value={riskLevel}
            onChange={(e) => { setRiskLevel(e.target.value); setPage(1); }}
            className="bg-cyber-surface border border-cyber-border rounded-lg px-3 py-2 text-xs font-mono text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Threat Levels</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low (Clean)</option>
          </select>

          <button
            onClick={() => setOrder(order === 'asc' ? 'desc' : 'asc')}
            className="px-3 py-2 rounded-lg bg-cyber-surface border border-cyber-border text-xs font-mono text-slate-300 hover:text-white flex items-center gap-1.5"
            title="Toggle sort order"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span>{order.toUpperCase()}</span>
          </button>
        </div>
      </div>

      {/* History Table */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
        {loading ? (
          <div className="py-12 text-center text-xs font-mono text-cyber-cyan flex flex-col items-center gap-2">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span>Querying archive records...</span>
          </div>
        ) : scans.length === 0 ? (
          <div className="py-10 text-center text-xs font-mono text-slate-500">
            No scan records matched your filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="border-b border-cyber-border text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Inspection Target</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Score</th>
                  <th className="py-3 px-4">Verdict</th>
                  <th className="py-3 px-4">Timestamp (UTC)</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-cyber-border/40">
                {scans.map((s) => {
                  const isCrit = s.risk_level === 'CRITICAL';
                  const isHigh = s.risk_level === 'HIGH';
                  const isMed = s.risk_level === 'MEDIUM';

                  const badgeClass = isCrit
                    ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                    : isHigh
                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                    : isMed
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40';

                  return (
                    <tr key={s.id} className="hover:bg-cyber-surface/60 transition-colors">
                      <td className="py-3.5 px-4 max-w-sm truncate text-white font-medium">
                        {s.target_display || s.input_value}
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 uppercase text-[11px]">
                        {s.scan_type}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-white">
                        {s.risk_score} <span className="text-[10px] text-slate-500 font-normal">/100</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${badgeClass}`}>
                          {s.risk_level}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                        {new Date(s.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                      <td className="py-3.5 px-4 text-right space-x-2">
                        <button
                          onClick={() => handleOpenDetail(s.id)}
                          className="p-1.5 rounded bg-cyber-surface hover:bg-cyber-cyan/20 border border-cyber-border hover:border-cyber-cyan text-slate-300 hover:text-cyber-cyan transition-colors"
                          title="View Forensic Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(s.id)}
                          className="p-1.5 rounded bg-cyber-surface hover:bg-red-500/20 border border-cyber-border hover:border-red-500 text-slate-400 hover:text-red-400 transition-colors"
                          title="Delete Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Controls */}
        <div className="flex items-center justify-between pt-4 border-t border-cyber-border/60 text-xs font-mono text-slate-400">
          <div>
            Showing {(page - 1) * 10 + (scans.length > 0 ? 1 : 0)} - {Math.min(page * 10, total)} of {total} records
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-1.5 rounded-lg border border-cyber-border hover:border-slate-500 disabled:opacity-30 disabled:pointer-events-none"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span>Page {page} of {totalPages}</span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-1.5 rounded-lg border border-cyber-border hover:border-slate-500 disabled:opacity-30 disabled:pointer-events-none"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Details Modal */}
      <ScanDetailModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        scanData={selectedScan}
      />
    </div>
  );
};
