import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Users,
  Activity,
  Server,
  Cpu,
  Layers,
  Lock,
  Loader2,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [overview, setOverview] = useState<any>(null);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [health, setHealth] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      setError(null);
      const [overRes, usersRes, healthRes] = await Promise.all([
        api.get('/admin/overview'),
        api.get('/admin/users'),
        api.get('/admin/system-health')
      ]);
      setOverview(overRes.data);
      setUsersList(usersRes.data);
      setHealth(healthRes.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to retrieve administrative telemetry.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleRoleToggle = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    try {
      await api.put(`/admin/users/${userId}/role?role=${newRole}`);
      await fetchAdminData();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to change role');
    }
  };

  if (loading && !overview) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-purple-400 font-mono">
        <Loader2 className="w-8 h-8 animate-spin mb-3" />
        <span>Authenticating administrative console...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="p-8 rounded-2xl bg-red-950/30 border border-red-500/40 text-red-300 font-mono space-y-3">
          <AlertTriangle className="w-10 h-10 text-red-400 mx-auto" />
          <h2 className="text-xl font-bold uppercase">Restricted Administrative Area</h2>
          <p className="text-xs text-slate-300 font-sans">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-purple-400 uppercase tracking-widest">
            <ShieldCheck className="w-4 h-4" />
            <span>Master Governance & Access Control</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
            Administrative Command Terminal
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
            System-wide operator registry, database telemetry, and detection engine rule enforcement.
          </p>
        </div>

        <button
          onClick={fetchAdminData}
          className="p-2.5 rounded-xl bg-cyber-card border border-cyber-border hover:border-purple-500 text-slate-300 hover:text-purple-300 transition-colors flex items-center gap-2 text-xs font-mono"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Sync Registry</span>
        </button>
      </div>

      {/* Global Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono">
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border">
          <span className="text-[10px] text-slate-500 uppercase block">Registered Operators</span>
          <span className="text-3xl font-extrabold text-white mt-1 block">{overview?.total_users ?? 0}</span>
        </div>
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border">
          <span className="text-[10px] text-slate-500 uppercase block">Systemwide Scans</span>
          <span className="text-3xl font-extrabold text-cyber-cyan mt-1 block">{overview?.total_scans ?? 0}</span>
        </div>
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border">
          <span className="text-[10px] text-slate-500 uppercase block">Active Threat Catalog</span>
          <span className="text-3xl font-extrabold text-red-400 mt-1 block">{overview?.total_threats ?? 0}</span>
        </div>
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border">
          <span className="text-[10px] text-slate-500 uppercase block">Generated Dossiers</span>
          <span className="text-3xl font-extrabold text-emerald-400 mt-1 block">{overview?.total_reports ?? 0}</span>
        </div>
      </div>

      {/* Engine Status & System Health */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
          <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-purple-400" /> Detection Engine Architecture
          </h3>
          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">Core Engine:</span>
              <span className="text-white font-semibold">{overview?.engine_status?.version}</span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">Operational State:</span>
              <span className="text-emerald-400 font-semibold">{overview?.engine_status?.status}</span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">Enforced Heuristic Rules:</span>
              <span className="text-cyber-cyan font-semibold">{overview?.engine_status?.active_rules} Rulesets</span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">SSRF Isolation Defense:</span>
              <span className="text-emerald-400 font-semibold">{overview?.engine_status?.ssrf_protection}</span>
            </div>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
          <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
            <Server className="w-4 h-4 text-cyber-cyan" /> Infrastructure Diagnostics
          </h3>
          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">Service Status:</span>
              <span className="text-emerald-400 font-semibold">{health?.status}</span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">Database Layer:</span>
              <span className="text-white font-semibold">{health?.database}</span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">Python Runtime:</span>
              <span className="text-cyber-cyan font-semibold">{health?.python_version}</span>
            </div>
            <div className="flex justify-between p-2.5 rounded bg-cyber-surface border border-cyber-border">
              <span className="text-slate-400">Platform OS:</span>
              <span className="text-slate-300 font-semibold truncate max-w-[200px]">{health?.platform}</span>
            </div>
          </div>
        </div>
      </div>

      {/* User Management Table */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
        <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
          <Users className="w-4 h-4 text-purple-400" /> Operator Registry & Access Levels ({usersList.length})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="border-b border-cyber-border text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="py-3 px-4">Operator Name</th>
                <th className="py-3 px-4">Email Address</th>
                <th className="py-3 px-4">Organization</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Total Scans</th>
                <th className="py-3 px-4">Registered</th>
                <th className="py-3 px-4 text-right">Access Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cyber-border/40">
              {usersList.map((u) => (
                <tr key={u.id} className="hover:bg-cyber-surface/60 transition-colors">
                  <td className="py-3 px-4 font-bold text-white">
                    {u.name}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {u.email}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {u.organization || 'Independent'}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      u.role === 'admin'
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                        : 'bg-slate-700 text-slate-300'
                    }`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-cyber-cyan font-bold">
                    {u.total_scans}
                  </td>
                  <td className="py-3 px-4 text-slate-400 text-[11px]">
                    {new Date(u.created_at).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {u.id !== user?.id && (
                      <button
                        onClick={() => handleRoleToggle(u.id, u.role)}
                        className="px-2.5 py-1 rounded bg-cyber-surface hover:bg-purple-500/20 border border-cyber-border hover:border-purple-500 text-purple-300 text-[11px] transition-colors"
                      >
                        Toggle {u.role === 'admin' ? 'to User' : 'to Admin'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
