import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Shield, Lock, Mail, ArrowRight, AlertCircle, Loader2, KeyRound } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Quick fill pre-seeded demo accounts
  const fillCredentials = (userType: 'analyst' | 'admin') => {
    if (userType === 'analyst') {
      setEmail('analyst@phishguard.ai');
      setPassword('Analyst@PhishGuard2026!');
    } else {
      setEmail('admin@phishguard.ai');
      setPassword('Admin@PhishGuard2026!');
    }
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please input your email address and password.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      await login(email, password);
      const redirect = location.state?.redirectUrl || '/dashboard';
      navigate(redirect);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Authentication failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 cyber-grid-bg">
      <div className="w-full max-w-md space-y-6">
        {/* Top Emblem */}
        <div className="text-center">
          <div className="inline-flex p-3 rounded-2xl bg-cyber-card border border-cyber-cyan/40 shadow-neon-cyan mb-3">
            <Shield className="w-8 h-8 text-cyber-cyan" />
          </div>
          <h2 className="text-2xl font-mono font-extrabold text-white uppercase tracking-wider">
            Operator Authentication
          </h2>
          <p className="text-xs text-cyber-muted font-mono mt-1">
            Access PhishGuard Defense Command Center
          </p>
        </div>

        {/* Demo Fast-Fill Bar */}
        <div className="p-3.5 rounded-xl bg-cyber-card/80 border border-cyber-border space-y-2">
          <div className="text-[11px] font-mono text-cyber-cyan flex items-center gap-1.5">
            <KeyRound className="w-3.5 h-3.5" />
            <span>Instant Demo Credentials</span>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => fillCredentials('analyst')}
              className="flex-1 py-1.5 px-2 rounded-lg bg-cyber-surface hover:bg-cyber-cyan/15 border border-cyber-border hover:border-cyber-cyan/40 text-[11px] font-mono text-slate-300 hover:text-cyber-cyan transition-all text-center"
            >
              Analyst Account
            </button>
            <button
              type="button"
              onClick={() => fillCredentials('admin')}
              className="flex-1 py-1.5 px-2 rounded-lg bg-cyber-surface hover:bg-purple-500/15 border border-cyber-border hover:border-purple-500/40 text-[11px] font-mono text-slate-300 hover:text-purple-300 transition-all text-center"
            >
              Admin Console
            </button>
          </div>
        </div>

        {/* Form Container */}
        <div className="p-8 rounded-2xl bg-cyber-card border border-cyber-border shadow-2xl">
          {error && (
            <div className="mb-5 p-3 rounded-xl bg-red-950/40 border border-red-500/40 flex items-start gap-2.5 text-xs text-red-200">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="analyst@phishguard.ai"
                  required
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-10 pr-3 py-2.5 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-10 pr-3 py-2.5 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 rounded-xl bg-cyber-cyan hover:bg-cyan-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-neon-cyan disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Validating Key...</span>
                </>
              ) : (
                <>
                  <span>Authenticate Session</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-cyber-border/60 text-center text-xs font-mono text-slate-400">
            Need an account?{' '}
            <Link to="/register" className="text-cyber-cyan hover:underline font-semibold">
              Register New Agent
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
