import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Radio,
  Search,
  Filter,
  ShieldAlert,
  Flame,
  Globe,
  Database,
  ExternalLink,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Loader2
} from 'lucide-react';
import api from '../services/api';
import { ThreatItem, ThreatStats, IntelligenceProvider } from '../types';

export const ThreatIntelPage: React.FC = () => {
  const [threats, setThreats] = useState<ThreatItem[]>([]);
  const [stats, setStats] = useState<ThreatStats | null>(null);
  const [providers, setProviders] = useState<IntelligenceProvider[]>([]);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);

  const fetchThreatData = async () => {
    try {
      setLoading(true);
      const [threatsRes, statsRes, provRes] = await Promise.all([
        api.get(`/threats?search=${encodeURIComponent(search)}&threat_type=${categoryFilter}&severity=${severityFilter}&limit=25`),
        api.get('/threats/statistics'),
        api.get('/threats/providers')
      ]);
      setThreats(threatsRes.data.items);
      setStats(statsRes.data);
      setProviders(provRes.data);
    } catch (err) {
      console.error('Failed to load threat intelligence', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchThreatData();
  }, [categoryFilter, severityFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchThreatData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-widest">
            <Radio className="w-4 h-4 animate-pulse" />
            <span>Global Threat Surveillance</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
            Cyber Threat Intelligence Feed
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
            Curated high-confidence phishing indicators, malicious C2 infrastructure, and active credential harvesting campaigns.
          </p>
        </div>

        <button
          onClick={fetchThreatData}
          className="p-2.5 rounded-xl bg-cyber-card border border-cyber-border hover:border-amber-400 text-slate-300 hover:text-amber-400 transition-colors flex items-center gap-2 text-xs font-mono"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Refresh Indicators</span>
        </button>
      </div>

      {/* Intelligence Providers Status Card */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
        <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
          <Database className="w-4 h-4 text-cyber-cyan" /> Intelligence Integrations & Providers Status
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {providers.map((p) => {
            const isActive = p.status === 'ACTIVE';
            return (
              <div key={p.id} className="p-4 rounded-xl bg-cyber-surface border border-cyber-border flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono font-bold text-xs text-white truncate max-w-[150px]">{p.name}</span>
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase ${
                      isActive ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-700 text-slate-300'
                    }`}>
                      {p.status}
                    </span>
                  </div>
                  <div className="text-[11px] font-sans text-slate-400 mb-2">
                    {p.notice}
                  </div>
                </div>
                <div className="flex flex-wrap gap-1 text-[9px] font-mono text-cyber-cyan">
                  {p.capabilities.map((c) => (
                    <span key={c} className="px-1.5 py-0.5 rounded bg-cyber-card border border-cyber-border/70">
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stats Counters */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 text-center font-mono">
          <div className="p-4 rounded-xl bg-cyber-card border border-cyber-border">
            <span className="text-[10px] text-slate-500 uppercase block">Total Indicators</span>
            <span className="text-2xl font-extrabold text-white mt-1 block">{stats.total_threats}</span>
          </div>
          <div className="p-4 rounded-xl bg-cyber-card border border-cyber-border">
            <span className="text-[10px] text-slate-500 uppercase block">Phishing Lures</span>
            <span className="text-2xl font-extrabold text-red-400 mt-1 block">{stats.phishing_count}</span>
          </div>
          <div className="p-4 rounded-xl bg-cyber-card border border-cyber-border">
            <span className="text-[10px] text-slate-500 uppercase block">Brand Spoofs</span>
            <span className="text-2xl font-extrabold text-amber-400 mt-1 block">{stats.impersonation_count}</span>
          </div>
          <div className="p-4 rounded-xl bg-cyber-card border border-cyber-border">
            <span className="text-[10px] text-slate-500 uppercase block">C2 & Malware</span>
            <span className="text-2xl font-extrabold text-purple-400 mt-1 block">{stats.malware_c2_count}</span>
          </div>
          <div className="p-4 rounded-xl bg-cyber-card border border-cyber-border">
            <span className="text-[10px] text-slate-500 uppercase block">Active Feeds</span>
            <span className="text-2xl font-extrabold text-cyber-cyan mt-1 block">{stats.active_feeds}</span>
          </div>
        </div>
      )}

      {/* Search & Filter Bar */}
      <div className="p-4 rounded-xl bg-cyber-card border border-cyber-border flex flex-col md:flex-row items-center justify-between gap-4">
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search indicator, source, or keyword..."
            className="w-full bg-cyber-surface border border-cyber-border rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-amber-400"
          />
        </form>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-cyber-surface border border-cyber-border rounded-lg px-3 py-2 text-xs font-mono text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Categories</option>
            <option value="Phishing">Phishing</option>
            <option value="Brand Impersonation">Brand Spoofing</option>
            <option value="Credential">Credential Harvester</option>
            <option value="Crypto">Crypto Phishing</option>
          </select>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="bg-cyber-surface border border-cyber-border rounded-lg px-3 py-2 text-xs font-mono text-slate-300 focus:outline-none"
          >
            <option value="ALL">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
          </select>
        </div>
      </div>

      {/* Threat Feed Table */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border">
        {loading ? (
          <div className="py-12 text-center text-xs font-mono text-amber-400 flex flex-col items-center gap-2">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span>Querying active threat sensors...</span>
          </div>
        ) : threats.length === 0 ? (
          <div className="py-10 text-center text-xs font-mono text-slate-500">
            No threat indicators matched your search parameters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="border-b border-cyber-border text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Threat Indicator</th>
                  <th className="py-3 px-4">Threat Category</th>
                  <th className="py-3 px-4">Feed Source</th>
                  <th className="py-3 px-4">Confidence</th>
                  <th className="py-3 px-4">Severity</th>
                  <th className="py-3 px-4">Tags</th>
                  <th className="py-3 px-4">Last Observed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-cyber-border/40">
                {threats.map((t) => {
                  const isCrit = t.severity === 'CRITICAL';
                  const isHigh = t.severity === 'HIGH';
                  return (
                    <tr key={t.id} className="hover:bg-cyber-surface/60 transition-colors">
                      <td className="py-3 px-4 font-bold text-white max-w-xs truncate">
                        {t.indicator}
                      </td>
                      <td className="py-3 px-4 text-slate-300">
                        {t.threat_type}
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        {t.source}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-cyber-cyan">
                        {t.confidence}%
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isCrit
                            ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                            : isHigh
                            ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                            : 'bg-amber-500/20 text-amber-400'
                        }`}>
                          {t.severity}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[10px] text-slate-400">
                        {Array.isArray(t.tags) ? t.tags.slice(0, 2).join(', ') : t.tags}
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        {new Date(t.last_seen).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
