import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Globe,
  Search,
  RotateCcw,
  Shield,
  ShieldAlert,
  Server,
  Lock,
  Mail,
  AlertTriangle,
  CheckCircle2,
  FileDown,
  Loader2,
  Copy,
  Check
} from 'lucide-react';
import api from '../services/api';
import { RiskGauge } from '../components/RiskGauge';

export const DomainIntelPage: React.FC = () => {
  const [domainInput, setDomainInput] = useState('paypal-security-update.xyz');
  const [loading, setLoading] = useState(false);
  const [domainData, setDomainData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleAnalyze = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!domainInput.trim()) {
      setError('Please provide a domain name (e.g. example.com).');
      return;
    }

    try {
      setError(null);
      setLoading(true);
      setDomainData(null);

      const res = await api.post('/domain/analyze', { domain: domainInput.trim() });
      setDomainData(res.data.result);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Domain analysis failed. Please verify the domain.');
    } finally {
      setLoading(false);
    }
  };

  const copyDomainData = () => {
    if (!domainData) return;
    navigator.clipboard.writeText(JSON.stringify(domainData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-mono text-cyber-cyan uppercase tracking-widest">
          <Globe className="w-4 h-4" />
          <span>Infrastructure Intelligence</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
          Domain Reputation & DNS Forensics
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
          Safely probe DNS records, verify TLS certificate authority, detect Cyrillic IDN homoglyphs, and evaluate namespace reputation without executing remote browser code.
        </p>
      </div>

      {/* Input Box */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4 shadow-xl">
        <form onSubmit={handleAnalyze} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={domainInput}
              onChange={(e) => setDomainInput(e.target.value)}
              placeholder="Enter domain (e.g. paypal-security-update.xyz or github.com)..."
              className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-4 pr-24 py-3.5 text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyber-cyan transition-colors"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono text-slate-400 mr-1">Quick Probe:</span>
              {['paypal-security-update.xyz', 'github.com', 'google.com', 'apple-support-verify.buzz'].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDomainInput(d)}
                  className="px-2.5 py-1 rounded-lg bg-cyber-surface hover:bg-cyber-card border border-cyber-border text-[11px] font-mono text-slate-300 hover:text-cyber-cyan transition-colors"
                >
                  {d}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => { setDomainInput(''); setDomainData(null); setError(null); }}
                className="px-4 py-2.5 rounded-xl border border-cyber-border text-slate-400 hover:text-white font-mono text-xs transition-colors flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2.5 rounded-xl bg-cyber-cyan hover:bg-cyan-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-neon-cyan flex items-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Resolving DNS...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Query Domain</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {error && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/40 text-xs text-red-200 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Domain Analysis Results */}
      {domainData && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Top Verdict Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 rounded-2xl bg-cyber-card border border-cyber-border">
            <div className="lg:col-span-4 flex flex-col items-center justify-center p-4 border-b lg:border-b-0 lg:border-r border-cyber-border/70">
              <RiskGauge score={domainData.risk_score} level={domainData.risk_level} size={180} />
            </div>

            <div className="lg:col-span-8 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase tracking-wider text-cyber-cyan">
                    Domain Assessment // {domainData.domain}
                  </span>
                  <button
                    onClick={copyDomainData}
                    className="p-1.5 rounded-lg bg-cyber-surface hover:bg-cyber-border text-slate-400 hover:text-white transition-colors"
                    title="Copy Raw JSON"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-cyber-success" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <h3 className="text-lg font-mono font-bold text-white mt-1">
                  {domainData.summary}
                </h3>
              </div>

              {/* Attributes */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">TLD</span>
                  <span className="text-slate-200 block font-semibold">.{domainData.tld || 'unknown'}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">Entropy</span>
                  <span className="text-slate-200 block font-semibold">{domainData.entropy}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">SPF Policy</span>
                  <span className={`block font-semibold ${domainData.dns?.has_spf ? 'text-cyber-success' : 'text-amber-400'}`}>
                    {domainData.dns?.has_spf ? 'CONFIGURED' : 'MISSING'}
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">TLS Active</span>
                  <span className={`block font-semibold ${domainData.ssl?.ssl_active ? 'text-cyber-success' : 'text-slate-400'}`}>
                    {domainData.ssl?.ssl_active ? 'PORT 443 OPEN' : 'INACTIVE'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* DNS & SSL Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* DNS Records */}
            <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
              <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <Server className="w-4 h-4 text-cyber-cyan" /> DNS Routing Records
              </h4>
              <div className="space-y-3 text-xs font-mono">
                <div>
                  <span className="text-slate-500 uppercase text-[10px] block mb-1">A Records (IPv4)</span>
                  {domainData.dns?.a_records?.length ? (
                    <div className="flex flex-wrap gap-1.5">
                      {domainData.dns.a_records.map((ip: string) => (
                        <span key={ip} className="px-2 py-0.5 rounded bg-cyber-surface border border-cyber-border text-slate-200">
                          {ip}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-slate-500">No A records resolved.</span>
                  )}
                </div>

                <div>
                  <span className="text-slate-500 uppercase text-[10px] block mb-1">MX Records (Mail Exchangers)</span>
                  {domainData.dns?.mx_records?.length ? (
                    <div className="flex flex-wrap gap-1.5">
                      {domainData.dns.mx_records.map((mx: string) => (
                        <span key={mx} className="px-2 py-0.5 rounded bg-cyber-surface border border-cyber-border text-slate-200">
                          {mx}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-slate-500">No MX records configured.</span>
                  )}
                </div>

                <div>
                  <span className="text-slate-500 uppercase text-[10px] block mb-1">NS Records (Authoritative Nameservers)</span>
                  {domainData.dns?.ns_records?.length ? (
                    <div className="flex flex-wrap gap-1.5">
                      {domainData.dns.ns_records.map((ns: string) => (
                        <span key={ns} className="px-2 py-0.5 rounded bg-cyber-surface border border-cyber-border text-slate-200">
                          {ns}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-slate-500">No NS records returned.</span>
                  )}
                </div>
              </div>
            </div>

            {/* SSL / TLS Certificate Info */}
            <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
              <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <Lock className="w-4 h-4 text-cyber-purple" /> TLS Handshake Certificate
              </h4>
              <div className="space-y-3 text-xs font-mono">
                <div>
                  <span className="text-slate-500 uppercase text-[10px] block">Certificate Authority / Issuer</span>
                  <span className="text-slate-200 font-semibold block mt-0.5">{domainData.ssl?.issuer || 'None'}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase text-[10px] block">Certificate Subject</span>
                  <span className="text-slate-200 font-semibold block mt-0.5">{domainData.ssl?.subject || 'None'}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-500 uppercase text-[10px] block">Days Remaining</span>
                    <span className="text-slate-200 font-semibold block mt-0.5">{domainData.ssl?.days_remaining ?? 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 uppercase text-[10px] block">Certificate Expiration</span>
                    <span className={`font-semibold block mt-0.5 ${domainData.ssl?.is_expired ? 'text-red-400' : 'text-cyber-success'}`}>
                      {domainData.ssl?.is_expired ? 'EXPIRED' : 'VALID'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Forensic Checks */}
          <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-3">
            <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider">
              Domain Security Gates
            </h4>
            <div className="space-y-2">
              {domainData.checks && domainData.checks.map((chk: any, i: number) => (
                <div
                  key={i}
                  className={`p-3 rounded-xl border flex items-start gap-3 ${
                    chk.passed
                      ? 'bg-emerald-950/15 border-emerald-500/20'
                      : 'bg-red-950/20 border-red-500/30'
                  }`}
                >
                  {chk.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 text-xs">
                    <div className="flex items-center justify-between font-mono font-bold">
                      <span className={chk.passed ? 'text-emerald-300' : 'text-red-300'}>{chk.title}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded uppercase ${
                        chk.passed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {chk.passed ? 'PASSED' : chk.severity}
                      </span>
                    </div>
                    <p className="text-slate-400 font-sans mt-0.5">{chk.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};
