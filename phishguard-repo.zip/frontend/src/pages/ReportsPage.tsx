import React, { useState, useEffect } from 'react';
import {
  FileText,
  FileDown,
  Download,
  Plus,
  Shield,
  Loader2,
  CheckCircle,
  ExternalLink,
  Calendar
} from 'lucide-react';
import api from '../services/api';
import { SecurityReport, ScanRecord } from '../types';

export const ReportsPage: React.FC = () => {
  const [reports, setReports] = useState<SecurityReport[]>([]);
  const [scans, setScans] = useState<ScanRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedScanId, setSelectedScanId] = useState<string>('');
  const [generating, setGenerating] = useState(false);

  const fetchReportsAndScans = async () => {
    try {
      setLoading(true);
      const [repRes, scanRes] = await Promise.all([
        api.get('/reports'),
        api.get('/history?limit=50')
      ]);
      setReports(repRes.data);
      setScans(scanRes.data.items);
      if (scanRes.data.items.length > 0) {
        setSelectedScanId(scanRes.data.items[0].id);
      }
    } catch (err) {
      console.error('Failed to load reports', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReportsAndScans();
  }, []);

  const handleGenerateReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedScanId) return;

    try {
      setGenerating(true);
      await api.post(`/reports/generate/${selectedScanId}`);
      await fetchReportsAndScans();
    } catch (err) {
      console.error('Report generation failed', err);
      alert('Failed to generate report.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadReport = async (reportId: string, reportCode: string) => {
    try {
      const res = await api.get(`/reports/${reportId}/download`, { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${reportCode}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('Failed to download report', err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 uppercase tracking-widest">
          <FileText className="w-4 h-4" />
          <span>Cryptographic Forensic Records</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
          Forensic Security Report Generator
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
          Export tamper-evident PDF dossiers with technical evidence tables, risk scoring justifications, and remediation protocol checklists.
        </p>
      </div>

      {/* Generator Form Box */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border shadow-xl">
        <form onSubmit={handleGenerateReport} className="flex flex-col sm:flex-row items-end gap-4">
          <div className="w-full sm:flex-1 space-y-1.5">
            <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider">
              Select Scan Event to Compile Into Enterprise PDF
            </label>
            <select
              value={selectedScanId}
              onChange={(e) => setSelectedScanId(e.target.value)}
              className="w-full bg-cyber-surface border border-cyber-border rounded-xl px-4 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-emerald-400"
            >
              {scans.map((s) => (
                <option key={s.id} value={s.id}>
                  [{s.scan_type.toUpperCase()}] {s.target_display || s.input_value} — {s.risk_level} ({s.risk_score}/100)
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            disabled={generating || !selectedScanId}
            className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 shadow-sm disabled:opacity-50 shrink-0"
          >
            {generating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Compiling Dossier...</span>
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                <span>Compile Security PDF</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Reports Archive */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
        <div className="flex items-center justify-between border-b border-cyber-border pb-3">
          <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
            <FileDown className="w-4 h-4 text-emerald-400" /> Generated Enterprise PDF Reports ({reports.length})
          </h3>
        </div>

        {loading ? (
          <div className="py-12 text-center text-xs font-mono text-emerald-400 flex flex-col items-center gap-2">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span>Loading report manifests...</span>
          </div>
        ) : reports.length === 0 ? (
          <div className="py-12 text-center text-xs font-mono text-slate-500">
            No PDF reports generated yet. Select a scan event above to compile a forensic document.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {reports.map((rep) => (
              <div
                key={rep.id}
                className="p-5 rounded-xl bg-cyber-surface border border-cyber-border hover:border-emerald-500/50 transition-all flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 mb-2">
                    <span className="font-bold">{rep.report_code}</span>
                    <span className="text-slate-400">{Math.round(rep.file_size_bytes / 1024)} KB</span>
                  </div>
                  <h4 className="text-sm font-mono font-bold text-white line-clamp-2">
                    {rep.report_name}
                  </h4>
                </div>

                <div className="pt-3 border-t border-cyber-border/60 flex items-center justify-between text-xs font-mono text-slate-400">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>{new Date(rep.created_at).toLocaleDateString()}</span>
                  </div>

                  <button
                    onClick={() => handleDownloadReport(rep.id, rep.report_code)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500 border border-emerald-500/40 text-emerald-300 hover:text-black font-semibold text-xs transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
