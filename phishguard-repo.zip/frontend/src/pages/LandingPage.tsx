import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Shield,
  ArrowRight,
  Zap,
  Lock,
  Globe,
  Radio,
  FileCheck,
  Search,
  CheckCircle2,
  AlertTriangle,
  Terminal,
  Activity,
  Layers
} from 'lucide-react';
import { CyberShieldCanvas } from '../components/CyberShieldCanvas';
import { useAuth } from '../context/AuthContext';

export const LandingPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [quickInput, setQuickInput] = useState('');

  const handleQuickScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    if (user) {
      navigate('/scan/url', { state: { initialUrl: quickInput } });
    } else {
      navigate('/login', { state: { redirectUrl: '/scan/url', prefillUrl: quickInput } });
    }
  };

  const featureCards = [
    {
      icon: Search,
      title: "URL Forensic Engine",
      color: "text-cyber-cyan",
      borderColor: "border-cyber-cyan/30",
      description: "Dissects lexical entropy, homoglyph confusables, punycode spoofing, and nested subdomains with zero SSRF vulnerability."
    },
    {
      icon: Terminal,
      title: "Social Engineering NLP",
      color: "text-cyber-purple",
      borderColor: "border-cyber-purple/30",
      description: "Identifies psychological triggers including urgency pressure, credential traps, and fake executive wire instructions."
    },
    {
      icon: Radio,
      title: "Live Threat Feeds",
      color: "text-amber-400",
      borderColor: "border-amber-400/30",
      description: "Aggregates indicators from URLhaus, PhishTank, and global threat sensors to cross-reference indicators in real-time."
    },
    {
      icon: FileCheck,
      title: "Forensic PDF Dossiers",
      color: "text-emerald-400",
      borderColor: "border-emerald-400/30",
      description: "Compiles enterprise-grade cryptographic analysis reports with vector evidence tables ready for security audits."
    }
  ];

  return (
    <div className="relative min-h-screen bg-cyber-bg cyber-grid-bg overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-20 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[128px] pointer-events-none" />
      <div className="absolute top-80 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[128px] pointer-events-none" />

      {/* Hero Section */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24 lg:pt-24 lg:pb-32">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Headlines & Call to Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-7 space-y-6 text-center lg:text-left"
          >
            {/* Live Sentinel Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyber-card border border-cyber-cyan/40 text-cyber-cyan text-xs font-mono shadow-neon-cyan">
              <span className="w-2 h-2 rounded-full bg-cyber-cyan animate-ping" />
              <span>PHISHGUARD INTELLIGENCE ENGINE v2.4 ONLINE</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white uppercase font-mono leading-tight">
              THE INTERNET IS NOT ALWAYS WHAT IT SEEMS.
            </h1>

            {/* Tagline & Supporting description */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl font-sans leading-relaxed">
              Detect phishing. Understand threats. Protect your digital identity with explainable, enterprise-grade AI security analysis before breach execution.
            </p>

            {/* Interactive Quick Scan Bar */}
            <form onSubmit={handleQuickScan} className="max-w-xl">
              <div className="relative flex items-center p-1.5 bg-cyber-card border border-cyber-border rounded-xl shadow-2xl focus-within:border-cyber-cyan focus-within:shadow-neon-cyan transition-all">
                <Search className="w-5 h-5 text-slate-400 ml-3 shrink-0" />
                <input
                  type="text"
                  value={quickInput}
                  onChange={(e) => setQuickInput(e.target.value)}
                  placeholder="Paste suspicious URL (e.g. https://paypal-security-auth.xyz)..."
                  className="w-full bg-transparent px-3 py-2 text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-lg bg-cyber-cyan text-black font-mono font-bold text-xs uppercase tracking-wider hover:bg-cyan-300 transition-all shrink-0 flex items-center gap-1.5"
                >
                  <span>Scan</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-2 px-1">
                <span>Free heuristic check // Zero-Trust Sandbox</span>
                <span className="text-cyber-cyan">No installation required</span>
              </div>
            </form>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <Link
                to={user ? "/scan/url" : "/register"}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-mono font-bold text-sm tracking-wide hover:from-cyan-400 hover:to-blue-500 transition-all shadow-neon-cyan"
              >
                <Zap className="w-4 h-4" />
                <span>Start Scanning</span>
              </Link>
              <Link
                to={user ? "/dashboard" : "/login"}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-cyber-card border border-cyber-border hover:border-cyber-cyan/50 text-slate-200 hover:text-white font-mono text-sm transition-all"
              >
                <span>Explore Platform</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>

          {/* Right Column: 3D Holographic Shield Canvas */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="lg:col-span-5 relative flex items-center justify-center min-h-[380px]"
          >
            <CyberShieldCanvas />
          </motion.div>
        </div>
      </section>

      {/* Realtime Metrics Banner */}
      <section className="border-y border-cyber-border/70 bg-cyber-surface/70 py-8 px-4 sm:px-6 lg:px-8 backdrop-blur-md">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center font-mono">
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-white text-cyber-cyan">
              97.4%
            </div>
            <div className="text-xs text-cyber-muted uppercase tracking-wider mt-1">
              Engine Precision Rate
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-white">
              0-100
            </div>
            <div className="text-xs text-cyber-muted uppercase tracking-wider mt-1">
              Transparent Risk Scoring
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-white text-cyber-purple">
              &lt; 150ms
            </div>
            <div className="text-xs text-cyber-muted uppercase tracking-wider mt-1">
              Heuristic Latency
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-white text-emerald-400">
              100%
            </div>
            <div className="text-xs text-cyber-muted uppercase tracking-wider mt-1">
              SSRF Protected Sandbox
            </div>
          </div>
        </div>
      </section>

      {/* Feature Capabilities Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <span className="text-xs font-mono uppercase tracking-widest text-cyber-cyan">
            Defense Capabilities
          </span>
          <h2 className="text-3xl font-bold font-mono text-white uppercase tracking-tight">
            Multi-Layered Phishing Interception
          </h2>
          <p className="text-sm text-slate-300 font-sans">
            PhishGuard combines static lexical analysis, punycode trap detection, natural language processing, and public threat feeds into an explainable verdict.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featureCards.map((feat, i) => {
            const Icon = feat.icon;
            return (
              <motion.div
                key={feat.title}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className={`p-6 rounded-2xl bg-cyber-card border ${feat.borderColor} hover:border-cyber-cyan transition-all flex flex-col justify-between`}
              >
                <div>
                  <div className={`p-3 rounded-xl bg-cyber-surface w-fit mb-4 ${feat.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-mono text-base font-bold text-white mb-2">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    {feat.description}
                  </p>
                </div>
                <div className="mt-5 pt-3 border-t border-cyber-border/60 flex items-center text-[11px] font-mono text-cyber-cyan">
                  <span>Explore Module</span>
                  <ArrowRight className="w-3 h-3 ml-1" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Educational Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-cyber-card to-cyber-surface border border-cyber-cyan/30 relative overflow-hidden">
          <div className="relative z-10 max-w-2xl space-y-4">
            <span className="text-xs font-mono uppercase tracking-widest text-cyber-purple">
              Workforce Cyber Awareness
            </span>
            <h3 className="text-2xl sm:text-3xl font-mono font-bold text-white">
              Arm Your Team With Realistic Attack Awareness
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed">
              Explore interactive modules on QR code phishing (Quishing), SMS parcel delivery scams (Smishing), and executive wire transfer diversion (BEC) with instant quiz scoring.
            </p>
            <div className="pt-2">
              <Link
                to={user ? "/awareness" : "/register"}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-bold transition-all shadow-neon-purple"
              >
                <span>Enter Awareness Academy</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
