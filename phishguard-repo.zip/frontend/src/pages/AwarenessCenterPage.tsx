import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  GraduationCap,
  Award,
  CheckCircle2,
  HelpCircle,
  BookOpen,
  ArrowRight,
  Shield,
  Loader2,
  Sparkles
} from 'lucide-react';
import api from '../services/api';
import { AwarenessModule } from '../types';

export const AwarenessCenterPage: React.FC = () => {
  const [modules, setModules] = useState<AwarenessModule[]>([]);
  const [activeModule, setActiveModule] = useState<AwarenessModule | null>(null);
  const [loading, setLoading] = useState(true);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState<number>(0);

  const fetchModules = async () => {
    try {
      setLoading(true);
      const res = await api.get('/awareness/modules');
      setModules(res.data);
      if (res.data.length > 0 && !activeModule) {
        setActiveModule(res.data[0]);
      }
    } catch (err) {
      console.error('Failed to load awareness modules', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchModules();
  }, []);

  const selectModule = (m: AwarenessModule) => {
    setActiveModule(m);
    setUserAnswers({});
    setQuizSubmitted(false);
    setQuizScore(0);
  };

  const handleSelectAnswer = (qIndex: number, optionIndex: number) => {
    if (quizSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [qIndex]: optionIndex }));
  };

  const handleSubmitQuiz = async () => {
    if (!activeModule) return;
    let correctCount = 0;
    activeModule.quiz.forEach((q, idx) => {
      if (userAnswers[idx] === q.correct_index) {
        correctCount++;
      }
    });

    const score = Math.round((correctCount / activeModule.quiz.length) * 100);
    const passed = score >= 50;

    setQuizScore(score);
    setQuizSubmitted(true);

    try {
      await api.post('/awareness/quiz', {
        module_id: activeModule.id,
        module_title: activeModule.title,
        score,
        passed
      });
      // Refresh badge statuses
      const res = await api.get('/awareness/modules');
      setModules(res.data);
    } catch (err) {
      console.error('Failed to save quiz score', err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-mono text-purple-400 uppercase tracking-widest">
          <GraduationCap className="w-4 h-4" />
          <span>Interactive Cyber Academy</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
          Cybersecurity Threat Awareness Center
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
          Examine tactical tradecraft used by threat actors, complete scenario simulations, and earn verified defense proficiency badges.
        </p>
      </div>

      {/* Badges / Modules Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {modules.map((m) => {
          const isSelected = activeModule?.id === m.id;
          return (
            <button
              key={m.id}
              onClick={() => selectModule(m)}
              className={`p-5 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-cyber-card border-purple-500 shadow-neon-purple'
                  : 'bg-cyber-card/60 border-cyber-border hover:border-slate-600'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-semibold uppercase">
                    {m.category}
                  </span>
                  {m.user_passed && (
                    <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Certified</span>
                    </span>
                  )}
                </div>
                <h3 className="font-mono text-xs sm:text-sm font-bold text-white mb-1">
                  {m.title}
                </h3>
                <p className="text-[11px] text-slate-400 font-sans line-clamp-2">
                  {m.summary}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-cyber-border/60 flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span className="flex items-center gap-1 text-purple-300">
                  <Award className="w-3.5 h-3.5" /> {m.badge}
                </span>
                <span>{m.reading_time}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Module Study & Quiz Panel */}
      {activeModule && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Educational Content (7 cols) */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-cyber-card border border-cyber-border space-y-6">
            <div className="border-b border-cyber-border pb-4">
              <span className="text-xs font-mono uppercase tracking-wider text-purple-400">
                Tactical Dossier // {activeModule.category}
              </span>
              <h2 className="text-xl sm:text-2xl font-mono font-bold text-white mt-1">
                {activeModule.title}
              </h2>
            </div>

            <div className="space-y-6">
              {activeModule.content.map((sec, idx) => (
                <div key={idx} className="space-y-2">
                  <h3 className="text-sm font-mono font-bold text-cyber-cyan flex items-center gap-2">
                    <BookOpen className="w-4 h-4" /> {sec.subheading}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed">
                    {sec.body}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Interactive Quiz (5 cols) */}
          <div className="lg:col-span-5 p-6 sm:p-8 rounded-2xl bg-cyber-card border border-cyber-border space-y-6">
            <div className="flex items-center justify-between border-b border-cyber-border pb-4">
              <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-purple-400" /> Defense Knowledge Check
              </h3>
              {quizSubmitted && (
                <span className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                  quizScore >= 50 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                }`}>
                  Score: {quizScore}%
                </span>
              )}
            </div>

            <div className="space-y-6">
              {activeModule.quiz.map((q, qIdx) => (
                <div key={qIdx} className="space-y-3">
                  <span className="text-xs font-mono text-slate-200 block font-semibold">
                    Q{qIdx + 1}: {q.question}
                  </span>

                  <div className="space-y-2">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = userAnswers[qIdx] === optIdx;
                      const isCorrect = q.correct_index === optIdx;

                      let btnStyle = 'border-cyber-border bg-cyber-surface text-slate-300 hover:border-slate-500';
                      if (quizSubmitted) {
                        if (isCorrect) {
                          btnStyle = 'border-emerald-500 bg-emerald-950/30 text-emerald-300';
                        } else if (isSelected && !isCorrect) {
                          btnStyle = 'border-red-500 bg-red-950/30 text-red-300';
                        }
                      } else if (isSelected) {
                        btnStyle = 'border-purple-500 bg-purple-950/30 text-purple-200';
                      }

                      return (
                        <button
                          key={optIdx}
                          type="button"
                          disabled={quizSubmitted}
                          onClick={() => handleSelectAnswer(qIdx, optIdx)}
                          className={`w-full p-2.5 rounded-xl border text-left text-xs font-sans transition-all flex items-start gap-2.5 ${btnStyle}`}
                        >
                          <span className="font-mono text-slate-500 font-bold shrink-0">
                            {String.fromCharCode(65 + optIdx)}.
                          </span>
                          <span>{opt}</span>
                        </button>
                      );
                    })}
                  </div>

                  {quizSubmitted && (
                    <div className="p-3 rounded-lg bg-cyber-surface border border-cyber-border text-[11px] font-sans text-slate-300">
                      <span className="text-purple-300 font-semibold font-mono block mb-0.5">Explanation:</span>
                      {q.explanation}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="pt-2">
              {!quizSubmitted ? (
                <button
                  type="button"
                  onClick={handleSubmitQuiz}
                  disabled={Object.keys(userAnswers).length < activeModule.quiz.length}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-neon-purple disabled:opacity-40"
                >
                  Verify Answers & Claim Badge
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => { setQuizSubmitted(false); setUserAnswers({}); }}
                  className="w-full py-2.5 rounded-xl bg-cyber-surface border border-cyber-border text-slate-300 hover:text-white font-mono text-xs transition-colors"
                >
                  Retake Quiz
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
