import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, Lock, Mail, User, Building, ArrowRight, AlertCircle, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const RegisterPage: React.FC = () => {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 8) {
      setError('Password must contain at least 8 characters.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      await register(name, email, password, confirmPassword, organization);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Registration failed. Email may already be registered.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 cyber-grid-bg">
      <div className="w-full max-w-md space-y-6">
        {/* Emblem */}
        <div className="text-center">
          <div className="inline-flex p-3 rounded-2xl bg-cyber-card border border-cyber-cyan/40 shadow-neon-cyan mb-3">
            <Shield className="w-8 h-8 text-cyber-cyan" />
          </div>
          <h2 className="text-2xl font-mono font-extrabold text-white uppercase tracking-wider">
            Deploy PhishGuard Agent
          </h2>
          <p className="text-xs text-cyber-muted font-mono mt-1">
            Create your cyber threat intelligence console
          </p>
        </div>

        {/* Form Container */}
        <div className="p-8 rounded-2xl bg-cyber-card border border-cyber-border shadow-2xl">
          {error && (
            <div className="mb-5 p-3 rounded-xl bg-red-950/40 border border-red-500/40 flex items-start gap-2.5 text-xs text-red-200">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider mb-1">
                Full Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Security Analyst"
                  required
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-10 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="analyst@enterprise.com"
                  required
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-10 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider mb-1">
                Organization / Team (Optional)
              </label>
              <div className="relative">
                <Building className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={organization}
                  onChange={(e) => setOrganization(e.target.value)}
                  placeholder="SecOps Team"
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-10 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider mb-1">
                Master Password (min 8 chars)
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-10 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider mb-1">
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-10 pr-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 rounded-xl bg-cyber-cyan hover:bg-cyan-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-neon-cyan disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Provisioning Account...</span>
                </>
              ) : (
                <>
                  <span>Create Operator Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-cyber-border/60 text-center text-xs font-mono text-slate-400">
            Already registered?{' '}
            <Link to="/login" className="text-cyber-cyan hover:underline font-semibold">
              Sign In Here
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
