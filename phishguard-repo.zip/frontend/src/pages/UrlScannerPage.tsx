import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  RotateCcw,
  Shield,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  FileDown,
  Layers,
  Globe,
  ExternalLink,
  ChevronDown,
  Loader2,
  Copy,
  Check
} from 'lucide-react';
import api from '../services/api';
import { ScanResult } from '../types';
import { RiskGauge } from '../components/RiskGauge';
import { RadarScanner } from '../components/RadarScanner';

const PRESET_URLS = [
  {
    name: "Phishing: PayPal Impersonator",
    url: "https://paypal-security-account-verification.xyz/login?redirect=malicious-payload.com",
    tag: "High Risk"
  },
  {
    name: "Homograph: Confusable Spoof",
    url: "https://p\u0430ypal.com/verify", // Cyrillic 'а'
    tag: "Cyrillic IDN"
  },
  {
    name: "Legitimate: Google Search",
    url: "https://www.google.com/search?q=zero+trust+architecture",
    tag: "Verified Safe"
  },
  {
    name: "Shortener: Obfuscated Link",
    url: "https://bit.ly/3x8QzL",
    tag: "Redirect Vector"
  }
];

export const UrlScannerPage: React.FC = () => {
  const location = useLocation();
  const [urlInput, setUrlInput] = useState('');
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanId, setScanId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'failed' | 'passed' | 'all'>('failed');
  const [downloadingPdf, setDownloadingPdf] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (location.state?.initialUrl) {
      setUrlInput(location.state.initialUrl);
    }
  }, [location.state]);

  const handleScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!urlInput.trim()) {
      setError('Please provide a URL to inspect.');
      return;
    }

    try {
      setError(null);
      setScanning(true);
      setScanResult(null);

      const res = await api.post('/scan/url', { url: urlInput.trim() });
      setScanResult(res.data.result);
      setScanId(res.data.id);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Scan execution failed. Please verify input.');
      setScanning(false);
    }
  };

  const handleRadarComplete = () => {
    setScanning(false);
  };

  const handleClear = () => {
    setUrlInput('');
    setScanResult(null);
    setScanId(null);
    setError(null);
  };

  const handleDownloadPdf = async () => {
    if (!scanId) return;
    try {
      setDownloadingPdf(true);
      const repRes = await api.post(`/reports/generate/${scanId}`);
      const reportId = repRes.data.id;
      const fileRes = await api.get(`/reports/${reportId}/download`, { responseType: 'blob' });

      const blobUrl = window.URL.createObjectURL(new Blob([fileRes.data]));
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = `${repRes.data.report_code || 'PhishGuard_Forensic_Report'}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      console.error('Failed to download report', err);
      alert('Report generation failed. Please try again.');
    } finally {
      setDownloadingPdf(false);
    }
  };

  const copyResultSummary = () => {
    if (!scanResult) return;
    const text = `PhishGuard URL Verdict: ${scanResult.risk_level} (${scanResult.risk_score}/100) for ${urlInput}\nSummary: ${scanResult.summary}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-mono text-cyber-cyan uppercase tracking-widest">
          <Shield className="w-4 h-4" />
          <span>Automated Heuristic Defense</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
          Advanced URL Forensic Scanner
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
          Perform multi-vector inspection for domain homoglyphs, brand spoofing, subdomain stacking, and redirects without executing client code or triggering SSRF.
        </p>
      </div>

      {/* Input Box Card */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4 shadow-xl">
        <form onSubmit={handleScan} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Paste URL (e.g. https://security-verify-paypal.xyz/login)..."
              className="w-full bg-cyber-surface border border-cyber-border rounded-xl pl-4 pr-24 py-3.5 text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyber-cyan transition-colors"
            />
            {urlInput && (
              <button
                type="button"
                onClick={handleClear}
                className="absolute right-3 top-3.5 px-2 py-1 rounded bg-cyber-card hover:bg-slate-700 text-slate-400 hover:text-white text-xs font-mono transition-colors"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono text-slate-400 mr-1">Presets:</span>
              {PRESET_URLS.map((preset) => (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => {
                    setUrlInput(preset.url);
                    setError(null);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-cyber-surface hover:bg-cyber-card border border-cyber-border hover:border-cyber-cyan/40 text-[11px] font-mono text-slate-300 transition-colors"
                >
                  {preset.name.split(':')[0]}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleClear}
                className="px-4 py-2.5 rounded-xl border border-cyber-border text-slate-400 hover:text-white font-mono text-xs transition-colors flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
              <button
                type="submit"
                disabled={scanning}
                className="px-6 py-2.5 rounded-xl bg-cyber-cyan hover:bg-cyan-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-neon-cyan flex items-center gap-2 disabled:opacity-50"
              >
                <Search className="w-4 h-4" />
                <span>Execute Deep Scan</span>
              </button>
            </div>
          </div>
        </form>

        {error && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/40 text-xs text-red-200 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Radar Scanning View */}
      {scanning && (
        <div className="p-8 rounded-2xl bg-cyber-card border border-cyber-cyan/30 shadow-neon-cyan">
          <RadarScanner target={urlInput} onComplete={handleRadarComplete} />
        </div>
      )}

      {/* Forensic Results Section */}
      {!scanning && scanResult && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="space-y-6"
        >
          {/* Top Verdict Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 rounded-2xl bg-cyber-card border border-cyber-border">
            {/* Risk Gauge */}
            <div className="lg:col-span-4 flex flex-col items-center justify-center p-4 border-b lg:border-b-0 lg:border-r border-cyber-border/70">
              <RiskGauge score={scanResult.risk_score} level={scanResult.risk_level} size={190} />
            </div>

            {/* Verdict Summary & Characteristics */}
            <div className="lg:col-span-8 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase tracking-wider text-cyber-cyan">
                    Forensic Verdict // {scanResult.risk_level} Risk Profile
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={copyResultSummary}
                      className="p-1.5 rounded-lg bg-cyber-surface hover:bg-cyber-border text-slate-400 hover:text-white transition-colors"
                      title="Copy Summary"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-cyber-success" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <h3 className="text-lg font-mono font-bold text-white mt-1">
                  {scanResult.summary}
                </h3>

                <p className="text-xs font-mono text-slate-400 mt-2 break-all bg-cyber-surface p-2.5 rounded border border-cyber-border">
                  Target: <span className="text-cyber-cyan">{scanResult.target}</span>
                </p>
              </div>

              {/* Technical Attributes Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">Hostname</span>
                  <span className="text-slate-200 truncate block font-semibold">{scanResult.hostname}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">Protocol</span>
                  <span className={`block font-semibold ${scanResult.scheme === 'https' ? 'text-cyber-success' : 'text-amber-400'}`}>
                    {scanResult.scheme?.toUpperCase()}
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">Lexical Entropy</span>
                  <span className="text-slate-200 block font-semibold">{scanResult.entropy ?? 'Normal'}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-cyber-surface border border-cyber-border">
                  <span className="text-[10px] text-slate-500 uppercase block">Failed Flags</span>
                  <span className={`block font-semibold ${scanResult.failed_count ? 'text-red-400' : 'text-emerald-400'}`}>
                    {scanResult.failed_count || 0} Flags
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap gap-3">
                <button
                  onClick={handleDownloadPdf}
                  disabled={downloadingPdf}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyber-cyan/15 border border-cyber-cyan text-cyber-cyan hover:bg-cyber-cyan hover:text-black font-mono text-xs font-bold transition-all shadow-neon-cyan disabled:opacity-50"
                >
                  {downloadingPdf ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Generating PDF...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-3.5 h-3.5" />
                      <span>Download Official PDF Report</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Forensic Checks Breakdown */}
          <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
            <div className="flex items-center justify-between border-b border-cyber-border pb-3">
              <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyber-cyan" /> Inspection Breakdown
              </h4>
              <div className="flex gap-1.5 font-mono text-xs">
                <button
                  onClick={() => setActiveTab('failed')}
                  className={`px-3 py-1 rounded-lg transition-colors ${
                    activeTab === 'failed' ? 'bg-red-500/20 text-red-400 border border-red-500/40' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Anomalies ({scanResult.failed_checks?.length || 0})
                </button>
                <button
                  onClick={() => setActiveTab('passed')}
                  className={`px-3 py-1 rounded-lg transition-colors ${
                    activeTab === 'passed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Passed ({scanResult.passed_checks?.length || 0})
                </button>
              </div>
            </div>

            {/* Check Cards */}
            <div className="space-y-3">
              {activeTab === 'failed' && (
                <>
                  {(!scanResult.failed_checks || scanResult.failed_checks.length === 0) ? (
                    <div className="text-center py-8 text-xs font-mono text-emerald-400 flex flex-col items-center gap-2">
                      <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                      <span>Clean inspection: No anomalous security indicators triggered.</span>
                    </div>
                  ) : (
                    scanResult.failed_checks.map((fc, i) => (
                      <div key={i} className="p-4 rounded-xl bg-red-950/20 border border-red-500/30 flex items-start gap-3">
                        <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                        <div className="flex-1 text-xs">
                          <div className="flex items-center justify-between font-mono font-bold text-red-300">
                            <span>{fc.title}</span>
                            <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-400">{fc.severity}</span>
                          </div>
                          <p className="text-slate-300 font-sans mt-1">{fc.description}</p>
                          {fc.evidence && (
                            <div className="mt-2 font-mono text-[11px] text-red-200/90 bg-red-950/40 p-2 rounded border border-red-500/20">
                              Forensic Evidence: {fc.evidence}
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </>
              )}

              {activeTab === 'passed' && (
                <>
                  {scanResult.passed_checks && scanResult.passed_checks.map((pc, i) => (
                    <div key={i} className="p-3.5 rounded-xl bg-emerald-950/15 border border-emerald-500/20 flex items-start gap-3">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div className="flex-1 text-xs">
                        <div className="flex items-center justify-between font-mono font-semibold text-emerald-300">
                          <span>{pc.title}</span>
                          <span className="text-emerald-400 text-[11px]">PASSED</span>
                        </div>
                        <p className="text-slate-400 font-sans mt-0.5">{pc.description}</p>
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>

          {/* Actionable Protocol */}
          {scanResult.recommendations && scanResult.recommendations.length > 0 && (
            <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-3">
              <h4 className="text-xs uppercase font-mono tracking-wider text-cyber-cyan font-bold">
                Actionable Defense Protocol
              </h4>
              <ul className="space-y-2 text-xs text-slate-300 font-sans">
                {scanResult.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <span className="text-cyber-cyan font-mono font-bold">[{i + 1}]</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};
