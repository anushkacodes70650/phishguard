import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Target,
  Activity,
  ArrowUpRight,
  Radio,
  FileDown,
  RefreshCw,
  Search,
  ExternalLink,
  Loader2
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import api from '../services/api';
import { DashboardOverview, DashboardAnalytics, ScanRecord } from '../types';
import { ScanDetailModal } from '../components/ScanDetailModal';

const COLORS = ['#00E5FF', '#8B5CF6', '#F59E0B', '#EF4444', '#22C55E'];

export const DashboardPage: React.FC = () => {
  const [overview, setOverview] = useState<DashboardOverview | null>(null);
  const [analytics, setAnalytics] = useState<DashboardAnalytics | null>(null);
  const [recentScans, setRecentScans] = useState<ScanRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedScan, setSelectedScan] = useState<any>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [overRes, analRes, recentRes] = await Promise.all([
        api.get('/dashboard/overview'),
        api.get('/dashboard/analytics'),
        api.get('/dashboard/recent-scans?limit=6')
      ]);
      setOverview(overRes.data);
      setAnalytics(analRes.data);
      setRecentScans(recentRes.data);
    } catch (err) {
      console.error('Failed to fetch dashboard data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleOpenScan = async (scanId: string) => {
    try {
      const res = await api.get(`/history/${scanId}`);
      setSelectedScan(res.data);
      setModalOpen(true);
    } catch (err) {
      console.error('Failed to load scan details', err);
    }
  };

  if (loading && !overview) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-cyber-cyan font-mono">
        <Loader2 className="w-8 h-8 animate-spin mb-3" />
        <span>Synchronizing telemetry...</span>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyber-cyan uppercase tracking-widest">
            <span className="w-2 h-2 rounded-full bg-cyber-success animate-ping" />
            <span>Cyber Defense Command // Telemetry Live</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
            Intelligence Operations Center
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchDashboardData}
            className="p-2 rounded-lg bg-cyber-card border border-cyber-border hover:border-cyber-cyan/50 text-slate-300 hover:text-cyber-cyan transition-colors"
            title="Refresh Telemetry"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <Link
            to="/scan/url"
            className="px-4 py-2 rounded-lg bg-cyber-cyan hover:bg-cyan-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-neon-cyan flex items-center gap-1.5"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Launch Scanner</span>
          </Link>
        </div>
      </div>

      {/* Main Metrics 5 Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Metric 1: Total Scans */}
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border hover:border-cyber-cyan/40 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Total Scans</span>
            <Activity className="w-4 h-4 text-cyber-cyan" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-mono font-extrabold text-white">
              {overview?.total_scans ?? 0}
            </div>
            <div className="text-[11px] font-mono text-slate-400 mt-1">
              Database verified events
            </div>
          </div>
        </div>

        {/* Metric 2: Safe Scans */}
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border hover:border-emerald-500/40 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Safe Clean</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-mono font-extrabold text-emerald-400">
              {overview?.safe_scans ?? 0}
            </div>
            <div className="text-[11px] font-mono text-slate-400 mt-1">
              Passed all heuristic gates
            </div>
          </div>
        </div>

        {/* Metric 3: Suspicious */}
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border hover:border-amber-500/40 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Suspicious</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-mono font-extrabold text-amber-400">
              {overview?.suspicious_scans ?? 0}
            </div>
            <div className="text-[11px] font-mono text-slate-400 mt-1">
              Elevated caution advised
            </div>
          </div>
        </div>

        {/* Metric 4: Critical Threats */}
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border hover:border-red-500/40 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">High Threats</span>
            <Flame className="w-4 h-4 text-red-500 animate-pulse" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-mono font-extrabold text-red-500">
              {overview?.critical_threats ?? 0}
            </div>
            <div className="text-[11px] font-mono text-slate-400 mt-1">
              Phishing / C2 neutralized
            </div>
          </div>
        </div>

        {/* Metric 5: Engine Precision */}
        <div className="p-5 rounded-2xl bg-cyber-card border border-cyber-border hover:border-purple-500/40 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Engine Accuracy</span>
            <Target className="w-4 h-4 text-cyber-purple" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-mono font-extrabold text-purple-300">
              {overview?.engine_accuracy ?? 97.4}%
            </div>
            <div className="text-[11px] font-mono text-slate-400 mt-1">
              Validated on test corpus
            </div>
          </div>
        </div>
      </div>

      {/* Analytics Visualizations Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Threat Activity Area Chart (8 cols) */}
        <div className="lg:col-span-8 p-6 rounded-2xl bg-cyber-card border border-cyber-border">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyber-cyan" /> Threat Activity Timeline (Past 7 Days)
              </h3>
              <p className="text-xs text-slate-400 font-sans mt-0.5">
                Aggregated daily volume of analyzed endpoints and detected indicators
              </p>
            </div>
            <span className="text-xs font-mono text-cyber-cyan bg-cyber-surface px-2.5 py-1 rounded border border-cyber-border">
              Real-time DB Sync
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analytics?.activity_chart || []}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00E5FF" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#00E5FF" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.5}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#101B2D',
                    borderColor: '#1E2D4A',
                    borderRadius: '8px',
                    fontSize: '11px',
                    fontFamily: 'monospace'
                  }}
                />
                <Area type="monotone" dataKey="total" stroke="#00E5FF" fillOpacity={1} fill="url(#colorTotal)" name="Total Scans" />
                <Area type="monotone" dataKey="threats" stroke="#EF4444" fillOpacity={1} fill="url(#colorThreats)" name="Threats Detected" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Security Health Gauge & Threat Distribution (4 cols) */}
        <div className="lg:col-span-4 p-6 rounded-2xl bg-cyber-card border border-cyber-border flex flex-col justify-between">
          <div>
            <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-cyber-purple" /> Defense Health Posture
            </h3>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Calculated cyber resilience score
            </p>
          </div>

          {/* Health Index Box */}
          <div className="my-6 p-4 rounded-xl bg-cyber-surface border border-cyber-border flex items-center justify-around">
            <div className="text-center">
              <div className="text-4xl font-mono font-extrabold text-white text-cyber-cyan">
                {overview?.health_score ?? 100}
                <span className="text-xs text-cyber-muted font-normal ml-0.5">/100</span>
              </div>
              <div className="text-[11px] font-mono text-emerald-400 uppercase font-semibold mt-1">
                STATUS: {overview?.health_status ?? 'Protected'}
              </div>
            </div>
            <div className="text-xs font-mono text-slate-400 border-l border-cyber-border pl-4 space-y-1">
              <div>Zero-Day Guard: <span className="text-cyber-cyan">ACTIVE</span></div>
              <div>SSRF Defense: <span className="text-emerald-400">ENFORCED</span></div>
              <div>Threat Feeds: <span className="text-cyber-cyan">4 ACTIVE</span></div>
            </div>
          </div>

          {/* Mini Pie Distribution */}
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={analytics?.distribution_chart || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={36}
                  outerRadius={56}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {(analytics?.distribution_chart || []).map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#101B2D',
                    borderColor: '#1E2D4A',
                    borderRadius: '8px',
                    fontSize: '11px',
                    fontFamily: 'monospace'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Recent Scans Table */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider">
              Recent Forensic Scans
            </h3>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Live audit stream of user-submitted endpoints and messages
            </p>
          </div>
          <Link
            to="/history"
            className="text-xs font-mono text-cyber-cyan hover:underline flex items-center gap-1"
          >
            <span>Full History ({overview?.total_scans ?? 0})</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {recentScans.length === 0 ? (
          <div className="text-center py-10 text-xs font-mono text-slate-500">
            No scans recorded yet. Enter a URL above to perform your first inspection.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="border-b border-cyber-border text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Target / Display</th>
                  <th className="py-3 px-4">Scan Type</th>
                  <th className="py-3 px-4">Risk Index</th>
                  <th className="py-3 px-4">Classification</th>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-cyber-border/40">
                {recentScans.map((scan) => {
                  const isCrit = scan.risk_level === 'CRITICAL';
                  const isHigh = scan.risk_level === 'HIGH';
                  const isMed = scan.risk_level === 'MEDIUM';

                  const badgeClass = isCrit
                    ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                    : isHigh
                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                    : isMed
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40';

                  return (
                    <tr key={scan.id} className="hover:bg-cyber-surface/60 transition-colors">
                      <td className="py-3 px-4 max-w-xs truncate font-medium text-slate-200">
                        {scan.target_display || scan.input_value}
                      </td>
                      <td className="py-3 px-4 text-slate-400 uppercase">
                        {scan.scan_type}
                      </td>
                      <td className="py-3 px-4 font-bold text-white">
                        {scan.risk_score} <span className="text-[10px] text-slate-500 font-normal">/100</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${badgeClass}`}>
                          {scan.risk_level}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        {new Date(scan.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => handleOpenScan(scan.id)}
                          className="px-2.5 py-1 rounded bg-cyber-surface hover:bg-cyber-cyan/15 border border-cyber-border hover:border-cyber-cyan/40 text-[11px] text-cyber-cyan transition-colors"
                        >
                          View Analysis
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal for Details */}
      <ScanDetailModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        scanData={selectedScan}
      />
    </div>
  );
};
