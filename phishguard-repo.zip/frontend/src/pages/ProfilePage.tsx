import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User as UserIcon,
  Lock,
  Settings as SettingsIcon,
  Download,
  Trash2,
  CheckCircle,
  AlertCircle,
  Shield,
  Loader2,
  Building,
  Mail
} from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { UserSettings } from '../types';

export const ProfilePage: React.FC = () => {
  const { user, refreshUser, logout } = useAuth();
  const navigate = useNavigate();

  // Profile Form state
  const [name, setName] = useState(user?.name || '');
  const [organization, setOrganization] = useState(user?.organization || '');
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  // Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordMsg, setPasswordMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Settings state
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [settingsSaving, setSettingsSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setName(user.name);
      setOrganization(user.organization || '');
    }

    // Fetch user settings
    api.get('/profile/settings').then((res) => {
      setSettings(res.data);
    }).catch(() => {});
  }, [user]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setProfileSaving(true);
      setProfileMsg(null);
      await api.put('/profile', { name, organization });
      await refreshUser();
      setProfileMsg('Profile information successfully saved.');
    } catch {
      setProfileMsg('Failed to update profile.');
    } finally {
      setProfileSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setPasswordSaving(true);
      setPasswordMsg(null);
      await api.put('/profile/password', {
        current_password: currentPassword,
        new_password: newPassword
      });
      setPasswordMsg({ type: 'success', text: 'Password successfully updated.' });
      setCurrentPassword('');
      setNewPassword('');
    } catch (err: any) {
      setPasswordMsg({ type: 'error', text: err.response?.data?.detail || 'Failed to update password.' });
    } finally {
      setPasswordSaving(false);
    }
  };

  const handleToggleSetting = async (key: keyof UserSettings) => {
    if (!settings) return;
    const updatedVal = !settings[key];
    const newSettings = { ...settings, [key]: updatedVal };
    setSettings(newSettings);

    try {
      await api.put('/profile/settings', { [key]: updatedVal });
    } catch (err) {
      console.error('Failed to update setting', err);
    }
  };

  const handleExportData = async () => {
    try {
      const res = await api.get('/profile/export-data');
      const jsonStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(res.data, null, 2));
      const link = document.createElement('a');
      link.href = jsonStr;
      link.setAttribute('download', `phishguard_user_data_${user?.id}.json`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('Failed to export data', err);
    }
  };

  const handleDeleteAccount = async () => {
    if (!confirm('DANGER: This action is irreversible. All your scan history and telemetry will be permanently wiped. Confirm deletion?')) return;
    try {
      await api.delete('/profile/account');
      logout();
      navigate('/login');
    } catch (err) {
      console.error('Failed to delete account', err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-mono text-cyber-cyan uppercase tracking-widest">
          <SettingsIcon className="w-4 h-4" />
          <span>Operator Profile</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
          Account & Engine Preferences
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Profile Information Card */}
        <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-5">
          <div className="flex items-center justify-between border-b border-cyber-border pb-3">
            <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
              <UserIcon className="w-4 h-4 text-cyber-cyan" /> Operator Identity
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyber-cyan/20 text-cyber-cyan uppercase font-bold">
              {user?.role}
            </span>
          </div>

          {profileMsg && (
            <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-300">
              {profileMsg}
            </div>
          )}

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-cyber-surface border border-cyber-border rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyber-cyan"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">
                Email Address (Immutable)
              </label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full bg-cyber-surface/50 border border-cyber-border/50 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">
                Assigned Team / Organization
              </label>
              <input
                type="text"
                value={organization}
                onChange={(e) => setOrganization(e.target.value)}
                placeholder="e.g. SOC Team Alpha"
                className="w-full bg-cyber-surface border border-cyber-border rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyber-cyan"
              />
            </div>

            <button
              type="submit"
              disabled={profileSaving}
              className="px-5 py-2 rounded-xl bg-cyber-cyan hover:bg-cyan-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50"
            >
              {profileSaving ? 'Saving...' : 'Save Profile Details'}
            </button>
          </form>
        </div>

        {/* Change Password Card */}
        <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-5">
          <div className="border-b border-cyber-border pb-3">
            <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
              <Lock className="w-4 h-4 text-cyber-purple" /> Authentication Secrets
            </h3>
          </div>

          {passwordMsg && (
            <div className={`p-3 rounded-lg border text-xs ${
              passwordMsg.type === 'success'
                ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                : 'bg-red-950/30 border-red-500/30 text-red-300'
            }`}>
              {passwordMsg.text}
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">
                Current Password
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
                className="w-full bg-cyber-surface border border-cyber-border rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyber-purple"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">
                New Master Password (min 8 chars)
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                className="w-full bg-cyber-surface border border-cyber-border rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyber-purple"
              />
            </div>

            <button
              type="submit"
              disabled={passwordSaving}
              className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50"
            >
              {passwordSaving ? 'Updating...' : 'Update Password'}
            </button>
          </form>
        </div>
      </div>

      {/* Engine & Detection Preferences */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
        <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyber-cyan" /> Scan & Alert Preferences
        </h3>

        {settings && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-cyber-surface border border-cyber-border flex items-center justify-between">
              <div>
                <div className="font-mono text-xs font-bold text-white">Deep Heuristic Inspection</div>
                <div className="text-[11px] text-slate-400 font-sans">Execute multi-pass entropy and Cyrillic homoglyph calculations</div>
              </div>
              <button
                type="button"
                onClick={() => handleToggleSetting('deep_analysis_enabled')}
                className={`w-12 h-6 rounded-full transition-colors p-1 ${
                  settings.deep_analysis_enabled ? 'bg-cyber-cyan' : 'bg-slate-700'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-black transition-transform ${
                  settings.deep_analysis_enabled ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-cyber-surface border border-cyber-border flex items-center justify-between">
              <div>
                <div className="font-mono text-xs font-bold text-white">Automate PDF Dossier Compilation</div>
                <div className="text-[11px] text-slate-400 font-sans">Generate PDF reports immediately after high-risk verdicts</div>
              </div>
              <button
                type="button"
                onClick={() => handleToggleSetting('auto_export_pdf')}
                className={`w-12 h-6 rounded-full transition-colors p-1 ${
                  settings.auto_export_pdf ? 'bg-cyber-cyan' : 'bg-slate-700'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-black transition-transform ${
                  settings.auto_export_pdf ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-cyber-surface border border-cyber-border flex items-center justify-between">
              <div>
                <div className="font-mono text-xs font-bold text-white">Browser Notifications</div>
                <div className="text-[11px] text-slate-400 font-sans">Display in-app warnings when critical threats are intercepted</div>
              </div>
              <button
                type="button"
                onClick={() => handleToggleSetting('notifications_enabled')}
                className={`w-12 h-6 rounded-full transition-colors p-1 ${
                  settings.notifications_enabled ? 'bg-cyber-cyan' : 'bg-slate-700'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-black transition-transform ${
                  settings.notifications_enabled ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-cyber-surface border border-cyber-border flex items-center justify-between">
              <div>
                <div className="font-mono text-xs font-bold text-white">Threat Feed Email Alerts</div>
                <div className="text-[11px] text-slate-400 font-sans">Dispatch email summaries for verified zero-day phishing spikes</div>
              </div>
              <button
                type="button"
                onClick={() => handleToggleSetting('email_alerts')}
                className={`w-12 h-6 rounded-full transition-colors p-1 ${
                  settings.email_alerts ? 'bg-cyber-cyan' : 'bg-slate-700'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-black transition-transform ${
                  settings.email_alerts ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Data Sovereignty & Danger Zone */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-3">
          <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
            <Download className="w-4 h-4 text-cyber-cyan" /> Data Sovereignty Export
          </h4>
          <p className="text-xs text-slate-400 font-sans">
            Download an encrypted, comprehensive JSON archive of your user profile, scan histories, and report records.
          </p>
          <button
            onClick={handleExportData}
            className="px-4 py-2 rounded-xl bg-cyber-surface border border-cyber-border hover:border-cyber-cyan text-xs font-mono text-cyber-cyan transition-colors"
          >
            Download Personal Telemetry (.json)
          </button>
        </div>

        <div className="p-6 rounded-2xl bg-cyber-card border border-red-500/30 space-y-3">
          <h4 className="font-mono font-bold text-sm text-red-400 uppercase tracking-wider flex items-center gap-2">
            <Trash2 className="w-4 h-4" /> Danger Zone: Erase Account
          </h4>
          <p className="text-xs text-slate-400 font-sans">
            Permanently destroy your operator credentials, historical scans, and cryptographic reports from the database.
          </p>
          <button
            onClick={handleDeleteAccount}
            className="px-4 py-2 rounded-xl bg-red-950/40 border border-red-500/50 hover:bg-red-500 hover:text-white text-xs font-mono text-red-400 transition-all"
          >
            Delete Account & Telemetry
          </button>
        </div>
      </div>
    </div>
  );
};
