import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  MailWarning,
  Search,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Brain,
  Link as LinkIcon,
  Shield,
  FileDown,
  Loader2,
  ExternalLink
} from 'lucide-react';
import api from '../services/api';
import { ScanResult } from '../types';
import { RiskGauge } from '../components/RiskGauge';
import { HighlightedMessage } from '../components/HighlightedMessage';

const PRESET_MESSAGES = [
  {
    name: "Urgent Bank Suspension",
    sender: "security@paypa1-alert.com",
    text: "URGENT: Your bank account will be suspended within 24 hours due to unauthorized access detected. Verify your password and social security number immediately using this link: https://chase-bank-verify.xyz/auth or legal action will be initiated."
  },
  {
    name: "Lottery / Prize SMS",
    sender: "+1 (800) 555-0199",
    text: "Congratulations! You have won a $1,000,000 cash prize voucher from our holiday lottery! Enter your bank account verification details right away to claim your reward."
  },
  {
    name: "CEO Emergency Wire (BEC)",
    sender: "ceo.office@gmail.com",
    text: "Alex, I am in a confidential board meeting and cannot take calls. I need you to initiate a wire transfer of $45,000 to this vendor account right away before it is too late. Keep this strictly between us."
  },
  {
    name: "Legitimate Meeting Invite",
    sender: "colleague@enterprise.com",
    text: "Hi Alex, please find the quarterly sprint notes attached. Let me know if you would like to sync on the roadmap during tomorrow morning's coffee check-in."
  }
];

export const MessageScannerPage: React.FC = () => {
  const [messageInput, setMessageInput] = useState('');
  const [senderHint, setSenderHint] = useState('');
  const [loading, setLoading] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanId, setScanId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  const handleScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!messageInput.trim()) {
      setError('Please paste a suspicious message or email body to evaluate.');
      return;
    }

    try {
      setError(null);
      setLoading(true);
      setScanResult(null);

      const res = await api.post('/scan/message', {
        message: messageInput.trim(),
        sender_hint: senderHint.trim() || undefined
      });
      setScanResult(res.data.result);
      setScanId(res.data.id);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Analysis failed. Please verify input.');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setMessageInput('');
    setSenderHint('');
    setScanResult(null);
    setScanId(null);
    setError(null);
  };

  const loadPreset = (preset: typeof PRESET_MESSAGES[0]) => {
    setMessageInput(preset.text);
    setSenderHint(preset.sender);
    setError(null);
  };

  const handleDownloadPdf = async () => {
    if (!scanId) return;
    try {
      setDownloadingPdf(true);
      const repRes = await api.post(`/reports/generate/${scanId}`);
      const reportId = repRes.data.id;
      const fileRes = await api.get(`/reports/${reportId}/download`, { responseType: 'blob' });

      const blobUrl = window.URL.createObjectURL(new Blob([fileRes.data]));
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = `${repRes.data.report_code || 'PhishGuard_Message_Report'}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      console.error('Failed to download report', err);
      alert('Report generation failed. Please try again.');
    } finally {
      setDownloadingPdf(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-mono text-cyber-purple uppercase tracking-widest">
          <Brain className="w-4 h-4" />
          <span>Social Engineering & NLP Decomposition</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-mono font-extrabold text-white uppercase tracking-tight mt-1">
          Suspicious Message & Phishing Inspector
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 font-sans mt-1">
          Inspect incoming emails, SMS messages, and chat notifications for cognitive manipulation, urgency levers, and embedded malicious links with visual phrase mapping.
        </p>
      </div>

      {/* Input Form Box */}
      <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4 shadow-xl">
        <form onSubmit={handleScan} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-1">
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider">
                Message Content (Email Body, SMS, or Chat Text)
              </label>
              <textarea
                rows={5}
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="Paste the raw text of the suspicious email or SMS message here..."
                className="w-full bg-cyber-surface border border-cyber-border rounded-xl p-3.5 text-xs sm:text-sm font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-purple transition-colors resize-none"
              />
            </div>

            <div className="space-y-3 flex flex-col justify-between">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-1">
                  Sender Address or Phone (Optional)
                </label>
                <input
                  type="text"
                  value={senderHint}
                  onChange={(e) => setSenderHint(e.target.value)}
                  placeholder="e.g. security@bank-alert.com"
                  className="w-full bg-cyber-surface border border-cyber-border rounded-xl px-3 py-2 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-cyber-purple transition-colors"
                />
              </div>

              <div>
                <span className="block text-[11px] font-mono text-slate-400 mb-1.5">
                  Load Realistic Scenario:
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  {PRESET_MESSAGES.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => loadPreset(preset)}
                      className="p-1.5 rounded-lg bg-cyber-surface hover:bg-cyber-card border border-cyber-border hover:border-cyber-purple/50 text-[10px] font-mono text-slate-300 text-left truncate transition-colors"
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-cyber-border/70">
            <div className="text-[11px] font-mono text-slate-400">
              Zero-Trust: Private content is analyzed locally and never shared.
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleClear}
                className="px-4 py-2 rounded-xl border border-cyber-border text-slate-400 hover:text-white font-mono text-xs transition-colors flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-neon-purple flex items-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Analyzing Patterns...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Scan Message</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {error && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/40 text-xs text-red-200 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Results View */}
      {scanResult && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Top Verdict Card */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 rounded-2xl bg-cyber-card border border-cyber-border">
            <div className="lg:col-span-4 flex flex-col items-center justify-center p-4 border-b lg:border-b-0 lg:border-r border-cyber-border/70">
              <RiskGauge score={scanResult.risk_score} level={scanResult.risk_level} size={180} />
            </div>

            <div className="lg:col-span-8 flex flex-col justify-between space-y-4">
              <div>
                <span className="text-xs font-mono uppercase tracking-wider text-cyber-purple">
                  Psychological & Phishing Assessment
                </span>
                <h3 className="text-lg font-mono font-bold text-white mt-1">
                  {scanResult.summary}
                </h3>
                <p className="text-xs text-slate-300 font-sans mt-2 leading-relaxed">
                  Identified {scanResult.psychological_triggers?.length || 0} distinct cognitive manipulation patterns designed to induce panic, compliance, or credential compromise.
                </p>
              </div>

              <div className="flex flex-wrap gap-3 pt-2">
                <button
                  onClick={handleDownloadPdf}
                  disabled={downloadingPdf}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600/20 border border-purple-500 text-purple-300 hover:bg-purple-600 hover:text-white font-mono text-xs font-bold transition-all shadow-neon-purple disabled:opacity-50"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>Download Forensic PDF Report</span>
                </button>
              </div>
            </div>
          </div>

          {/* Visual Highlight Inspection */}
          <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider">
                Visual Phrase & Threat Highlighting
              </h4>
              <span className="text-xs font-mono text-slate-400">
                Hover highlighted badges to view classification
              </span>
            </div>
            <HighlightedMessage
              text={messageInput}
              spans={scanResult.suspicious_spans}
            />
          </div>

          {/* Psychological Triggers Breakdown */}
          {scanResult.psychological_triggers && scanResult.psychological_triggers.length > 0 && (
            <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-4">
              <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <Brain className="w-4 h-4 text-cyber-purple" /> Deconstructed Social Engineering Triggers
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {scanResult.psychological_triggers.map((trigger, i) => (
                  <div key={i} className="p-4 rounded-xl bg-cyber-surface border border-cyber-border space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-xs text-white">
                        {trigger.category}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-semibold uppercase">
                        {trigger.severity}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 font-sans leading-relaxed">
                      {trigger.explanation}
                    </p>
                    <div className="text-[11px] font-mono text-slate-400">
                      Matched: <span className="text-cyber-cyan">{trigger.matched_phrases.join(', ')}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Embedded URLs Inspection */}
          {scanResult.embedded_urls && scanResult.embedded_urls.length > 0 && (
            <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-3">
              <h4 className="font-mono font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-cyber-cyan" /> Embedded Links Auto-Analyzed ({scanResult.embedded_urls.length})
              </h4>
              <div className="space-y-2">
                {scanResult.embedded_urls.map((link, i) => (
                  <div key={i} className="p-3.5 rounded-xl bg-cyber-surface border border-cyber-border flex items-center justify-between">
                    <div className="truncate max-w-lg font-mono text-xs text-slate-200">
                      {link.url}
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono font-bold text-white">
                        Risk: {link.risk_score}/100
                      </span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        link.risk_level === 'CRITICAL' ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        {link.risk_level}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Actionable Protocol & Disclaimer */}
          {scanResult.recommendations && scanResult.recommendations.length > 0 && (
            <div className="p-6 rounded-2xl bg-cyber-card border border-cyber-border space-y-3">
              <h4 className="text-xs uppercase font-mono tracking-wider text-cyber-cyan font-bold">
                Actionable Defense Protocol
              </h4>
              <ul className="space-y-2 text-xs text-slate-300 font-sans">
                {scanResult.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <span className="text-cyber-cyan font-mono font-bold">[{i + 1}]</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
              <div className="pt-2 text-[11px] font-mono text-slate-500 border-t border-cyber-border/40">
                Notice: Natural language heuristics identify behavioral cues. Linguistic analysis alone cannot guarantee 100% certainty; always combine with out-of-band identity verification.
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};
