import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, Float, Boolean, Text, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship

from app.database.session import Base

class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default="user", nullable=False)  # "user" or "admin"
    organization = Column(String(150), default="Independent")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)

    # Relationships
    scans = relationship("Scan", back_populates="user", cascade="all, delete-orphan")
    reports = relationship("Report", back_populates="user", cascade="all, delete-orphan")
    settings = relationship("UserSettings", back_populates="user", uselist=False, cascade="all, delete-orphan")
    quiz_progress = relationship("QuizProgress", back_populates="user", cascade="all, delete-orphan")

class Scan(Base):
    __tablename__ = "scans"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    scan_type = Column(String(20), nullable=False, index=True)  # "url", "message", "domain"
    input_value = Column(Text, nullable=False)
    target_display = Column(String(255), nullable=True)
    risk_score = Column(Integer, nullable=False, default=0)
    risk_level = Column(String(20), nullable=False, default="LOW")  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    summary = Column(Text, nullable=True)
    result_json = Column(Text, nullable=False)  # JSON serialized full analysis
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User", back_populates="scans")
    reports = relationship("Report", back_populates="scan", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_scans_user_created", "user_id", "created_at"),
    )

class Threat(Base):
    __tablename__ = "threats"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    indicator = Column(String(255), unique=True, index=True, nullable=False)
    threat_type = Column(String(50), nullable=False, index=True)
    source = Column(String(100), nullable=False)
    confidence = Column(Integer, default=85)
    severity = Column(String(20), default="HIGH")  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    tags = Column(String(255), default="phishing,credential-harvesting")
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)

class Report(Base):
    __tablename__ = "reports"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    scan_id = Column(String(36), ForeignKey("scans.id"), nullable=False, index=True)
    report_code = Column(String(50), unique=True, index=True, nullable=False)
    report_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size_bytes = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="reports")
    scan = relationship("Scan", back_populates="reports")

class UserSettings(Base):
    __tablename__ = "user_settings"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), unique=True, nullable=False)
    theme = Column(String(20), default="dark")
    notifications_enabled = Column(Boolean, default=True)
    deep_analysis_enabled = Column(Boolean, default=True)
    auto_export_pdf = Column(Boolean, default=False)
    email_alerts = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="settings")

class QuizProgress(Base):
    __tablename__ = "quiz_progress"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    module_id = Column(String(50), nullable=False)
    module_title = Column(String(150), nullable=False)
    score = Column(Integer, default=0)
    passed = Column(Boolean, default=False)
    completed_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="quiz_progress")
