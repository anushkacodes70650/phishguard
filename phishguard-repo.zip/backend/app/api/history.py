import json
import csv
import io
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.orm import Session
from sqlalchemy import desc, asc

from app.database.session import get_db
from app.models import User, Scan
from app.schemas import ScanHistoryItem, ScanResponse
from app.core.security import get_current_user

router = APIRouter(prefix="/history", tags=["Scan History"])

@router.get("")
def list_scan_history(
    search: Optional[str] = None,
    scan_type: Optional[str] = None,
    risk_level: Optional[str] = None,
    sort_by: str = "created_at",
    order: str = "desc",
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Scan).filter(Scan.user_id == current_user.id)

    if search:
        search_filter = f"%{search.strip()}%"
        query = query.filter(
            (Scan.input_value.ilike(search_filter)) |
            (Scan.target_display.ilike(search_filter)) |
            (Scan.summary.ilike(search_filter))
        )

    if scan_type and scan_type.lower() != "all":
        query = query.filter(Scan.scan_type == scan_type.lower())

    if risk_level and risk_level.upper() != "ALL":
        query = query.filter(Scan.risk_level == risk_level.upper())

    # Sorting
    sort_col = getattr(Scan, sort_by, Scan.created_at)
    if order.lower() == "asc":
        query = query.order_by(asc(sort_col))
    else:
        query = query.order_by(desc(sort_col))

    total = query.count()
    items = query.offset((page - 1) * limit).limit(limit).all()

    return {
        "items": [
            {
                "id": s.id,
                "scan_type": s.scan_type,
                "input_value": s.input_value,
                "target_display": s.target_display,
                "risk_score": s.risk_score,
                "risk_level": s.risk_level,
                "summary": s.summary,
                "created_at": s.created_at
            }
            for s in items
        ],
        "total": total,
        "page": page,
        "limit": limit,
        "total_pages": (total + limit - 1) // limit if limit else 1
    }

@router.get("/export")
def export_history(
    format: str = Query("csv", regex="^(csv|json)$"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scans = db.query(Scan).filter(Scan.user_id == current_user.id).order_by(desc(Scan.created_at)).all()

    if format == "json":
        data = [
            {
                "id": s.id,
                "scan_type": s.scan_type,
                "input_value": s.input_value,
                "target": s.target_display,
                "risk_score": s.risk_score,
                "risk_level": s.risk_level,
                "summary": s.summary,
                "created_at": s.created_at.isoformat()
            }
            for s in scans
        ]
        return data

    # CSV Export
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Scan ID", "Type", "Target", "Risk Score", "Risk Level", "Summary", "Timestamp (UTC)"])

    for s in scans:
        writer.writerow([
            s.id,
            s.scan_type,
            s.target_display,
            s.risk_score,
            s.risk_level,
            s.summary,
            s.created_at.strftime("%Y-%m-%d %H:%M:%S")
        ])

    return Response(
        content=output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=phishguard_scans_{current_user.email.split('@')[0]}.csv"}
    )

@router.get("/{scan_id}", response_model=ScanResponse)
def get_scan_details(
    scan_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scan = db.query(Scan).filter(Scan.id == scan_id, Scan.user_id == current_user.id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan record not found or access denied.")

    return {
        "id": scan.id,
        "scan_type": scan.scan_type,
        "input_value": scan.input_value,
        "target_display": scan.target_display,
        "risk_score": scan.risk_score,
        "risk_level": scan.risk_level,
        "summary": scan.summary,
        "created_at": scan.created_at,
        "result": json.loads(scan.result_json)
    }

@router.delete("/{scan_id}")
def delete_scan(
    scan_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scan = db.query(Scan).filter(Scan.id == scan_id, Scan.user_id == current_user.id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan record not found.")

    db.delete(scan)
    db.commit()
    return {"message": "Scan record successfully deleted."}
