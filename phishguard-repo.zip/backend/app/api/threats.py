from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database.session import get_db
from app.models import Threat
from app.core.security import get_current_user
from app.intelligence.intel_service import intel_service

router = APIRouter(prefix="/threats", tags=["Threat Intelligence"])

@router.get("")
def get_threats(
    search: Optional[str] = None,
    threat_type: Optional[str] = None,
    severity: Optional[str] = None,
    limit: int = Query(25, ge=1, le=100),
    page: int = Query(1, ge=1),
    current_user = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Threat)

    if search:
        s_filt = f"%{search.strip()}%"
        query = query.filter(
            (Threat.indicator.ilike(s_filt)) |
            (Threat.threat_type.ilike(s_filt)) |
            (Threat.source.ilike(s_filt))
        )

    if threat_type and threat_type.lower() != "all":
        query = query.filter(Threat.threat_type.ilike(f"%{threat_type}%"))

    if severity and severity.upper() != "ALL":
        query = query.filter(Threat.severity == severity.upper())

    total = query.count()
    items = query.order_by(desc(Threat.last_seen)).offset((page - 1) * limit).limit(limit).all()

    return {
        "items": [
            {
                "id": t.id,
                "indicator": t.indicator,
                "threat_type": t.threat_type,
                "source": t.source,
                "confidence": t.confidence,
                "severity": t.severity,
                "tags": t.tags.split(",") if t.tags else [],
                "first_seen": t.first_seen,
                "last_seen": t.last_seen
            }
            for t in items
        ],
        "total": total,
        "page": page,
        "limit": limit
    }

@router.get("/statistics")
def get_threat_statistics(
    current_user = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    total = db.query(Threat).count()
    phishing = db.query(Threat).filter(Threat.threat_type.ilike("%phish%")).count()
    impersonation = db.query(Threat).filter(Threat.threat_type.ilike("%impersonation%")).count()
    malware = db.query(Threat).filter(Threat.threat_type.ilike("%malware%")).count()
    social_eng = db.query(Threat).filter(Threat.threat_type.ilike("%social%")).count()

    return {
        "total_threats": total,
        "phishing_count": phishing,
        "impersonation_count": impersonation,
        "malware_c2_count": malware,
        "social_eng_count": social_eng,
        "active_feeds": 4
    }

@router.get("/providers")
def get_threat_providers(
    current_user = Depends(get_current_user)
):
    return intel_service.get_provider_statuses()
