import json
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import User, Scan, Threat
from app.schemas import UrlScanRequest, MessageScanRequest, DomainScanRequest, ScanResponse
from app.core.security import get_current_user
from app.detection.url_detector import analyze_url
from app.detection.message_detector import analyze_message
from app.detection.domain_detector import analyze_domain

router = APIRouter(tags=["Detection & Scans"])

@router.post("/scan/url", response_model=ScanResponse)
def scan_url_endpoint(
    req: UrlScanRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    clean_url = req.url.strip()
    analysis = analyze_url(clean_url)

    # Save to Scan database
    new_scan = Scan(
        user_id=current_user.id,
        scan_type="url",
        input_value=clean_url,
        target_display=analysis.get("hostname") or clean_url[:40],
        risk_score=analysis["risk_score"],
        risk_level=analysis["risk_level"],
        summary=analysis["summary"],
        result_json=json.dumps(analysis),
        created_at=datetime.utcnow()
    )
    db.add(new_scan)

    # If critical or high risk, track in threat intelligence table if not already present
    if analysis["risk_score"] >= 60 and analysis.get("hostname"):
        existing_threat = db.query(Threat).filter(Threat.indicator == analysis["hostname"]).first()
        if not existing_threat:
            threat_rec = Threat(
                indicator=analysis["hostname"],
                threat_type="Phishing / Brand Impersonation" if analysis.get("metadata", {}).get("brand_flag") else "Malicious URL Pattern",
                source="PhishGuard Live Sensor",
                confidence=min(95, analysis["risk_score"] + 10),
                severity=analysis["risk_level"],
                tags="phishing,suspicious-url,live-detection",
                first_seen=datetime.utcnow(),
                last_seen=datetime.utcnow()
            )
            db.add(threat_rec)

    db.commit()
    db.refresh(new_scan)

    return {
        "id": new_scan.id,
        "scan_type": new_scan.scan_type,
        "input_value": new_scan.input_value,
        "target_display": new_scan.target_display,
        "risk_score": new_scan.risk_score,
        "risk_level": new_scan.risk_level,
        "summary": new_scan.summary,
        "created_at": new_scan.created_at,
        "result": analysis
    }

@router.get("/scan/url/{scan_id}", response_model=ScanResponse)
def get_url_scan(
    scan_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scan = db.query(Scan).filter(Scan.id == scan_id, Scan.user_id == current_user.id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan record not found.")

    return {
        "id": scan.id,
        "scan_type": scan.scan_type,
        "input_value": scan.input_value,
        "target_display": scan.target_display,
        "risk_score": scan.risk_score,
        "risk_level": scan.risk_level,
        "summary": scan.summary,
        "created_at": scan.created_at,
        "result": json.loads(scan.result_json)
    }

@router.post("/scan/message", response_model=ScanResponse)
def scan_message_endpoint(
    req: MessageScanRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    clean_text = req.message.strip()
    analysis = analyze_message(clean_text, req.sender_hint)

    display_snippet = clean_text[:60] + "..." if len(clean_text) > 60 else clean_text

    new_scan = Scan(
        user_id=current_user.id,
        scan_type="message",
        input_value=clean_text,
        target_display=display_snippet,
        risk_score=analysis["risk_score"],
        risk_level=analysis["risk_level"],
        summary=analysis["summary"],
        result_json=json.dumps(analysis),
        created_at=datetime.utcnow()
    )
    db.add(new_scan)
    db.commit()
    db.refresh(new_scan)

    return {
        "id": new_scan.id,
        "scan_type": new_scan.scan_type,
        "input_value": new_scan.input_value,
        "target_display": new_scan.target_display,
        "risk_score": new_scan.risk_score,
        "risk_level": new_scan.risk_level,
        "summary": new_scan.summary,
        "created_at": new_scan.created_at,
        "result": analysis
    }

@router.get("/scan/message/{scan_id}", response_model=ScanResponse)
def get_message_scan(
    scan_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scan = db.query(Scan).filter(Scan.id == scan_id, Scan.user_id == current_user.id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Message scan record not found.")

    return {
        "id": scan.id,
        "scan_type": scan.scan_type,
        "input_value": scan.input_value,
        "target_display": scan.target_display,
        "risk_score": scan.risk_score,
        "risk_level": scan.risk_level,
        "summary": scan.summary,
        "created_at": scan.created_at,
        "result": json.loads(scan.result_json)
    }

@router.post("/domain/analyze", response_model=ScanResponse)
def analyze_domain_endpoint(
    req: DomainScanRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    clean_domain = req.domain.strip()
    analysis = analyze_domain(clean_domain)

    new_scan = Scan(
        user_id=current_user.id,
        scan_type="domain",
        input_value=clean_domain,
        target_display=analysis.get("domain", clean_domain),
        risk_score=analysis["risk_score"],
        risk_level=analysis["risk_level"],
        summary=analysis["summary"],
        result_json=json.dumps(analysis),
        created_at=datetime.utcnow()
    )
    db.add(new_scan)
    db.commit()
    db.refresh(new_scan)

    return {
        "id": new_scan.id,
        "scan_type": new_scan.scan_type,
        "input_value": new_scan.input_value,
        "target_display": new_scan.target_display,
        "risk_score": new_scan.risk_score,
        "risk_level": new_scan.risk_level,
        "summary": new_scan.summary,
        "created_at": new_scan.created_at,
        "result": analysis
    }

@router.get("/domain/{domain}")
def get_domain_info(
    domain: str,
    current_user: User = Depends(get_current_user)
):
    return analyze_domain(domain)
