import os
import json
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database.session import get_db
from app.models import User, Scan, Report
from app.schemas import ReportResponse
from app.core.security import get_current_user
from app.reports.pdf_generator import generate_security_pdf_report

router = APIRouter(prefix="/reports", tags=["Security Reports"])

@router.get("")
def list_reports(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    reports = db.query(Report).filter(Report.user_id == current_user.id).order_by(desc(Report.created_at)).all()
    return [
        {
            "id": r.id,
            "scan_id": r.scan_id,
            "report_code": r.report_code,
            "report_name": r.report_name,
            "file_size_bytes": r.file_size_bytes,
            "created_at": r.created_at
        }
        for r in reports
    ]

@router.post("/generate/{scan_id}", response_model=ReportResponse)
def generate_report(
    scan_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scan = db.query(Scan).filter(Scan.id == scan_id, Scan.user_id == current_user.id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan record not found.")

    scan_data = {
        "id": scan.id,
        "scan_type": scan.scan_type,
        "input_value": scan.input_value,
        "target_display": scan.target_display,
        "risk_score": scan.risk_score,
        "risk_level": scan.risk_level,
        "summary": scan.summary,
        "result": json.loads(scan.result_json)
    }

    # Generate actual PDF file on disk
    file_path = generate_security_pdf_report(scan_data, current_user.email)
    file_size = os.path.getsize(file_path) if os.path.exists(file_path) else 0
    report_code = os.path.basename(file_path).replace(".pdf", "")

    new_report = Report(
        user_id=current_user.id,
        scan_id=scan.id,
        report_code=report_code,
        report_name=f"Forensic Assessment - {scan.target_display or scan.scan_type.upper()}",
        file_path=file_path,
        file_size_bytes=file_size,
        created_at=datetime.utcnow()
    )
    db.add(new_report)
    db.commit()
    db.refresh(new_report)

    return new_report

@router.get("/{report_id}/download")
def download_report(
    report_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    report = db.query(Report).filter(Report.id == report_id, Report.user_id == current_user.id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found.")

    if not os.path.exists(report.file_path):
        raise HTTPException(status_code=404, detail="Report file not found on disk.")

    return FileResponse(
        path=report.file_path,
        filename=f"{report.report_code}.pdf",
        media_type="application/pdf"
    )
