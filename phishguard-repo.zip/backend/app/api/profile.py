import json
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import User, UserSettings, Scan, Report
from app.schemas import (
    UserResponse,
    PasswordChangeRequest,
    UserSettingsResponse,
    UserSettingsUpdate,
    ProfileUpdate
)
from app.core.security import get_current_user, verify_password, get_password_hash

router = APIRouter(prefix="/profile", tags=["User Profile & Settings"])

@router.get("", response_model=UserResponse)
def get_profile(current_user: User = Depends(get_current_user)):
    return current_user

@router.put("", response_model=UserResponse)
def update_profile(
    req: ProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if req.name:
        current_user.name = req.name.strip()
    if req.organization is not None:
        current_user.organization = req.organization.strip()

    db.commit()
    db.refresh(current_user)
    return current_user

@router.put("/password")
def change_password(
    req: PasswordChangeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if not verify_password(req.current_password, current_user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect."
        )

    current_user.password_hash = get_password_hash(req.new_password)
    db.commit()
    return {"message": "Password successfully updated."}

@router.get("/settings", response_model=UserSettingsResponse)
def get_settings(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    user_settings = db.query(UserSettings).filter(UserSettings.user_id == current_user.id).first()
    if not user_settings:
        user_settings = UserSettings(user_id=current_user.id)
        db.add(user_settings)
        db.commit()
        db.refresh(user_settings)
    return user_settings

@router.put("/settings", response_model=UserSettingsResponse)
def update_settings(
    req: UserSettingsUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    user_settings = db.query(UserSettings).filter(UserSettings.user_id == current_user.id).first()
    if not user_settings:
        user_settings = UserSettings(user_id=current_user.id)
        db.add(user_settings)

    if req.theme is not None:
        user_settings.theme = req.theme
    if req.notifications_enabled is not None:
        user_settings.notifications_enabled = req.notifications_enabled
    if req.deep_analysis_enabled is not None:
        user_settings.deep_analysis_enabled = req.deep_analysis_enabled
    if req.auto_export_pdf is not None:
        user_settings.auto_export_pdf = req.auto_export_pdf
    if req.email_alerts is not None:
        user_settings.email_alerts = req.email_alerts

    user_settings.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(user_settings)
    return user_settings

@router.get("/export-data")
def export_personal_data(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scans = db.query(Scan).filter(Scan.user_id == current_user.id).all()
    reports = db.query(Report).filter(Report.user_id == current_user.id).all()

    return {
        "user_profile": {
            "id": current_user.id,
            "name": current_user.name,
            "email": current_user.email,
            "role": current_user.role,
            "organization": current_user.organization,
            "created_at": current_user.created_at.isoformat(),
        },
        "total_scans": len(scans),
        "scans": [
            {
                "id": s.id,
                "scan_type": s.scan_type,
                "input_value": s.input_value,
                "risk_score": s.risk_score,
                "risk_level": s.risk_level,
                "created_at": s.created_at.isoformat()
            }
            for s in scans
        ],
        "reports": [
            {
                "id": r.id,
                "report_code": r.report_code,
                "report_name": r.report_name,
                "created_at": r.created_at.isoformat()
            }
            for r in reports
        ]
    }

@router.delete("/account")
def delete_account(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    db.delete(current_user)
    db.commit()
    return {"message": "User account and all associated telemetry successfully deleted."}
