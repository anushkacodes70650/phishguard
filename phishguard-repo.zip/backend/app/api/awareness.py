from datetime import datetime
from typing import List, Dict, Any
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import User, QuizProgress
from app.schemas import QuizSubmitRequest
from app.core.security import get_current_user

router = APIRouter(prefix="/awareness", tags=["Awareness Center"])

MODULES_DATA = [
    {
        "id": "module_phishing_core",
        "title": "Phishing Foundations & Deception Psychology",
        "badge": "Threat Identifier",
        "category": "Foundations",
        "reading_time": "5 min",
        "summary": "Understand the core taxonomy of deceptive cyber attacks, urgency levers, and cognitive manipulation tactics.",
        "content": [
            {
                "subheading": "The Anatomy of Modern Phishing",
                "body": "Phishing is not merely a spam email; it is a calculated psychological exploitation attack designed to elicit immediate, fear-driven compliance. Attackers disguise themselves as high-trust entities (financial institutions, cloud identity providers, tax agencies) to harvest authentication tokens, session cookies, or initiate unauthorized transactions."
            },
            {
                "subheading": "The Six Psychological Triggers",
                "body": "Attackers leverage six fundamental behavioral triggers: (1) Urgency ('Account suspended in 2 hours'), (2) Authority ('Action requested by Legal / IT Security'), (3) Fear ('Immediate legal arrest warrant issued'), (4) Greed ('Unclaimed \$1,500 holiday bonus voucher'), (5) Curiosity ('Confidential Q4 layoff roster leaked'), and (6) Helpfulness ('Colleague locked out of client VPN')."
            }
        ],
        "quiz": [
            {
                "question": "Which cognitive manipulation tactic is most commonly used in account suspension emails?",
                "options": [
                    "Artificial urgency to bypass critical thinking",
                    "Polite requests with flexible deadlines",
                    "Technical cryptographic proofs",
                    "Detailed privacy policy disclosures"
                ],
                "correct_index": 0,
                "explanation": "Attackers introduce urgent deadlines ('within 24 hours') to trigger panic and reduce rational deliberation."
            },
            {
                "question": "An email arrives from 'security@paypa1-update.com'. What technique is being employed?",
                "options": [
                    "Direct Denial of Service (DDoS)",
                    "Typosquatting / Character Substitution Spoofing",
                    "SQL Injection attack",
                    "Session hijacking"
                ],
                "correct_index": 1,
                "explanation": "The numeral '1' is substituted for the letter 'l' in 'paypal', an example of visually deceptively similar typosquatting."
            }
        ]
    },
    {
        "id": "module_fake_websites",
        "title": "Identifying Fraudulent Domains & Homographs",
        "badge": "Domain Sentinel",
        "category": "Web Security",
        "reading_time": "6 min",
        "summary": "Master IDN homoglyphs, sub-domain stacking, and deceptive SSL locks.",
        "content": [
            {
                "subheading": "The Myth of the 'Secure' Padlock",
                "body": "The presence of HTTPS (the browser padlock) ONLY guarantees that connection traffic is encrypted in transit—it does NOT mean the recipient domain is trustworthy. Over 80% of modern phishing landing pages now use free automated SSL certificates (such as Let's Encrypt or Cloudflare) to convey false legitimacy."
            },
            {
                "subheading": "Internationalized Domain Name (IDN) Homoglyphs",
                "body": "Attackers substitute Latin letters with visually identical Cyrillic or Greek characters (e.g., Cyrillic 'а' U+0430 for Latin 'a' U+0061). Browsers convert these into Punycode (e.g. 'xn--...'). Always inspect the raw address bar before entering master credentials."
            }
        ],
        "quiz": [
            {
                "question": "Does having an HTTPS padlock on a website prove that the site is safe and authentic?",
                "options": [
                    "No; HTTPS only encrypts the traffic, malicious sites frequently obtain free SSL certificates",
                    "Yes; only verified Fortune 500 corporations can acquire SSL certificates",
                    "Yes; search engines block SSL on unauthorized websites automatically",
                    "Only if the website is hosted on AWS"
                ],
                "correct_index": 0,
                "explanation": "HTTPS only ensures channel encryption; threat actors readily acquire free TLS certs for fraudulent domains."
            },
            {
                "question": "What is the primary indicator of an Internationalized Domain Name (Punycode) spoof?",
                "options": [
                    "The URL hostname begins with 'xn--'",
                    "The URL starts with port 8080",
                    "The website uses dark mode",
                    "The site lacks a favicon"
                ],
                "correct_index": 0,
                "explanation": "IDN domains containing foreign non-ASCII characters are represented in Punycode format with the prefix 'xn--'."
            }
        ]
    },
    {
        "id": "module_smishing_quishing",
        "title": "Smishing (SMS) & Quishing (QR Code Phishing)",
        "badge": "Mobile Defense Specialist",
        "category": "Emerging Vectors",
        "reading_time": "5 min",
        "summary": "Defend against SMS parcel delivery scams, bank text alerts, and malicious physical QR code overlays.",
        "content": [
            {
                "subheading": "Smishing: The Mobile Perimeter Attack",
                "body": "SMS messages have an open rate exceeding 98%. Attackers leverage SMS spoofing to inject fake notifications into legitimate bank SMS threads. Common themes include 'USPS: Address incomplete for package redelivery' or 'Bank Alert: Wire attempted. Reply NO to decline or click link'."
            },
            {
                "subheading": "Quishing: Weaponized Physical & Digital QR Codes",
                "body": "QR codes circumvent traditional enterprise email text filters because the payload URL is encoded inside a matrix barcode image. Attackers place physical stickers over legitimate parking meters or send multi-factor setup PDF emails featuring QR codes."
            }
        ],
        "quiz": [
            {
                "question": "Why do phishing actors increasingly embed QR codes (Quishing) in emails?",
                "options": [
                    "QR codes bypass text-based automated email gateway filters and shift victims to unmonitored mobile devices",
                    "QR codes consume less bandwidth on the mail server",
                    "Mobile phones do not support web browsers",
                    "QR codes are required by Federal cybersecurity guidelines"
                ],
                "correct_index": 0,
                "explanation": "QR codes hide malicious links inside image pixels, evading text-based email security filters and pushing users onto personal phones without corporate protections."
            }
        ]
    },
    {
        "id": "module_social_eng_bec",
        "title": "Business Email Compromise (BEC) & Spear Phishing",
        "badge": "Executive Defender",
        "category": "Enterprise Threat",
        "reading_time": "7 min",
        "summary": "Recognize CEO gift card requests, vendor wire diversion, and invoice manipulation fraud.",
        "content": [
            {
                "subheading": "Business Email Compromise (BEC)",
                "body": "BEC attacks rarely contain malware or hyperlinks. Instead, attackers spend weeks conducting open-source intelligence (OSINT) on LinkedIn to learn organizational hierarchies, supplier relationships, and billing cycles. They then impersonate executives requesting urgent gift cards, payroll account switches, or emergency vendor wire updates."
            },
            {
                "subheading": "Out-of-Band Verification Protocol",
                "body": "The definitive countermeasure to wire fraud and executive impersonation is establishing a strict out-of-band verification policy: any modification of banking wiring instructions or emergency gift card requests must be confirmed verbally via a pre-established verified internal phone number."
            }
        ],
        "quiz": [
            {
                "question": "What is the most effective operational defense against Business Email Compromise (BEC) invoice fraud?",
                "options": [
                    "Mandatory out-of-band verbal phone confirmation via a known, pre-established contact number",
                    "Replying directly to the email asking if the CEO really sent it",
                    "Changing the font color to red in accounting",
                    "Waiting 30 days before paying any bills"
                ],
                "correct_index": 0,
                "explanation": "Always confirm financial instruction changes via an independent out-of-band communication channel."
            }
        ]
    }
]

@router.get("/modules")
def get_awareness_modules(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    progress_records = db.query(QuizProgress).filter(QuizProgress.user_id == current_user.id).all()
    progress_map = {p.module_id: {"score": p.score, "passed": p.passed} for p in progress_records}

    result = []
    for m in MODULES_DATA:
        p = progress_map.get(m["id"], {"score": 0, "passed": False})
        result.append({
            **m,
            "user_score": p["score"],
            "user_passed": p["passed"]
        })
    return result

@router.post("/quiz")
def submit_quiz_score(
    req: QuizSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    progress = db.query(QuizProgress).filter(
        QuizProgress.user_id == current_user.id,
        QuizProgress.module_id == req.module_id
    ).first()

    if not progress:
        progress = QuizProgress(
            user_id=current_user.id,
            module_id=req.module_id,
            module_title=req.module_title,
            score=req.score,
            passed=req.passed,
            completed_at=datetime.utcnow()
        )
        db.add(progress)
    else:
        progress.score = max(progress.score, req.score)
        progress.passed = progress.passed or req.passed
        progress.completed_at = datetime.utcnow()

    db.commit()
    db.refresh(progress)

    return {
        "module_id": progress.module_id,
        "score": progress.score,
        "passed": progress.passed,
        "message": "Quiz results recorded successfully."
    }
