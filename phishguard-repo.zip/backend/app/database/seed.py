import json
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from app.database.session import SessionLocal, Base, engine
from app.models import User, UserSettings, Scan, Threat, Report, QuizProgress
from app.core.security import get_password_hash
from app.detection.url_detector import analyze_url
from app.detection.message_detector import analyze_message
from app.detection.domain_detector import analyze_domain
from app.reports.pdf_generator import generate_security_pdf_report

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Check if already seeded
        if db.query(User).filter(User.email == "admin@phishguard.ai").first():
            print("Database already contains admin account. Skipping seed.")
            return

        print("Seeding database with PhishGuard cybersecurity telemetry...")

        # 1. Admin User
        admin_user = User(
            name="Chief Security Officer",
            email="admin@phishguard.ai",
            password_hash=get_password_hash("Admin@PhishGuard2026!"),
            role="admin",
            organization="PhishGuard Cyber Defense Command",
            created_at=datetime.utcnow() - timedelta(days=60),
            last_login=datetime.utcnow()
        )
        db.add(admin_user)
        db.flush()

        admin_settings = UserSettings(
            user_id=admin_user.id,
            theme="dark",
            notifications_enabled=True,
            deep_analysis_enabled=True,
            auto_export_pdf=True,
            email_alerts=True
        )
        db.add(admin_settings)

        # 2. Analyst User
        analyst_user = User(
            name="Alex Mercer",
            email="analyst@phishguard.ai",
            password_hash=get_password_hash("Analyst@PhishGuard2026!"),
            role="user",
            organization="Threat Analysis Unit",
            created_at=datetime.utcnow() - timedelta(days=30),
            last_login=datetime.utcnow()
        )
        db.add(analyst_user)
        db.flush()

        analyst_settings = UserSettings(
            user_id=analyst_user.id,
            theme="dark",
            notifications_enabled=True,
            deep_analysis_enabled=True,
            auto_export_pdf=False,
            email_alerts=True
        )
        db.add(analyst_settings)

        # 3. Threat Intelligence Database Feed
        threats_data = [
            ("paypal-security-center.xyz", "Phishing / Brand Impersonation", "URLhaus Threat Feed", 96, "CRITICAL", "paypal,credential-harvesting,phish"),
            ("login-microsoft-auth-verify.top", "Brand Impersonation", "PhishTank Global Database", 92, "CRITICAL", "microsoft,mfa-bypass,phish"),
            ("netflix-billing-update-account.buzz", "Credential Harvester", "PhishGuard Threat Network", 88, "HIGH", "netflix,credit-card-theft"),
            ("chase-bank-secure-alert.cc", "Financial Phishing", "URLhaus Threat Feed", 95, "CRITICAL", "banking,chase,wire-fraud"),
            ("apple-support-icloud-device.rest", "Account Takeover", "PhishTank Global Database", 91, "HIGH", "apple,icloud,id-theft"),
            ("dhl-express-package-redelivery.monster", "Smishing Lure Endpoint", "PhishGuard Threat Network", 85, "HIGH", "package-scam,smishing"),
            ("binance-asset-recovery-portal.sbs", "Crypto Phishing", "URLhaus Threat Feed", 98, "CRITICAL", "crypto,wallet-drainer"),
            ("usps-tracking-package-verify.info", "Postal Smishing", "PhishTank Global Database", 89, "HIGH", "usps,parcel-fraud"),
            ("steam-community-trade-gift.click", "Gaming Credential Theft", "PhishGuard Threat Network", 82, "HIGH", "steam,inventory-theft"),
            ("wellsfargo-online-protection.live", "Banking Credential Theft", "URLhaus Threat Feed", 94, "CRITICAL", "wellsfargo,banking")
        ]

        for ind, t_type, src, conf, sev, tags in threats_data:
            t = Threat(
                indicator=ind,
                threat_type=t_type,
                source=src,
                confidence=conf,
                severity=sev,
                tags=tags,
                first_seen=datetime.utcnow() - timedelta(days=5),
                last_seen=datetime.utcnow() - timedelta(hours=2)
            )
            db.add(t)

        # 4. Realistic Scan History for Analyst User
        scans_to_create = [
            # High-risk phishing URL
            ("url", "https://paypal-security-account-verification.xyz/login?redirect=evil.com", datetime.utcnow() - timedelta(hours=2)),
            # Legitimate safe URL
            ("url", "https://google.com/search?q=cybersecurity", datetime.utcnow() - timedelta(hours=8)),
            # URL shortener
            ("url", "https://bit.ly/3x8QzL", datetime.utcnow() - timedelta(days=1)),
            # High-risk spoof message
            ("message", "Your Wells Fargo account has been suspended due to suspicious activity. Verify your identity immediately using this link or legal action will be initiated within 24 hours.", datetime.utcnow() - timedelta(days=2)),
            # Clean safe message
            ("message", "Hi Alex, please find the Q3 cybersecurity architecture review attached. Let's discuss on Tuesday's sync.", datetime.utcnow() - timedelta(days=3)),
            # Suspicious Domain
            ("domain", "paypal-security-update.xyz", datetime.utcnow() - timedelta(days=4)),
            # Clean Domain
            ("domain", "github.com", datetime.utcnow() - timedelta(days=5)),
        ]

        saved_scans = []
        for s_type, s_input, s_time in scans_to_create:
            if s_type == "url":
                analysis = analyze_url(s_input)
                target_disp = analysis.get("hostname")
            elif s_type == "message":
                analysis = analyze_message(s_input)
                target_disp = s_input[:40] + "..."
            else:
                analysis = analyze_domain(s_input)
                target_disp = s_input

            scan_obj = Scan(
                user_id=analyst_user.id,
                scan_type=s_type,
                input_value=s_input,
                target_display=target_disp,
                risk_score=analysis["risk_score"],
                risk_level=analysis["risk_level"],
                summary=analysis["summary"],
                result_json=json.dumps(analysis),
                created_at=s_time
            )
            db.add(scan_obj)
            db.flush()
            saved_scans.append((scan_obj, analysis))

        # Generate a sample PDF report for the first high-risk scan
        if saved_scans:
            first_scan, first_analysis = saved_scans[0]
            scan_data = {
                "id": first_scan.id,
                "scan_type": first_scan.scan_type,
                "input_value": first_scan.input_value,
                "target_display": first_scan.target_display,
                "risk_score": first_scan.risk_score,
                "risk_level": first_scan.risk_level,
                "summary": first_scan.summary,
                "result": first_analysis
            }
            pdf_path = generate_security_pdf_report(scan_data, analyst_user.email)
            rep = Report(
                user_id=analyst_user.id,
                scan_id=first_scan.id,
                report_code=f"PG-REP-{datetime.utcnow().strftime('%Y%m%d')}-001",
                report_name=f"Forensic Assessment - {first_scan.target_display}",
                file_path=pdf_path,
                file_size_bytes=42000,
                created_at=datetime.utcnow() - timedelta(hours=1)
            )
            db.add(rep)

        # 5. Quiz progress
        quiz_item = QuizProgress(
            user_id=analyst_user.id,
            module_id="module_phishing_core",
            module_title="Phishing Foundations & Deception Psychology",
            score=100,
            passed=True,
            completed_at=datetime.utcnow() - timedelta(days=2)
        )
        db.add(quiz_item)

        db.commit()
        print("Database successfully seeded with realistic accounts, threat feeds, and scan records.")

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
    finally:
        db.close()
