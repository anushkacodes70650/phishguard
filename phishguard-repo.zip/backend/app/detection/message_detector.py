import re
from typing import Dict, Any, List
from app.detection.url_detector import analyze_url

# Pattern dictionaries with category and risk weighting
PSYCHOLOGICAL_PATTERNS = [
    {
        "category": "Urgency & Time Pressure",
        "severity": "HIGH",
        "weight": 22,
        "regex": r"\b(immediately|within\s+(?:24|12|48|2|1)\s*hours?|expires\s+today|act\s+now|urgent\s+action|before\s+it(?:'?s|\s+is)\s+too\s+late|instant\s+verification|right\s+away)\b",
        "explanation": "Creates artificial panic and urgency to rush the recipient into acting without thinking."
    },
    {
        "category": "Threatening & Fear Language",
        "severity": "CRITICAL",
        "weight": 28,
        "regex": r"\b(suspended|account\s+will\s+be\s+terminated|permanently\s+disabled|legal\s+action|lawsuit|arrest\s+warrant|police|prosecution|unauthorized\s+access\s+detected|frozen|restricted|security\s+breach)\b",
        "explanation": "Uses intimidating or punitive threats to bypass rational skepticism."
    },
    {
        "category": "Credential Harvesting",
        "severity": "CRITICAL",
        "weight": 35,
        "regex": r"\b(verify\s+your\s+(?:password|pin|identity|ssn|social\s+security)|confirm\s+your\s+(?:login|credentials|details)|enter\s+your\s+password|update\s+security\s+questions|provide\s+your\s+(?:otp|code)|reset\s+password\s+now)\b",
        "explanation": "Solicits private authentication credentials or multi-factor verification tokens."
    },
    {
        "category": "Suspicious Financial / Payment Request",
        "severity": "HIGH",
        "weight": 25,
        "regex": r"\b(wire\s+transfer|bitcoin|crypto\s+wallet|update\s+billing\s+info|overdue\s+invoice|payment\s+declined|bank\s+account\s+verification|direct\s+deposit|gift\s+cards?|western\s+union)\b",
        "explanation": "Attempts to initiate untraceable funds transfer or compromise banking details."
    },
    {
        "category": "Prize & Reward Lures",
        "severity": "HIGH",
        "weight": 22,
        "regex": r"\b(you\s+(?:have\s+)?won|lottery\s+winner|congratulations!\s*you|claim\s+your\s+(?:prize|\$|cash|reward|gift\s+card)|selected\s+for\s+a\s+free|100%\s+free\s+voucher)\b",
        "explanation": "Exploits greed and curiosity with fraudulent financial incentives."
    },
    {
        "category": "Authority & Impersonation",
        "severity": "MEDIUM",
        "weight": 18,
        "regex": r"\b(it\s+support\s+desk|system\s+administrator|internal\s+revenue\s+service|irs\s+notice|fbi\s+alert|bank\s+fraud\s+department|ceo\s+office|security\s+team\s+bulletin)\b",
        "explanation": "Fabricates administrative authority to manipulate compliance."
    }
]

# URL extraction pattern
URL_REGEX = r'(https?://[^\s<>"]+|www\.[^\s<>"]+)'

def analyze_message(text: str, sender_hint: str = None) -> Dict[str, Any]:
    """
    Parses message for psychological manipulation, extracted links, credential hooks,
    and identifies exact spans for UI highlighting.
    """
    if not text or not text.strip():
        return {
            "risk_score": 0,
            "risk_level": "LOW",
            "summary": "Empty input provided.",
            "suspicious_spans": [],
            "psychological_triggers": [],
            "embedded_urls": [],
            "reasons": [],
            "recommendations": []
        }

    detected_triggers: List[Dict[str, Any]] = []
    suspicious_spans: List[Dict[str, Any]] = []
    base_score = 0
    reasons: List[str] = []
    recommendations: List[str] = []

    # 1. Analyze text against psychological patterns
    for pattern in PSYCHOLOGICAL_PATTERNS:
        matches = list(re.finditer(pattern["regex"], text, re.IGNORECASE))
        if matches:
            base_score += pattern["weight"]
            category_matches = []
            for m in matches:
                span_text = m.group(0)
                category_matches.append(span_text)
                suspicious_spans.append({
                    "start": m.start(),
                    "end": m.end(),
                    "text": span_text,
                    "category": pattern["category"],
                    "severity": pattern["severity"]
                })
            
            detected_triggers.append({
                "category": pattern["category"],
                "severity": pattern["severity"],
                "occurrences": len(matches),
                "matched_phrases": list(set(category_matches)),
                "explanation": pattern["explanation"]
            })
            reasons.append(f"{pattern['category']}: Detected phrases such as '{category_matches[0]}'.")

    # 2. Extract and inspect embedded links
    extracted_urls = re.findall(URL_REGEX, text)
    embedded_url_results: List[Dict[str, Any]] = []
    max_url_risk = 0

    for link in extracted_urls:
        url_analysis = analyze_url(link)
        embedded_url_results.append({
            "url": link,
            "risk_score": url_analysis["risk_score"],
            "risk_level": url_analysis["risk_level"],
            "summary": url_analysis["summary"],
            "failed_checks": url_analysis["failed_checks"]
        })
        if url_analysis["risk_score"] > max_url_risk:
            max_url_risk = url_analysis["risk_score"]

    if extracted_urls:
        if max_url_risk >= 60:
            base_score += 40
            reasons.append(f"Contains high-risk embedded link with risk score of {max_url_risk}/100.")
        elif max_url_risk >= 30:
            base_score += 20
            reasons.append("Contains link exhibiting moderate risk factors.")
        else:
            base_score += 10
            reasons.append("Contains external clickable link.")

    # 3. Sender hint check
    if sender_hint:
        clean_sender = sender_hint.lower().strip()
        suspicious_sender_indicators = ["@gmail.com", "@yahoo.com", "@hotmail.com"]
        if any(brand in text.lower() for brand in ["bank", "paypal", "apple", "microsoft", "amazon"]):
            if any(clean_sender.endswith(free_domain) for free_domain in suspicious_sender_indicators):
                base_score += 30
                sender_reason = f"Sender mismatch: Claimed corporate notification sent from free webmail ({sender_hint})."
                reasons.append(sender_reason)
                detected_triggers.append({
                    "category": "Sender Identity Discrepancy",
                    "severity": "CRITICAL",
                    "occurrences": 1,
                    "matched_phrases": [sender_hint],
                    "explanation": sender_reason
                })

    # Calculate final score
    risk_score = min(100, max(0, base_score))

    if risk_score >= 80:
        risk_level = "CRITICAL"
    elif risk_score >= 60:
        risk_level = "HIGH"
    elif risk_score >= 30:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    # Actionable guidance
    if risk_level in ["CRITICAL", "HIGH"]:
        recommendations.extend([
            "DO NOT click any embedded links or call phone numbers contained in this message.",
            "DO NOT provide any personal, financial, or account verification credentials.",
            "Verify with the genuine organization via their verified website or phone app independently.",
            "Report this message as Phishing/Spam in your client application."
        ])
    elif risk_level == "MEDIUM":
        recommendations.extend([
            "Approach with caution. Validate the sender's identity through a secondary channel.",
            "Inspect any links manually before opening.",
            "Legitimate organizations rarely demand immediate account verification via text or email."
        ])
    else:
        recommendations.extend([
            "No strong indicators of phishing identified based on keyword and structural patterns.",
            "Note: Language analysis alone cannot provide 100% certainty. Always exercise reasonable judgment.",
            "Never share passwords or MFA codes regardless of how convincing an inbound message appears."
        ])

    summary = (
        f"Critical Phishing Likelihood: {len(detected_triggers)} psychological manipulation triggers identified."
        if risk_level in ["CRITICAL", "HIGH"]
        else f"Suspicious Indicators: {len(detected_triggers)} alert patterns found."
        if risk_level == "MEDIUM"
        else "No typical social engineering triggers detected. Low apparent risk."
    )

    return {
        "risk_score": risk_score,
        "risk_level": risk_level,
        "summary": summary,
        "input_length": len(text),
        "total_triggers": len(detected_triggers),
        "psychological_triggers": detected_triggers,
        "suspicious_spans": suspicious_spans,
        "embedded_urls": embedded_url_results,
        "reasons": reasons,
        "recommendations": recommendations,
        "sender_hint": sender_hint
    }
