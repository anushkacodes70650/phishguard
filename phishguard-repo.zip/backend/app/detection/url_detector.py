import re
import math
import ipaddress
from urllib.parse import urlparse, parse_qs
from typing import Dict, Any, List, Tuple

# Well-known brands often targeted by phishing
TARGETED_BRANDS = {
    "paypal": ["paypal.com"],
    "apple": ["apple.com", "icloud.com"],
    "microsoft": ["microsoft.com", "live.com", "office.com", "outlook.com"],
    "google": ["google.com", "gmail.com", "accounts.google.com"],
    "netflix": ["netflix.com"],
    "chase": ["chase.com"],
    "wellsfargo": ["wellsfargo.com"],
    "bankofamerica": ["bankofamerica.com", "bofa.com"],
    "amazon": ["amazon.com", "aws.amazon.com"],
    "meta": ["meta.com", "facebook.com", "instagram.com", "whatsapp.com"],
    "instagram": ["instagram.com"],
    "facebook": ["facebook.com"],
    "binance": ["binance.com"],
    "coinbase": ["coinbase.com"],
    "steam": ["steampowered.com", "steamcommunity.com"],
    "dhl": ["dhl.com"],
    "fedex": ["fedex.com"],
    "usps": ["usps.com"],
}

# High-risk / abuse-prone TLDs
HIGH_RISK_TLDS = {
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "buzz", "club",
    "work", "click", "fit", "country", "surf", "rest", "cam", "kim",
    "cn", "ru", "monster", "sbs"
}

# URL shorteners
URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "is.gd", "buff.ly", "ow.ly",
    "cutt.ly", "rebrand.ly", "tiny.cc", "goo.gl", "bit.do"
}

# Confusable homograph map (Cyrillic/Greek to Latin)
HOMOGLYPHS = {
    '\u0430': 'a', '\u0441': 'c', '\u0435': 'e', '\u043e': 'o',
    '\u0440': 'p', '\u0455': 's', '\u0445': 'x', '\u0443': 'y',
    '\u0456': 'i', '\u0458': 'j', '\u03bf': 'o', '\u03c1': 'p',
    '\u03b1': 'a', '\u03bd': 'v'
}

def calculate_shannon_entropy(text: str) -> float:
    """Calculate Shannon entropy to detect random algorithmically generated strings (DGA)."""
    if not text:
        return 0.0
    entropy = 0.0
    length = len(text)
    for char in set(text):
        p_x = text.count(char) / length
        entropy += - p_x * math.log2(p_x)
    return round(entropy, 3)

def check_ssrf_safety(hostname: str) -> Tuple[bool, str]:
    """Strictly prevent SSRF: block private IPs, loopbacks, and cloud metadata."""
    if not hostname:
        return False, "Empty host"

    clean_host = hostname.strip().lower()
    if clean_host in ["localhost", "127.0.0.1", "0.0.0.0", "::1", "metadata.google.internal"]:
        return False, f"Prohibited loopback/internal hostname: {hostname}"

    # Check if host is raw IP
    try:
        ip = ipaddress.ip_address(clean_host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return False, f"Prohibited private/reserved IP address: {hostname}"
        # Cloud metadata address check
        if str(ip) == "169.254.169.254":
            return False, "Prohibited cloud instance metadata IP"
    except ValueError:
        # Not a raw IP, domain string is fine for SSRF guard
        pass

    return True, "SSRF validation passed"

def analyze_url(raw_url: str) -> Dict[str, Any]:
    """
    Examines URL structure, domain characteristics, homographs, brand spoofing,
    entropy, and redirects without navigating or fetching external resources.
    """
    url_to_parse = raw_url.strip()
    if not url_to_parse.startswith(("http://", "https://")):
        url_to_parse = "https://" + url_to_parse

    parsed = urlparse(url_to_parse)
    hostname = (parsed.hostname or "").lower()
    path = parsed.path or ""
    query = parsed.query or ""

    checks: List[Dict[str, Any]] = []
    risk_score = 0
    reasons: List[str] = []
    recommendations: List[str] = []

    # 1. SSRF & Scheme validation
    ssrf_ok, ssrf_msg = check_ssrf_safety(hostname)
    if not ssrf_ok:
        return {
            "risk_score": 100,
            "risk_level": "CRITICAL",
            "is_ssrf_risk": True,
            "target": raw_url,
            "summary": "Access blocked: Target resolves to restricted or private infrastructure (SSRF Guard).",
            "passed_checks": [],
            "failed_checks": [{
                "id": "ssrf_guard",
                "title": "SSRF & Internal IP Defense",
                "category": "Infrastructure Safety",
                "passed": False,
                "severity": "CRITICAL",
                "description": ssrf_msg,
                "evidence": hostname
            }],
            "reasons": [ssrf_msg],
            "recommendations": ["Do not attempt to scan internal network devices or cloud metadata services."]
        }

    # 2. Scheme check
    is_https = parsed.scheme == "https"
    if not is_https:
        risk_score += 15
        reasons.append("Unencrypted HTTP protocol detected. Sensitive data can be intercepted.")
        checks.append({
            "id": "ssl_scheme",
            "title": "HTTPS Encryption",
            "category": "Transport Security",
            "passed": False,
            "severity": "MEDIUM",
            "description": "The URL uses plain unencrypted HTTP instead of HTTPS.",
            "evidence": parsed.scheme
        })
    else:
        checks.append({
            "id": "ssl_scheme",
            "title": "HTTPS Encryption",
            "category": "Transport Security",
            "passed": True,
            "severity": "LOW",
            "description": "Standard HTTPS transport protocol is utilized.",
            "evidence": "https://"
        })

    # 3. IP address host check
    is_ip_host = False
    try:
        ipaddress.ip_address(hostname)
        is_ip_host = True
        risk_score += 35
        reasons.append("Direct IP address used instead of a registered domain name, common in phishing and malware drop sites.")
        checks.append({
            "id": "ip_host",
            "title": "Domain Name Resolution",
            "category": "Domain Integrity",
            "passed": False,
            "severity": "HIGH",
            "description": "URL bypasses DNS domain naming and directly points to a numeric IP address.",
            "evidence": hostname
        })
    except ValueError:
        checks.append({
            "id": "ip_host",
            "title": "Domain Name Resolution",
            "category": "Domain Integrity",
            "passed": True,
            "severity": "LOW",
            "description": "Valid fully qualified domain name structure.",
            "evidence": hostname
        })

    # 4. Homograph & Punycode detection
    punycode_detected = "xn--" in hostname
    confusables_found = [c for c in raw_url if c in HOMOGLYPHS]
    
    if punycode_detected or len(confusables_found) > 0:
        risk_score += 40
        homo_desc = "Internationalized Domain Name (Punycode xn--) or mixed-script homoglyphs detected. High likelihood of visual spoofing."
        reasons.append(homo_desc)
        checks.append({
            "id": "homoglyph_spoof",
            "title": "IDN & Homograph Confusable Detection",
            "category": "Identity Verification",
            "passed": False,
            "severity": "CRITICAL",
            "description": homo_desc,
            "evidence": f"Punycode: {punycode_detected}, Homoglyphs: {''.join(confusables_found)}"
        })
    else:
        checks.append({
            "id": "homoglyph_spoof",
            "title": "IDN & Homograph Confusable Detection",
            "category": "Identity Verification",
            "passed": True,
            "severity": "LOW",
            "description": "No Cyrillic or confusable internationalized domain spoofing found.",
            "evidence": "Standard ASCII character set"
        })

    # 5. High-risk TLD check
    tld = hostname.split(".")[-1] if "." in hostname else ""
    if tld in HIGH_RISK_TLDS:
        risk_score += 25
        reasons.append(f"Domain uses high-abuse top-level domain (.{tld}) frequently leveraged by disposable phishing campaigns.")
        checks.append({
            "id": "tld_reputation",
            "title": "TLD Risk Classification",
            "category": "Reputation Heuristics",
            "passed": False,
            "severity": "MEDIUM",
            "description": f"The top-level domain '.{tld}' is classified in the elevated threat category.",
            "evidence": f".{tld}"
        })
    else:
        checks.append({
            "id": "tld_reputation",
            "title": "TLD Risk Classification",
            "category": "Reputation Heuristics",
            "passed": True,
            "severity": "LOW",
            "description": f"Standard enterprise or general TLD (.{tld}).",
            "evidence": f".{tld}"
        })

    # 6. Brand Impersonation Analysis
    brand_impersonated = None
    domain_parts = hostname.split(".")
    second_level_domain = domain_parts[-2] if len(domain_parts) >= 2 else hostname

    for brand, legit_domains in TARGETED_BRANDS.items():
        if brand in hostname:
            # Check if it is the genuine domain
            is_legit = any(hostname == ld or hostname.endswith("." + ld) for ld in legit_domains)
            if not is_legit:
                brand_impersonated = brand
                break

    if brand_impersonated:
        risk_score += 45
        brand_reason = f"Targeted brand impersonation: '{brand_impersonated.upper()}' appears in the hostname, but the domain is not legitimate official infrastructure."
        reasons.append(brand_reason)
        checks.append({
            "id": "brand_impersonation",
            "title": "Brand Impersonation Defense",
            "category": "Social Engineering",
            "passed": False,
            "severity": "CRITICAL",
            "description": brand_reason,
            "evidence": f"Brand token '{brand_impersonated}' found on unauthorized host '{hostname}'"
        })
    else:
        checks.append({
            "id": "brand_impersonation",
            "title": "Brand Impersonation Defense",
            "category": "Social Engineering",
            "passed": True,
            "severity": "LOW",
            "description": "No known enterprise brand tokens or trademark misalignments detected.",
            "evidence": "Clean identity attribution"
        })

    # 7. URL Shortener check
    if hostname in URL_SHORTENERS:
        risk_score += 20
        reasons.append("URL shortener service detected. Obfuscates the actual final destination.")
        checks.append({
            "id": "url_shortener",
            "title": "Destination Transparency",
            "category": "Obfuscation",
            "passed": False,
            "severity": "MEDIUM",
            "description": "Shortened link obscures real endpoint target.",
            "evidence": hostname
        })
    else:
        checks.append({
            "id": "url_shortener",
            "title": "Destination Transparency",
            "category": "Obfuscation",
            "passed": True,
            "severity": "LOW",
            "description": "Full destination target is directly specified.",
            "evidence": "Direct domain"
        })

    # 8. Excessive URL Length & Structure
    url_len = len(raw_url)
    if url_len > 120:
        risk_score += 20
        reasons.append(f"Abnormally long URL ({url_len} chars), characteristic of token injection or phishing obfuscation.")
        checks.append({
            "id": "url_length",
            "title": "Length & Complexity Heuristic",
            "category": "Structural Analysis",
            "passed": False,
            "severity": "MEDIUM",
            "description": f"URL length is {url_len} characters, exceeding safe standard thresholds.",
            "evidence": f"{url_len} characters"
        })
    elif url_len > 80:
        risk_score += 10
        checks.append({
            "id": "url_length",
            "title": "Length & Complexity Heuristic",
            "category": "Structural Analysis",
            "passed": True,
            "severity": "LOW",
            "description": "URL length is slightly elevated but within acceptable parameters.",
            "evidence": f"{url_len} characters"
        })
    else:
        checks.append({
            "id": "url_length",
            "title": "Length & Complexity Heuristic",
            "category": "Structural Analysis",
            "passed": True,
            "severity": "LOW",
            "description": "Normal concise URL structure.",
            "evidence": f"{url_len} characters"
        })

    # 9. Excessive Subdomains (Domain Stacking)
    subdomain_count = len(domain_parts) - 2 if len(domain_parts) > 2 else 0
    if subdomain_count >= 3:
        risk_score += 25
        reasons.append(f"Excessive subdomain nesting ({subdomain_count} subdomains), often used to fake login paths.")
        checks.append({
            "id": "subdomain_nesting",
            "title": "Subdomain Hierarchy",
            "category": "Structural Analysis",
            "passed": False,
            "severity": "HIGH",
            "description": f"Domain features {subdomain_count} nested subdomains, masking the actual root domain.",
            "evidence": hostname
        })
    else:
        checks.append({
            "id": "subdomain_nesting",
            "title": "Subdomain Hierarchy",
            "category": "Structural Analysis",
            "passed": True,
            "severity": "LOW",
            "description": "Standard subdomain hierarchy.",
            "evidence": f"{max(0, subdomain_count)} subdomains"
        })

    # 10. Suspicious Characters (@ symbol, multiple hyphens, port)
    if "@" in raw_url:
        risk_score += 35
        reasons.append("Contains '@' symbol: Browser treats prefix as HTTP basic authentication, redirecting to the trailing host.")
        checks.append({
            "id": "auth_spoof",
            "title": "Credential Prefix Spoofing (@)",
            "category": "URL Manipulation",
            "passed": False,
            "severity": "HIGH",
            "description": "URL uses '@' symbol to mislead user into thinking previous domain is the host.",
            "evidence": "Contains '@'"
        })

    if hostname.count("-") >= 3:
        risk_score += 15
        reasons.append("High number of hyphens in domain, common in typosquatting and fake security landing portals.")
        checks.append({
            "id": "hyphen_stuffing",
            "title": "Hyphen Density Analysis",
            "category": "Domain Integrity",
            "passed": False,
            "severity": "MEDIUM",
            "description": f"Hostname contains {hostname.count('-')} hyphens.",
            "evidence": hostname
        })

    # 11. Open Redirect Query Parameters
    qs = parse_qs(query)
    redirect_keys = ["redirect", "url", "next", "dest", "return_to", "link", "target", "goto"]
    redirect_target = None
    for k in redirect_keys:
        if k in qs:
            val = qs[k][0]
            if val.startswith("http://") or val.startswith("https://") or "//" in val:
                redirect_target = val
                break

    if redirect_target:
        risk_score += 25
        reasons.append(f"Open redirect parameter detected: may bounce unsuspecting users to '{redirect_target[:40]}...'.")
        checks.append({
            "id": "open_redirect",
            "title": "Open Redirect Protection",
            "category": "Application Security",
            "passed": False,
            "severity": "HIGH",
            "description": f"Query string embeds a target redirect destination.",
            "evidence": redirect_target
        })
    else:
        checks.append({
            "id": "open_redirect",
            "title": "Open Redirect Protection",
            "category": "Application Security",
            "passed": True,
            "severity": "LOW",
            "description": "No third-party redirect forwarding parameters detected.",
            "evidence": "Clean query parameters"
        })

    # 12. Shannon Entropy of Domain
    entropy = calculate_shannon_entropy(hostname)
    if entropy > 3.8 and len(hostname) > 14:
        risk_score += 20
        reasons.append(f"High domain entropy ({entropy}), indicative of DGA (Domain Generation Algorithm) or disposable registration.")
        checks.append({
            "id": "domain_entropy",
            "title": "Shannon Entropy & Randomness",
            "category": "Algorithmic Analysis",
            "passed": False,
            "severity": "MEDIUM",
            "description": f"Calculated Shannon entropy is {entropy} (high lexical randomness).",
            "evidence": f"Entropy: {entropy}"
        })
    else:
        checks.append({
            "id": "domain_entropy",
            "title": "Shannon Entropy & Randomness",
            "category": "Algorithmic Analysis",
            "passed": True,
            "severity": "LOW",
            "description": f"Entropy level ({entropy}) is consistent with natural linguistic language patterns.",
            "evidence": f"Entropy: {entropy}"
        })

    # Clamp risk score to 0 - 100
    risk_score = min(100, max(0, risk_score))

    # Categorize Risk Level
    if risk_score >= 80:
        risk_level = "CRITICAL"
    elif risk_score >= 60:
        risk_level = "HIGH"
    elif risk_score >= 30:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    # Actionable Recommendations
    if risk_level in ["CRITICAL", "HIGH"]:
        recommendations.extend([
            "DO NOT click this link or submit any passwords or payment information.",
            "If already visited, immediately change passwords for any account you may have entered.",
            "Block this domain at the enterprise DNS / firewall perimeter.",
            "Report the link to your security team or phishguard threat feed."
        ])
    elif risk_level == "MEDIUM":
        recommendations.extend([
            "Proceed with extreme caution. Verify the domain identity independently before entering credentials.",
            "Inspect the SSL certificate and check whether the company requested this action.",
            "Consider manually navigating to the organization's verified homepage rather than following this link."
        ])
    else:
        recommendations.extend([
            "No active malicious indicators detected by local heuristic rules.",
            "Exercise standard cyber hygiene: verify the domain matches your expected destination.",
            "Never share 2FA codes or master passwords over email or chat."
        ])

    passed_checks = [c for c in checks if c["passed"]]
    failed_checks = [c for c in checks if not c["passed"]]

    summary = (
        f"Critical security flags identified: {len(failed_checks)} anomalous indicators detected."
        if risk_level in ["CRITICAL", "HIGH"]
        else f"Elevated caution required: {len(failed_checks)} warning indicators detected."
        if risk_level == "MEDIUM"
        else "No suspicious indicators detected based on heuristic rules. Exercise normal caution."
    )

    return {
        "risk_score": risk_score,
        "risk_level": risk_level,
        "target": raw_url,
        "hostname": hostname,
        "scheme": parsed.scheme,
        "path": path,
        "entropy": entropy,
        "summary": summary,
        "total_checks": len(checks),
        "passed_count": len(passed_checks),
        "failed_count": len(failed_checks),
        "passed_checks": passed_checks,
        "failed_checks": failed_checks,
        "reasons": reasons,
        "recommendations": recommendations,
        "metadata": {
            "is_ip": is_ip_host,
            "has_punycode": punycode_detected,
            "tld": tld,
            "brand_flag": brand_impersonated,
            "url_length": url_len,
        }
    }
