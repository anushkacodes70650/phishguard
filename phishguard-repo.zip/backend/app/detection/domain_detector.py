import socket
import ssl
import datetime
from typing import Dict, Any, List
import dns.resolver

from app.detection.url_detector import (
    check_ssrf_safety,
    calculate_shannon_entropy,
    TARGETED_BRANDS,
    HIGH_RISK_TLDS,
    HOMOGLYPHS
)

def inspect_dns_records(domain: str) -> Dict[str, Any]:
    """Safely queries public DNS for A, MX, NS, and TXT records with timeout."""
    dns_data = {
        "a_records": [],
        "mx_records": [],
        "ns_records": [],
        "has_spf": False,
        "dns_resolved": False,
        "error": None
    }
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 2.0
        resolver.lifetime = 2.0

        # Query A records
        try:
            a_answers = resolver.resolve(domain, "A")
            dns_data["a_records"] = [r.to_text() for r in a_answers]
            dns_data["dns_resolved"] = len(dns_data["a_records"]) > 0
        except Exception:
            pass

        # Query MX records
        try:
            mx_answers = resolver.resolve(domain, "MX")
            dns_data["mx_records"] = [r.exchange.to_text().rstrip(".") for r in mx_answers]
        except Exception:
            pass

        # Query NS records
        try:
            ns_answers = resolver.resolve(domain, "NS")
            dns_data["ns_records"] = [r.target.to_text().rstrip(".") for r in ns_answers]
        except Exception:
            pass

        # Query TXT records (for SPF)
        try:
            txt_answers = resolver.resolve(domain, "TXT")
            for r in txt_answers:
                txt_str = r.to_text().lower()
                if "v=spf1" in txt_str:
                    dns_data["has_spf"] = True
                    break
        except Exception:
            pass

    except Exception as e:
        dns_data["error"] = str(e)

    return dns_data

def inspect_ssl_certificate(domain: str) -> Dict[str, Any]:
    """Safely inspects TLS handshake certificate metadata without downloading web assets."""
    ssl_data = {
        "ssl_active": False,
        "issuer": "None",
        "subject": "None",
        "valid_from": None,
        "valid_to": None,
        "days_remaining": 0,
        "is_expired": False,
        "error": None
    }
    
    ctx = ssl.create_default_context()
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED

    try:
        with socket.create_connection((domain, 443), timeout=2.5) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                ssl_data["ssl_active"] = True
                
                # Extract issuer
                issuer_dict = dict(x[0] for x in cert.get("issuer", ()))
                ssl_data["issuer"] = issuer_dict.get("organizationName") or issuer_dict.get("commonName") or "Unknown Issuer"

                # Extract subject
                subject_dict = dict(x[0] for x in cert.get("subject", ()))
                ssl_data["subject"] = subject_dict.get("commonName") or domain

                # Dates
                not_before_str = cert.get("notBefore")
                not_after_str = cert.get("notAfter")
                if not_after_str:
                    exp_date = datetime.datetime.strptime(not_after_str, "%b %d %H:%M:%S %Y %Z")
                    ssl_data["valid_to"] = exp_date.isoformat()
                    days_left = (exp_date - datetime.datetime.utcnow()).days
                    ssl_data["days_remaining"] = days_left
                    ssl_data["is_expired"] = days_left <= 0

                if not_before_str:
                    val_from = datetime.datetime.strptime(not_before_str, "%b %d %H:%M:%S %Y %Z")
                    ssl_data["valid_from"] = val_from.isoformat()

    except Exception as e:
        ssl_data["error"] = "SSL handshake failed or host not reachable on port 443"

    return ssl_data

def analyze_domain(raw_domain: str) -> Dict[str, Any]:
    """Comprehensive domain intelligence analysis."""
    clean_domain = raw_domain.strip().lower()
    if clean_domain.startswith("http://"):
        clean_domain = clean_domain[7:]
    elif clean_domain.startswith("https://"):
        clean_domain = clean_domain[8:]
    clean_domain = clean_domain.split("/")[0].split(":")[0]

    # SSRF verification
    ssrf_ok, ssrf_msg = check_ssrf_safety(clean_domain)
    if not ssrf_ok:
        return {
            "domain": clean_domain,
            "risk_score": 100,
            "risk_level": "CRITICAL",
            "summary": f"SSRF Protection Alert: {ssrf_msg}",
            "dns": {},
            "ssl": {},
            "checks": [],
            "reasons": [ssrf_msg],
            "recommendations": ["Internal or loopback domains are barred from scanning."]
        }

    checks: List[Dict[str, Any]] = []
    risk_score = 0
    reasons: List[str] = []
    recommendations: List[str] = []

    # 1. Structural checks
    domain_parts = clean_domain.split(".")
    tld = domain_parts[-1] if len(domain_parts) > 1 else ""

    # Check high-risk TLD
    if tld in HIGH_RISK_TLDS:
        risk_score += 25
        reasons.append(f"Domain registered under high-risk TLD (.{tld}).")
        checks.append({
            "title": "Top-Level Domain Risk",
            "passed": False,
            "severity": "MEDIUM",
            "description": f"The top-level domain '.{tld}' is associated with frequent spam and disposable campaigns."
        })
    else:
        checks.append({
            "title": "Top-Level Domain Risk",
            "passed": True,
            "severity": "LOW",
            "description": f"Standard enterprise TLD (.{tld})."
        })

    # Homoglyphs & Punycode
    has_punycode = "xn--" in clean_domain
    homos = [c for c in clean_domain if c in HOMOGLYPHS]
    if has_punycode or homos:
        risk_score += 40
        reasons.append("Punycode / Cyrillic confusable homoglyphs detected in domain name.")
        checks.append({
            "title": "Homograph & IDN Spoofing",
            "passed": False,
            "severity": "CRITICAL",
            "description": "Domain appears to mimic Latin text using foreign confusable characters."
        })
    else:
        checks.append({
            "title": "Homograph & IDN Spoofing",
            "passed": True,
            "severity": "LOW",
            "description": "Clean standard ASCII character representation."
        })

    # Brand Impersonation
    impersonated = None
    for brand, legits in TARGETED_BRANDS.items():
        if brand in clean_domain:
            if not any(clean_domain == ld or clean_domain.endswith("." + ld) for ld in legits):
                impersonated = brand
                break

    if impersonated:
        risk_score += 40
        reasons.append(f"Brand impersonation attempt targeting '{impersonated.upper()}'.")
        checks.append({
            "title": "Brand Trademark Protection",
            "passed": False,
            "severity": "CRITICAL",
            "description": f"Domain embeds brand token '{impersonated}' without authorized lineage."
        })
    else:
        checks.append({
            "title": "Brand Trademark Protection",
            "passed": True,
            "severity": "LOW",
            "description": "No unauthorized brand keyword collisions detected."
        })

    # Entropy
    entropy = calculate_shannon_entropy(clean_domain)
    if entropy > 3.8 and len(clean_domain) > 12:
        risk_score += 20
        reasons.append(f"High domain character entropy ({entropy}) suggesting algorithmic domain generation (DGA).")
        checks.append({
            "title": "Lexical Randomness (Entropy)",
            "passed": False,
            "severity": "MEDIUM",
            "description": f"High lexical entropy ({entropy}) observed."
        })
    else:
        checks.append({
            "title": "Lexical Randomness (Entropy)",
            "passed": True,
            "severity": "LOW",
            "description": f"Entropy level ({entropy}) is normal."
        })

    # 2. DNS Resolution
    dns_info = inspect_dns_records(clean_domain)
    if not dns_info["dns_resolved"]:
        risk_score += 15
        reasons.append("Domain has no active A records or fails DNS resolution.")
        checks.append({
            "title": "DNS Routing & A-Records",
            "passed": False,
            "severity": "MEDIUM",
            "description": "Domain does not resolve to an active IPv4 address."
        })
    else:
        checks.append({
            "title": "DNS Routing & A-Records",
            "passed": True,
            "severity": "LOW",
            "description": f"Resolves to {len(dns_info['a_records'])} host IP address(es)."
        })

    if dns_info["has_spf"]:
        checks.append({
            "title": "Email Spoofing Protection (SPF)",
            "passed": True,
            "severity": "LOW",
            "description": "SPF DNS record published to prevent unauthorized email forgery."
        })
    else:
        checks.append({
            "title": "Email Spoofing Protection (SPF)",
            "passed": False,
            "severity": "LOW",
            "description": "No SPF DNS record detected. Domain can be spoofed in outbound SMTP mail."
        })

    # 3. SSL Inspection
    ssl_info = inspect_ssl_certificate(clean_domain)
    if ssl_info["ssl_active"]:
        if ssl_info["is_expired"]:
            risk_score += 25
            reasons.append("TLS Certificate has expired.")
            checks.append({
                "title": "TLS Certificate Status",
                "passed": False,
                "severity": "HIGH",
                "description": f"Expired certificate issued by {ssl_info['issuer']}."
            })
        else:
            checks.append({
                "title": "TLS Certificate Status",
                "passed": True,
                "severity": "LOW",
                "description": f"Valid certificate issued by {ssl_info['issuer']} ({ssl_info['days_remaining']} days remaining)."
            })
    else:
        risk_score += 10
        checks.append({
            "title": "TLS Certificate Status",
            "passed": False,
            "severity": "LOW",
            "description": "No direct HTTPS/TLS service responsive on port 443."
        })

    # Final Risk Score & Classification
    risk_score = min(100, max(0, risk_score))
    if risk_score >= 80:
        risk_level = "CRITICAL"
    elif risk_score >= 60:
        risk_level = "HIGH"
    elif risk_score >= 30:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    if risk_level in ["CRITICAL", "HIGH"]:
        recommendations.extend([
            "Domain exhibits significant phishing / malicious behavior indicators.",
            "Consider blacklisting this domain in enterprise egress firewalls.",
            "Alert end-users to disregard any correspondence referencing this domain."
        ])
    elif risk_level == "MEDIUM":
        recommendations.extend([
            "Exercise caution. Domain presents minor risk signals.",
            "Verify the domain ownership if dealing with financial transactions."
        ])
    else:
        recommendations.extend([
            "Domain presents typical legitimate infrastructure signals.",
            "Exercise routine security monitoring."
        ])

    return {
        "domain": clean_domain,
        "risk_score": risk_score,
        "risk_level": risk_level,
        "summary": (
            f"High-risk domain intelligence profile: {len(reasons)} significant indicators identified."
            if risk_level in ["CRITICAL", "HIGH"]
            else f"Elevated profile: {len(reasons)} potential warning flags identified."
            if risk_level == "MEDIUM"
            else "Domain infrastructure exhibits standard operational characteristics."
        ),
        "entropy": entropy,
        "tld": tld,
        "dns": dns_info,
        "ssl": ssl_info,
        "checks": checks,
        "reasons": reasons,
        "recommendations": recommendations
    }
