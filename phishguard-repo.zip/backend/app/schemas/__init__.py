from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, EmailStr, Field

# Auth Schemas
class UserBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr

class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=128)
    confirm_password: Optional[str] = None
    organization: Optional[str] = "Independent"

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=128)

class UserResponse(UserBase):
    id: str
    role: str
    organization: Optional[str]
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime] = None

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

# Scan Request Schemas
class UrlScanRequest(BaseModel):
    url: str = Field(..., min_length=3, max_length=2048)

class MessageScanRequest(BaseModel):
    message: str = Field(..., min_length=5, max_length=20000)
    sender_hint: Optional[str] = None

class DomainScanRequest(BaseModel):
    domain: str = Field(..., min_length=3, max_length=255)

# Detailed Result Schemas
class SecurityCheckItem(BaseModel):
    id: str
    title: str
    category: str
    passed: bool
    severity: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    description: str
    evidence: Optional[str] = None

class ScanResponse(BaseModel):
    id: str
    scan_type: str
    input_value: str
    target_display: Optional[str]
    risk_score: int
    risk_level: str
    summary: Optional[str]
    created_at: datetime
    result: Dict[str, Any]

    class Config:
        from_attributes = True

class ScanHistoryItem(BaseModel):
    id: str
    scan_type: str
    target_display: Optional[str]
    risk_score: int
    risk_level: str
    summary: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

# Threat Intelligence Schemas
class ThreatItem(BaseModel):
    id: str
    indicator: str
    threat_type: str
    source: str
    confidence: int
    severity: str
    tags: str
    first_seen: datetime
    last_seen: datetime

    class Config:
        from_attributes = True

class ThreatStats(BaseModel):
    total_threats: int
    phishing_count: int
    impersonation_count: int
    malware_c2_count: int
    social_eng_count: int
    avg_confidence: float

# Settings Schemas
class UserSettingsResponse(BaseModel):
    theme: str
    notifications_enabled: bool
    deep_analysis_enabled: bool
    auto_export_pdf: bool
    email_alerts: bool
    updated_at: datetime

    class Config:
        from_attributes = True

class UserSettingsUpdate(BaseModel):
    theme: Optional[str] = None
    notifications_enabled: Optional[bool] = None
    deep_analysis_enabled: Optional[bool] = None
    auto_export_pdf: Optional[bool] = None
    email_alerts: Optional[bool] = None

class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    organization: Optional[str] = None

# Report Schemas
class ReportResponse(BaseModel):
    id: str
    scan_id: str
    report_code: str
    report_name: str
    file_size_bytes: int
    created_at: datetime

    class Config:
        from_attributes = True

# Quiz Schemas
class QuizSubmitRequest(BaseModel):
    module_id: str
    module_title: str
    score: int
    passed: bool
