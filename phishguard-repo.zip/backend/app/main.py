from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.core.config import settings
from app.database.session import Base, engine
from app.database.seed import seed_database

# Routers
from app.api.auth import router as auth_router
from app.api.scan import router as scan_router
from app.api.history import router as history_router
from app.api.dashboard import router as dashboard_router
from app.api.threats import router as threats_router
from app.api.reports import router as reports_router
from app.api.profile import router as profile_router
from app.api.admin import router as admin_router
from app.api.awareness import router as awareness_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize DB schemas & seed baseline accounts and threats
    Base.metadata.create_all(bind=engine)
    seed_database()
    yield

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.PROJECT_VERSION,
    description="Enterprise AI-Powered Phishing Detection & Cyber Threat Intelligence API",
    lifespan=lifespan
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permits dev frontend and custom ports
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Routers under API prefix
app.include_router(auth_router, prefix=settings.API_V1_STR)
app.include_router(scan_router, prefix=settings.API_V1_STR)
app.include_router(history_router, prefix=settings.API_V1_STR)
app.include_router(dashboard_router, prefix=settings.API_V1_STR)
app.include_router(threats_router, prefix=settings.API_V1_STR)
app.include_router(reports_router, prefix=settings.API_V1_STR)
app.include_router(profile_router, prefix=settings.API_V1_STR)
app.include_router(admin_router, prefix=settings.API_V1_STR)
app.include_router(awareness_router, prefix=settings.API_V1_STR)

@app.get("/api/health")
def health_check():
    return {
        "status": "ONLINE",
        "service": "PhishGuard Threat Intelligence API",
        "version": settings.PROJECT_VERSION,
        "engine": "PhishGuard DeepInspect Heuristic & Rule Engine"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
