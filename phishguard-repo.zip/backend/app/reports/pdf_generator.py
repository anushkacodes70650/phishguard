import os
import uuid
from datetime import datetime
from typing import Dict, Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, KeepTogether
from reportlab.pdfgen import canvas

from app.core.config import settings

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_footer(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_footer(self, page_count):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748B"))
        # Footer text
        footer_text = f"PHISHGUARD AI CYBER INTELLIGENCE PLATFORM  |  CONFIDENTIAL FORENSIC REPORT  |  Page {self._pageNumber} of {page_count}"
        self.drawCentredString(letter[0] / 2.0, 30, footer_text)
        self.setStrokeColor(colors.HexColor("#1E293B"))
        self.setLineWidth(0.5)
        self.line(40, 45, letter[0] - 40, 45)
        self.restoreState()

def generate_security_pdf_report(scan_data: Dict[str, Any], user_email: str) -> str:
    """Generates an enterprise-grade cybersecurity PDF report."""
    os.makedirs(settings.REPORTS_DIR, exist_ok=True)
    report_id = f"PG-{datetime.utcnow().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
    filename = f"{report_id}.pdf"
    file_path = os.path.join(settings.REPORTS_DIR, filename)

    doc = SimpleDocTemplate(
        file_path,
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=54
    )

    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=colors.HexColor("#0F172A")
    )
    
    subtitle_style = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#475569")
    )

    h2_style = ParagraphStyle(
        'Heading2Custom',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#0F172A"),
        spaceBefore=10,
        spaceAfter=4
    )

    normal_style = ParagraphStyle(
        'NormalCustom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor("#334155")
    )

    code_style = ParagraphStyle(
        'CodeCustom',
        parent=styles['Normal'],
        fontName='Courier',
        fontSize=8,
        leading=11,
        textColor=colors.HexColor("#0284C7")
    )

    elements = []

    # 1. Header Banner
    elements.append(Paragraph("<b>PHISHGUARD</b> // FORENSIC SECURITY INTELLIGENCE REPORT", title_style))
    elements.append(Paragraph(f"Generated for: <b>{user_email}</b> | Report Reference: <b>{report_id}</b> | Classification: <b>RESTRICTED</b>", subtitle_style))
    elements.append(Spacer(1, 10))
    elements.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#00E5FF"), spaceAfter=12))

    # 2. Executive Summary & Risk Gauge Box
    risk_score = scan_data.get("risk_score", 0)
    risk_level = scan_data.get("risk_level", "LOW")
    scan_type = scan_data.get("scan_type", "URL").upper()
    target_input = scan_data.get("input_value", "")
    summary_text = scan_data.get("summary", "Analysis completed.")

    # Color code risk
    if risk_level == "CRITICAL":
        risk_color = colors.HexColor("#DC2626")  # Red
        bg_badge = colors.HexColor("#FEE2E2")
    elif risk_level == "HIGH":
        risk_color = colors.HexColor("#EA580C")  # Orange
        bg_badge = colors.HexColor("#FFEDD5")
    elif risk_level == "MEDIUM":
        risk_color = colors.HexColor("#D97706")  # Amber
        bg_badge = colors.HexColor("#FEF3C7")
    else:
        risk_color = colors.HexColor("#16A34A")  # Green
        bg_badge = colors.HexColor("#DCFCE7")

    meta_table_data = [
        [
            Paragraph("<b>Target Input:</b>", normal_style),
            Paragraph(f"<font name='Courier'>{target_input[:70]}...</font>" if len(target_input) > 70 else f"<font name='Courier'>{target_input}</font>", normal_style),
            Paragraph("<b>Risk Score:</b>", normal_style),
            Paragraph(f"<font color='{risk_color.hexval()}'><b>{risk_score} / 100</b></font>", normal_style)
        ],
        [
            Paragraph("<b>Scan Type:</b>", normal_style),
            Paragraph(scan_type, normal_style),
            Paragraph("<b>Threat Level:</b>", normal_style),
            Paragraph(f"<font color='{risk_color.hexval()}'><b>{risk_level}</b></font>", normal_style)
        ],
        [
            Paragraph("<b>Timestamp:</b>", normal_style),
            Paragraph(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"), normal_style),
            Paragraph("<b>Engine:</b>", normal_style),
            Paragraph("PhishGuard DeepInspect v2.4", normal_style)
        ]
    ]

    meta_table = Table(meta_table_data, colWidths=[80, 220, 80, 160])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor("#F8FAFC")),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor("#E2E8F0")),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(meta_table)
    elements.append(Spacer(1, 14))

    # 3. Assessment Narrative
    elements.append(Paragraph("EXECUTIVE ASSESSMENT SUMMARY", h2_style))
    elements.append(Paragraph(summary_text, normal_style))
    elements.append(Spacer(1, 12))

    # 4. Detailed Security Indicators / Checks Table
    elements.append(Paragraph("TECHNICAL FORENSIC INDICATORS", h2_style))
    
    # Extract checks from result dictionary
    result_dict = scan_data.get("result", {})
    failed_checks = result_dict.get("failed_checks", [])
    passed_checks = result_dict.get("passed_checks", [])
    psych_triggers = result_dict.get("psychological_triggers", [])

    table_rows = [
        [
            Paragraph("<b>Status</b>", normal_style),
            Paragraph("<b>Inspection Domain / Trigger</b>", normal_style),
            Paragraph("<b>Severity</b>", normal_style),
            Paragraph("<b>Technical Evidence & Details</b>", normal_style)
        ]
    ]

    # Add failed checks
    for fc in failed_checks[:8]:
        table_rows.append([
            Paragraph("<font color='#DC2626'><b>FAIL</b></font>", normal_style),
            Paragraph(f"<b>{fc.get('title', 'Unknown Check')}</b>", normal_style),
            Paragraph(f"<font color='#DC2626'>{fc.get('severity', 'HIGH')}</font>", normal_style),
            Paragraph(fc.get('description', '')[:140], normal_style)
        ])

    # Add psychological triggers for message scans
    for pt in psych_triggers[:6]:
        table_rows.append([
            Paragraph("<font color='#DC2626'><b>ALERT</b></font>", normal_style),
            Paragraph(f"<b>{pt.get('category', 'Social Engineering')}</b>", normal_style),
            Paragraph(f"<font color='#EA580C'>{pt.get('severity', 'HIGH')}</font>", normal_style),
            Paragraph(f"Pattern matched: {', '.join(pt.get('matched_phrases', []))[:90]}", normal_style)
        ])

    # Add passed checks
    for pc in passed_checks[:6]:
        table_rows.append([
            Paragraph("<font color='#16A34A'><b>PASS</b></font>", normal_style),
            Paragraph(pc.get('title', 'Security Standard'), normal_style),
            Paragraph("<font color='#16A34A'>CLEAN</font>", normal_style),
            Paragraph(pc.get('description', 'Passed security parameters')[:140], normal_style)
        ])

    if len(table_rows) == 1:
        table_rows.append([
            Paragraph("<font color='#16A34A'><b>PASS</b></font>", normal_style),
            Paragraph("Baseline Integrity Verification", normal_style),
            Paragraph("LOW", normal_style),
            Paragraph("No active exploitation anomalies observed in structural parsing.", normal_style)
        ])

    indicator_table = Table(table_rows, colWidths=[45, 150, 65, 280])
    indicator_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0F172A")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor("#CBD5E1")),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(indicator_table)
    elements.append(Spacer(1, 14))

    # 5. Actionable Mitigation Recommendations
    elements.append(Paragraph("RECOMMENDED REMEDIATION PROTOCOL", h2_style))
    recommendations = result_dict.get("recommendations", [])
    if not recommendations:
        recommendations = [
            "Maintain continuous perimeter monitoring.",
            "Enforce strict FIDO2 / WebAuthn multi-factor authentication.",
            "Verify sender credentials via secondary out-of-band communication."
        ]

    for idx, rec in enumerate(recommendations, 1):
        elements.append(Paragraph(f"<b>[{idx}]</b> {rec}", normal_style))
        elements.append(Spacer(1, 3))

    elements.append(Spacer(1, 14))
    elements.append(Paragraph("<b>Disclaimer:</b> This report is generated by automated heuristics and cyber intelligence feeds. While highly accurate, threat actors evolve rapidly; local classification should always be combined with defense-in-depth organizational security controls.", subtitle_style))

    doc.build(elements, canvasmaker=NumberedCanvas)
    return file_path
