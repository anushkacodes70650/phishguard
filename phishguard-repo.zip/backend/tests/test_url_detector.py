import pytest
from app.detection.url_detector import analyze_url, check_ssrf_safety, calculate_shannon_entropy

def test_legitimate_google_url():
    result = analyze_url("https://www.google.com/search?q=cybersecurity")
    assert result["risk_score"] < 30
    assert result["risk_level"] == "LOW"
    assert result["failed_count"] == 0 or result["risk_score"] <= 20

def test_brand_impersonation_detection():
    result = analyze_url("https://paypal-security-login-verify.xyz/account")
    assert result["risk_score"] >= 60
    assert result["risk_level"] in ["HIGH", "CRITICAL"]
    assert any(fc["id"] == "brand_impersonation" for fc in result["failed_checks"])

def test_ip_address_host_detection():
    # Use public routable IPv4 address
    result = analyze_url("http://93.184.216.34/auth/login")
    assert any(fc["id"] == "ip_host" for fc in result["failed_checks"])
    assert result["risk_score"] >= 30

def test_ssrf_prevention():
    # Localhost should trigger SSRF alert
    res_loopback = analyze_url("http://127.0.0.1/admin")
    assert res_loopback.get("is_ssrf_risk") is True
    assert res_loopback["risk_score"] == 100

    # Private IP range
    res_private = analyze_url("http://192.168.1.1/router")
    assert res_private.get("is_ssrf_risk") is True

    # Cloud metadata
    res_meta = analyze_url("http://169.254.169.254/latest/meta-data/")
    assert res_meta.get("is_ssrf_risk") is True

def test_homoglyph_detection():
    # Cyrillic 'a' (U+0430) instead of Latin 'a'
    cyrillic_url = "https://p\u0430ypal.com/signin"
    result = analyze_url(cyrillic_url)
    assert any(fc["id"] == "homoglyph_spoof" for fc in result["failed_checks"])

def test_shannon_entropy():
    # Random DGA string vs normal string
    entropy_normal = calculate_shannon_entropy("google.com")
    entropy_random = calculate_shannon_entropy("xj89v2kqlmn4z9981a.biz")
    assert entropy_random > entropy_normal
