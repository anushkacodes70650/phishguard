import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ONLINE"

def test_login_demo_analyst():
    response = client.post("/api/auth/login", json={
        "email": "analyst@phishguard.ai",
        "password": "Analyst@PhishGuard2026!"
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == "analyst@phishguard.ai"

def test_login_demo_admin():
    response = client.post("/api/auth/login", json={
        "email": "admin@phishguard.ai",
        "password": "Admin@PhishGuard2026!"
    })
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["role"] == "admin"

def test_unauthorized_dashboard_access():
    response = client.get("/api/dashboard/overview")
    assert response.status_code == 401

def test_authorized_url_scan_flow():
    # Login as analyst
    login_res = client.post("/api/auth/login", json={
        "email": "analyst@phishguard.ai",
        "password": "Analyst@PhishGuard2026!"
    })
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Perform URL scan
    scan_res = client.post("/api/scan/url", json={
        "url": "https://paypal-security-account-verification.xyz/login"
    }, headers=headers)

    assert scan_res.status_code == 200
    scan_data = scan_res.json()
    assert scan_data["risk_score"] >= 60
    assert scan_data["risk_level"] in ["HIGH", "CRITICAL"]

    # Verify scan recorded in history
    hist_res = client.get("/api/history", headers=headers)
    assert hist_res.status_code == 200
    assert hist_res.json()["total"] > 0

def test_admin_authorization():
    # User token cannot access admin endpoint
    login_user = client.post("/api/auth/login", json={
        "email": "analyst@phishguard.ai",
        "password": "Analyst@PhishGuard2026!"
    })
    user_token = login_user.json()["access_token"]
    res_forbidden = client.get("/api/admin/overview", headers={"Authorization": f"Bearer {user_token}"})
    assert res_forbidden.status_code == 403

    # Admin token can access admin endpoint
    login_admin = client.post("/api/auth/login", json={
        "email": "admin@phishguard.ai",
        "password": "Admin@PhishGuard2026!"
    })
    admin_token = login_admin.json()["access_token"]
    res_allowed = client.get("/api/admin/overview", headers={"Authorization": f"Bearer {admin_token}"})
    assert res_allowed.status_code == 200
    assert "total_users" in res_allowed.json()
