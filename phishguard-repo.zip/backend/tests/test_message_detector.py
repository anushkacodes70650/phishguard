import pytest
from app.detection.message_detector import analyze_message

def test_urgent_banking_phishing_message():
    phish_msg = (
        "URGENT: Your Wells Fargo bank account will be suspended within 24 hours. "
        "Verify your password and SSN immediately at https://chase-bank-verify.xyz/auth "
        "or face legal action."
    )
    res = analyze_message(phish_msg)
    assert res["risk_score"] >= 60
    assert res["risk_level"] in ["HIGH", "CRITICAL"]
    assert len(res["psychological_triggers"]) >= 2
    assert len(res["suspicious_spans"]) > 0
    assert len(res["embedded_urls"]) >= 1

def test_prize_scam_message():
    scam_msg = "Congratulations! You have won a $1,000,000 lottery cash prize! Claim your reward now."
    res = analyze_message(scam_msg)
    assert res["risk_score"] >= 20
    assert any(pt["category"] == "Prize & Reward Lures" for pt in res["psychological_triggers"])

def test_legitimate_internal_message():
    legit_msg = "Hey Team, reminder that our weekly cybersecurity sprint demo starts at 3:00 PM in Conference Room B."
    res = analyze_message(legit_msg)
    assert res["risk_score"] == 0
    assert res["risk_level"] == "LOW"
    assert len(res["psychological_triggers"]) == 0
