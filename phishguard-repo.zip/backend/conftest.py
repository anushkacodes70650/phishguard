import sys
import os
import pytest

# Ensure backend root is on sys.path
sys.path.insert(0, os.path.dirname(__file__))

from app.database.session import Base, engine
from app.database.seed import seed_database

@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    Base.metadata.create_all(bind=engine)
    seed_database()
    yield
