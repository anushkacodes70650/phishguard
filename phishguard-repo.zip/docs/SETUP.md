# PHISHGUARD QUICKSTART & DEPLOYMENT GUIDE

## Prerequisites
- **Python**: 3.10+ (tested on Python 3.13)
- **Node.js**: v18+ (tested on Node v24)
- **NPM**: 9+

---

## 1. Backend Installation & Startup

```bash
# Navigate to backend directory
cd backend

# Install Python requirements
py -m pip install -r requirements.txt

# Start FastAPI development server
py -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

The database (`phishguard.db`) will automatically initialize and seed baseline accounts and threat indicators on startup.

---

## 2. Frontend Installation & Startup

```bash
# In a new terminal, navigate to frontend directory
cd frontend

# Install Node dependencies
npm install

# Start Vite dev server
npm run dev
```

Open `http://localhost:5173` in your browser.

---

## 3. Pre-Seeded Demonstration Accounts

You can test the platform instantly using the built-in fast-fill credentials on the Login page:

| Role | Email | Password |
|---|---|---|
| **Analyst (Standard)** | `analyst@phishguard.ai` | `Analyst@PhishGuard2026!` |
| **Administrator (Full Access)** | `admin@phishguard.ai` | `Admin@PhishGuard2026!` |

---

## 4. Running Backend Automated Tests

```bash
cd backend
py -m pytest tests -v
```
Verifies 15 test suites covering lexical heuristics, SSRF defense, brand impersonation, message NLP, JWT authentication, and admin authorization.
