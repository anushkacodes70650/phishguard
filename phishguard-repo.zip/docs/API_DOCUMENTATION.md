# PHISHGUARD REST API DOCUMENTATION

Base Endpoint: `http://localhost:8000/api`

---

## 1. Authentication

### `POST /auth/register`
Creates an operator account and issues a bearer access token.
- **Request Body**:
  ```json
  {
    "name": "Alex Mercer",
    "email": "analyst@phishguard.ai",
    "password": "Analyst@PhishGuard2026!",
    "confirm_password": "Analyst@PhishGuard2026!",
    "organization": "Threat Intelligence Unit"
  }
  ```
- **Response** `201 Created`:
  ```json
  {
    "access_token": "eyJhbGciOi...",
    "token_type": "bearer",
    "user": { "id": "...", "name": "Alex Mercer", "email": "...", "role": "user" }
  }
  ```

### `POST /auth/login`
Authenticates existing operator credentials.
- **Request Body**:
  ```json
  {
    "email": "analyst@phishguard.ai",
    "password": "Analyst@PhishGuard2026!"
  }
  ```

### `GET /auth/me`
Retrieves currently authenticated session user.
- **Headers**: `Authorization: Bearer <token>`

---

## 2. Detection & Inspection

### `POST /scan/url`
Performs static lexical, entropy, homoglyph, and brand impersonation analysis on target URL.
- **Request Body**:
  ```json
  {
    "url": "https://paypal-security-account-verification.xyz/login"
  }
  ```
- **Response**:
  ```json
  {
    "id": "c89b25f1-...",
    "scan_type": "url",
    "input_value": "https://paypal-security-account-verification.xyz/login",
    "risk_score": 85,
    "risk_level": "CRITICAL",
    "summary": "Critical security flags identified: 3 anomalous indicators detected.",
    "result": { ... }
  }
  ```

### `POST /scan/message`
Decomposes message payload for urgency pressure, threats, credential harvesting, and analyzes embedded URLs.
- **Request Body**:
  ```json
  {
    "message": "URGENT: Your bank account will be suspended within 24 hours. Verify your password now at https://fake-bank.xyz.",
    "sender_hint": "security@alert-bank.com"
  }
  ```

### `POST /domain/analyze`
Extracts DNS records (A, MX, NS, SPF) and tests SSL handshake certificates.
- **Request Body**:
  ```json
  {
    "domain": "paypal-security-update.xyz"
  }
  ```

---

## 3. History & Analytics

### `GET /history`
Returns paginated scan history for the authenticated user.
- **Query Parameters**:
  - `search`: Filter keyword
  - `scan_type`: `all`, `url`, `message`, `domain`
  - `risk_level`: `ALL`, `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`
  - `page`: Page index (1-based)
  - `limit`: Items per page (default: 10)

### `GET /history/export`
Exports scan telemetry in CSV or JSON format.
- **Query Parameters**: `format=csv` or `format=json`

### `GET /dashboard/overview`
Retrieves aggregated metrics: Total scans, Safe scans, Suspicious scans, Critical threats, Accuracy percentage, and Health posture score.

### `GET /dashboard/analytics`
Retrieves 7-day time series activity and threat category distribution for charts.

---

## 4. Reports & Awareness

### `POST /reports/generate/{scan_id}`
Compiles an enterprise forensic PDF report for a completed scan.

### `GET /reports/{report_id}/download`
Streams the binary PDF document for download.

### `GET /awareness/modules`
Returns educational cyber awareness modules with user certification status.

### `POST /awareness/quiz`
Submits quiz score and unlocks certified proficiency badges.

---

## 5. Administrative Controls

### `GET /admin/overview`
*(Admin Only)* Systemwide telemetry counters, scan distribution, and engine status.

### `GET /admin/users`
*(Admin Only)* List all registered operators and their scan volumes.

### `PUT /admin/users/{user_id}/role`
*(Admin Only)* Update an operator's role between `user` and `admin`.
