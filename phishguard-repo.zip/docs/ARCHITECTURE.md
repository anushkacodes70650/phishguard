# PHISHGUARD SYSTEM ARCHITECTURE

## 1. System Overview

**PHISHGUARD** is an AI-powered phishing detection and cyber threat intelligence platform engineered to identify, decompose, and neutralize social engineering campaigns, homoglyphic lookalike domains, credential harvesters, and malicious URLs before execution.

```
                    +------------------------------------+
                    |   User Interface (React + Vite)    |
                    |  Three.js 3D Shield | Recharts UI  |
                    +-----------------+------------------+
                                      |  REST API / JWT
                                      v
                    +------------------------------------+
                    |       FastAPI Backend Gateway      |
                    |  Rate Limiter & OAuth2 Security    |
                    +-----------------+------------------+
                                      |
         +----------------------------+----------------------------+
         |                            |                            |
         v                            v                            v
+------------------+         +------------------+         +------------------+
|  URL Inspector   |         | Message NLP Trap |         |  Domain Resolver |
|  - SSRF Sentinel |         |  - Urgency Levers|         |  - DNS Forensics |
|  - Homoglyphs    |         |  - Credential Hook|        |  - TLS Handshake |
|  - Shannon DGA   |         |  - BEC Detection |         |  - SPF Record    |
|  - Brand Spoof   |         |  - URL Extraction|         |  - TLD Risk      |
+--------+---------+         +--------+---------+         +--------+---------+
         |                            |                            |
         +----------------------------+----------------------------+
                                      |
                                      v
                    +------------------------------------+
                    |     Scoring & Decision Engine      |
                    | 0-100 Transparent Weighted Verdict |
                    +-----------------+------------------+
                                      |
                         +------------+------------+
                         |                         |
                         v                         v
               +-------------------+     +-------------------+
               |  SQLite Database  |     | ReportLab Engine  |
               |  Normalized ORM   |     | Cryptographic PDF |
               +-------------------+     +-------------------+
```

---

## 2. Core Detection Subsystems

### A. SSRF Isolation Guard (`check_ssrf_safety`)
To prevent Server-Side Request Forgery attacks, all user-submitted hostnames and resolved targets undergo strict routing boundary enforcement:
- Loopbacks (`127.0.0.1`, `localhost`, `::1`) are immediately barred.
- RFC 1918 private IPv4 allocations (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`) are blocked.
- Cloud instance metadata addresses (`169.254.169.254`, `metadata.google.internal`) are blocked.

### B. Lexical & Shannon Entropy Engine (`calculate_shannon_entropy`)
Calculates the information entropy of domain tokens using:
$$H(X) = -\sum_{i=1}^{n} P(x_i) \log_2 P(x_i)$$
High entropy ($>3.8$) on elongated labels triggers DGA (Domain Generation Algorithm) and disposable registration alerts.

### C. IDN Homoglyph & Punycode Analyzer
Detects Internationalized Domain Name (IDN) spoofing where visual Cyrillic/Greek confusables (e.g. Cyrillic `а` U+0430 substituted for Latin `a` U+0061) are decoded into `xn--` Punycode labels.

### D. Brand Impersonation Heuristics
Cross-references secondary labels and subdomains against high-value targets (PayPal, Apple, Microsoft, Google, Netflix, Chase, Wells Fargo, Binance) to flag unauthorized third-party brand stuffing.

### E. Social Engineering NLP Engine
Deconstructs inbound message payloads for cognitive manipulation triggers:
- Artificial urgency and compressed deadlines ("within 24 hours")
- Intimidation & punitive fear ("arrest warrant", "account suspended")
- Financial & credential harvesting hooks ("verify password", "wire transfer")
- Automated link extraction and secondary inspection of embedded endpoints.

---

## 3. Data Integrity & Authorization

- **Password Cryptography**: Native salted bcrypt (`bcrypt.hashpw` with `gensalt`) with strict 72-byte window protection.
- **Session Tokens**: Cryptographically signed JSON Web Tokens (HS256) with expiration enforcement.
- **Role-Based Access Control**: Backend dependency guards (`get_admin_user`) enforcing authorization at the route layer.
- **Document Generation**: Vector-rendered PDF reports generated using ReportLab, containing verifiable timestamps, forensic evidence tables, and mitigation protocols.
